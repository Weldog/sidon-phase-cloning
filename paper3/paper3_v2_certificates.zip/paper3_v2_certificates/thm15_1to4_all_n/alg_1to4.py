# Claude's INDEPENDENT re-derivation of Grok's Gate C algebra for 1->4 (T=1, m=4, t=5). Written from the
# definitions (GNW Sigma_{t,t}; Paper 3 Lemma 4 composition law; Gamma = seed-coordinate swap) — Grok's code not used.
import itertools, sympy as sp
t=5; MASK=(1<<t)-1
def wt(v): return bin(v).count('1')
def q(x,y): return (wt(x)-wt(y))%4                      # Z4 form x.x - y.y
def pack(x,y): return (x<<t)|y
def unpack(v): return v>>t, v&MASK
def span(gens):
    S={0}
    for g in gens: S|={s^g for s in S}
    return frozenset(S)
ONE=pack(MASK,MASK)
# enumerate Sigma_{5,5}: 5-dim subspaces of F_2^10 containing 1_10, q = 0 on every element
cands=[v for v in range(1<<(2*t)) if q(*unpack(v))==0]
found=set(); stack=[span([ONE])]
seen=set()
while stack:
    L=stack.pop()
    if L in seen: continue
    seen.add(L)
    if len(L)==2**t: found.add(L); continue
    for v in cands:
        if v in L: continue
        L2=span(list(L)+[v])
        if all(q(*unpack(w))==0 for w in L2) and L2 not in seen: stack.append(L2)
Sig=sorted(found,key=lambda L: sorted(L))
print("|Sigma_{5,5}| =",len(Sig))
# S4 x S4 acting on output coords 1..4 of x (left) and y (right)
def perm_bits(v,p):   # p permutes positions 1..4; position 0 fixed
    out=v&1
    for i in range(1,5):
        if (v>>i)&1: out|=1<<p[i-1]
    return out
P4=[tuple(1+j for j in p) for p in itertools.permutations(range(4))]
def act(L,p,r): return frozenset(pack(perm_bits(x,p),perm_bits(y,r)) for x,y in map(unpack,L))
idx={L:i for i,L in enumerate(Sig)}
orb=[-1]*len(Sig); orbits=[]
for i,L in enumerate(Sig):
    if orb[i]>=0: continue
    O={act(L,p,r) for p in P4 for r in P4}
    k=len(orbits); orbits.append(sorted(idx[x] for x in O))
    for x in O: orb[idx[x]]=k
print("orbit sizes:",[len(o) for o in orbits])
# identify the identity orbit (contains the diagonal relation) and transposition orbit
DIAG=frozenset(pack(x,x) for x in range(1<<t))
k_id=orb[idx[DIAG]]
def NL(U): return frozenset(x for x,y in map(unpack,U) if y==0)
def NR(U): return frozenset(y for x,y in map(unpack,U) if x==0)
def dim(S): return len(S).bit_length()-1
def compose(U1,U2):
    by={}
    for x,y in map(unpack,U2): by.setdefault(x,[]).append(y)
    return frozenset(pack(x,z) for x,y in map(unpack,U1) for z in by.get(y,[]))
def swap0(U):   # Gamma: exchange x0 <-> y0
    def sw(v):
        x,y=unpack(v); x0,y0=x&1,y&1
        return pack((x&~1)|y0,(y&~1)|x0)
    return frozenset(sw(v) for v in U)
def transpose(U): return frozenset(pack(y,x) for x,y in map(unpack,U))
D=sp.Symbol('D',positive=True)
def build(rel):   # rel: list (per orbit) of lists of subspaces; returns structure constants of span{b_k}
    lookup={}
    for k,O in enumerate(rel):
        for U in O: lookup[U]=k
    reps=[O[0] for O in rel]
    C=[[[0]*len(rel) for _ in rel] for _ in rel]          # b_i b_j = sum_k C[i][j][k] b_k
    for i,Oi in enumerate(rel):
        for j,Oj in enumerate(rel):
            coef={}
            for U1 in Oi:
                for U2 in Oj:
                    W=compose(U1,U2); assert W in lookup, "product left the span"
                    coef[W]=coef.get(W,0)+D**dim(NR(U1)&NL(U2))
            # coefficient of b_k = coefficient of any single member of orbit k (all equal by invariance)
            for k,Ok in enumerate(rel):
                vals={sp.expand(coef.get(U,0)) for U in Ok}
                assert len(vals)==1, "not orbit-constant"
                C[i][j][k]=vals.pop()
    tr=[sum(D**dim(U & DIAG) for U in O) for O in rel]
    T=[]   # transpose map on basis
    for O in rel:
        tk={lookup.get(transpose(U),None) for U in O}; assert len(tk)==1 and None not in tk; T.append(tk.pop())
    return C,tr,T
A=[[Sig[i] for i in O] for O in orbits]
B=[[swap0(Sig[i]) for i in O] for O in orbits]
CA,trA,TA=build(A); CB,trB,TB=build(B)
import pickle; pickle.dump(dict(orbits=orbits,k_id=k_id,CA=CA,CB=CB,trA=trA,trB=trB,TA=TA,TB=TB,sizes=[len(o) for o in orbits]),open('alg.pkl','wb'))
print("identity orbit index:",k_id,"| transpose map A:",TA,"B:",TB)
print("traces A:",[sp.factor(x) for x in trA])
print("sum of traces A:",sp.factor(sum(trA)))
