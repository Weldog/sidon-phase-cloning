# Claude: symbolic sandwich for G1 at 1->4, every D. Lower bound = top eigenvalue of B compressed to span{e,f}
# (e = z^{⊗4}, f = (D-1)^{-1/2} Σ_{x≠0} |x>^{⊗4}); entries via the amplitude lemma Σ_x α_x^4 = 2^r α_0^4 and
# E_S |α_0|^{2u} = F_u. Upper bound = Grok's Gate C dual value lambda(D) (PSD checked in verify_gateC.py).
import sympy as sp
D,s=sp.symbols('D s',positive=True)
def F(k): return sp.prod([2**i+1 for i in range(k-1)])/(D*sp.prod([D+2**i for i in range(k-1)]))
M11=F(5); M12sq=(F(4)-F(5))**2/(D-1); M22=(F(3)-2*F(4)+F(5))/(D-1)
tr=sp.factor(M11+M22); det=sp.factor(M11*M22-M12sq); Z=D*(D+1)*(D+2)*(D+4)*(D+8); lam=3*(D+48+s)/Z
num=sp.Poly(sp.numer(sp.together(lam**2-tr*lam+det)),s); rel=sp.Poly(s**2-(D**2+16*D+1664),s)
print("tr =",tr,"| det =",det)
print("lambda(D) is the LARGER root of the 2x2 for every D:", sp.expand(sp.rem(num,rel).as_expr())==0, "| 2*lambda - tr =", sp.factor(sp.together(2*lam-tr)))
