# Claude: exact characteristic polynomials of left multiplication by Z*S and Z*W on the independently rebuilt
# algebra (alg_1to4.py, verify_gateC.py), with s^2 = D^2+16D+1664 imposed. Expected: both equal t^3 (t-alpha)(t-tau)^2.
import sympy as sp
exec(open('verify_gateC.py').read().split("# numeric eigenvalues")[0])
t=sp.Symbol('t'); rel=s**2-(D**2+16*D+1664)
ell1=sp.Rational(15,8)*(D+40+s); tau=sp.Rational(3,8)*(D**2-24*D+64+(D+8)*s)
target=sp.expand(t**3*(t-ell1)*(t-tau)**2)
for name,L in [("L_ZS",LS),("L_ZW",LW)]:
    cp=sp.expand(L.charpoly(t).as_expr())
    diff=sp.rem(sp.Poly(sp.expand(cp-target),s), sp.Poly(rel,s))
    print(name,"charpoly == t^3 (t - 15/8(D+40+s)) (t - tau)^2  mod s^2 relation:", sp.simplify(diff.as_expr())==0)
print("tau > 0 for every D>0: (D+8)s > (D+8)^2  =>  tau > (3/4)(D^2-4D+64) > 0")
