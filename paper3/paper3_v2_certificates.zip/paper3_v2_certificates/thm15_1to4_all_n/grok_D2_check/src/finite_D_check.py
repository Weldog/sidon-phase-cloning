"""Gate C: exact H-criterion check of the D-formula certificate at D = 2, 4, 8, 16 (n = 1..4). Valid even when the b_k are
linearly dependent (D = 2): H_X[i,j] = tr(b_i^T X b_j); X >= 0 on range(P) iff H_X >= 0 (CA (own)). PSD decided exactly by all
principal minors >= 0 (entries in Q(sqrt(q)); sign of a + b sqrt(q) decided exactly by sympy)."""
import pickle, json, itertools, sympy as sp
from relalg import peval
H = pickle.load(open('../work/hmats.pkl', 'rb')); TA, TB = H['TA'], H['TB']
def cert(Dv):
    s = sp.sqrt(Dv**2 + 16*Dv + 1664); c = (Dv + 40 + s)/64
    v = [-sp.Rational(1, 2), -sp.Rational(1, 2), -c, -sp.Rational(1, 2), 4*c, c - 1]
    yt = 3*(Dv + 48 + s); return yt, v
def Hm(T, coef, Dv):
    return sp.Matrix(6, 6, lambda i, j: sp.nsimplify(sum(coef[k]*peval(T[i][k][j], Dv) for k in range(6))))
def exact_sign(d):
    """d = a + b*sqrt(q), a, b rational, q squarefree integer: exact sign via squares (no floating point)"""
    d = sp.expand(d); rad = [x for x in d.atoms(sp.Pow) if x.exp == sp.Rational(1, 2)]
    assert len(rad) <= 1, d
    if not rad: a, b, q = sp.Rational(d), 0, 0
    else:
        r_ = rad[0]; b = sp.Rational(d.coeff(r_)); a = sp.Rational(sp.expand(d - b*r_)); q = r_.base
    sa, sb = sp.sign(a), sp.sign(b)
    if sb == 0: return int(sa)
    if sa == 0: return int(sb)
    if sa == sb: return int(sa)
    return int(sa) if a*a > b*b*q else (int(sb) if a*a < b*b*q else 0)
def psd_minors(M):
    n = M.shape[0]; worst = None; zero = 0
    for k in range(1, n + 1):
        for idx in itertools.combinations(range(n), k):
            d = sp.radsimp(sp.expand(M.extract(list(idx), list(idx)).det()))
            sg = exact_sign(d)
            if sg == 0: zero += 1; continue
            if sg < 0: return False, idx, str(d)
    return True, None, zero
for Dv in (2, 4, 8, 16):
    yt, v = cert(Dv)
    coefS = [-1 - v[k] for k in range(6)]; coefS[4] += yt/24
    HS = Hm(TA, coefS, Dv).applyfunc(sp.expand); HW = Hm(TB, v, Dv).applyfunc(sp.expand)
    okS = psd_minors(HS); okW = psd_minors(HW)
    Z = Dv*(Dv+1)*(Dv+2)*(Dv+4)*(Dv+8)
    print(json.dumps(dict(D=Dv, lam=str(sp.radsimp(yt/Z)), HS_symmetric=HS == HS.T, HW_symmetric=HW == HW.T,
                          HS_psd=okS[0], HS_info=str(okS[1:]), HW_psd=okW[0], HW_info=str(okW[1:]),
                          rank_HS=HS.rank(simplify=True), rank_HW=HW.rank(simplify=True))), flush=True)
