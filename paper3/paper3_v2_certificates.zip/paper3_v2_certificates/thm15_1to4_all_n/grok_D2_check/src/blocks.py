"""Gate C: block conditions (exact). A ~ C + C + M_2 (charpoly of the regular representation, regrep.log).
S >= 0 iff s1, s2 >= 0 and the M_2-block has trace >= 0, det >= 0; same for W (valid for D >= 16 where G > 0)."""
import pickle, sympy as sp
from regrep import D, yt, v, t, LS, LW
R = pickle.load(open('../work/regrep.pkl', 'rb'))
def parts(cp_):
    lin, quad = [], None
    for fac, mult in sp.factor_list(cp_)[1]:
        deg = sp.degree(fac, t)
        if deg == 1: lin.append(sp.expand(-fac.subs(t, 0)/fac.coeff(t, 1)))   # the root
        else:
            q = sp.Poly(fac, t); a2, a1, a0 = q.all_coeffs(); quad = (sp.expand(-a1/a2), sp.expand(a0/a2))   # trace, det
    return lin, quad
linS, quadS = parts(R['cS']); linW, quadW = parts(R['cW'])
cond = dict(s_lin=linS, s_tr=quadS[0], s_det=quadS[1], w_lin=linW, w_tr=quadW[0], w_det=quadW[1])
if __name__ == '__main__':
    for k, val in cond.items(): print(k, '=', val)
    c = sp.Symbol('c'); ans = {v[0]: -sp.Rational(1, 2), v[3]: -sp.Rational(1, 2), v[1]: -sp.Rational(1, 2), v[2]: -c, v[4]: 4*c, v[5]: c - 1}
    print('--- ansatz v0=v1=v3=-1/2, v2=-c, v4=4c, v5=c-1 ---')
    for k, val in cond.items():
        if isinstance(val, list): print(k, [sp.factor(x.subs(ans)) for x in val])
        else: print(k, sp.factor(val.subs(ans)))
    pickle.dump(cond, open('../work/blocks.pkl', 'wb'))
