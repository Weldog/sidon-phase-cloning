"""PDF builder: a copy of r32/gateB/src/build_pdf.py (itself from r32/gateA) with paths changed (own code)."""
import markdown, weasyprint, re, html as H
src='/workspace/r32/gateC/gateC.md'; out='/workspace/r32/gateC/gateC.pdf'
md=open(src).read()
import re as _re
parts=_re.split(r'(```.*?```)',md,flags=_re.S)
for i in range(0,len(parts),2):
    parts[i]=_re.sub(r'(?m)^(?!\s*[-*]|\s*\d+\.|\s*$)(.+)\n(\s*(?:[-*]|\d+\.) )',r'\1\n\n\2',parts[i])
md=''.join(parts)
store=[]
def keep(m, display):
    t=m.group(1)
    if not display: t=t.replace('\\|','|')
    store.append((t,display)); return f'@@M{len(store)-1}@@'
_cp=_re.split(r'(```.*?```)',md,flags=_re.S)
for _i in range(0,len(_cp),2):
    _cp[_i]=re.sub(r'\$\$(.+?)\$\$', lambda m: keep(m,True), _cp[_i], flags=re.S)
    _cp[_i]=re.sub(r'(?<![\\$])\$([^$\n]+?)\$', lambda m: keep(m,False), _cp[_i])
md=''.join(_cp)
html=markdown.markdown(md, extensions=['tables','fenced_code','sane_lists'])
def restore(m):
    t,disp=store[int(m.group(1))]; e=H.escape(t)
    return f'<div class="dm">$${e}$$</div>' if disp else f'<span class="m">${e}$</span>'
html=re.sub(r'@@M(\d+)@@', restore, html)
css="""
@page { size: Letter; margin: 0.75in 0.7in; @bottom-center { content: counter(page); font-size: 9pt; color:#666; } }
body { font-family: 'DejaVu Serif', serif; font-size: 9.6pt; line-height: 1.4; color:#111; }
h1 { font-size: 18pt; color:#1a2a4a; margin-bottom: 4pt; }
h2 { font-size: 13.5pt; color:#1a2a4a; border-bottom: 1px solid #99a; padding-bottom:2pt; margin-top: 16pt; page-break-after: avoid; }
h3 { font-size: 11pt; color:#243a66; margin-top: 11pt; page-break-after: avoid; }
table { border-collapse: collapse; width: 100%; font-size: 7.4pt; margin: 7pt 0; }
th, td { border: 1px solid #bbb; padding: 2.5pt 3.5pt; vertical-align: top; word-wrap: break-word; }
th { background: #e8ecf4; }
tr { page-break-inside: avoid; }
.m { font-family: 'DejaVu Sans Mono', monospace; font-size: 0.86em; color:#123; }
.dm { font-family: 'DejaVu Sans Mono', monospace; font-size: 8.4pt; background:#f5f6fa; padding:4pt 6pt; margin:5pt 0; white-space: pre-wrap; word-break: break-all; }
code { font-family: 'DejaVu Sans Mono', monospace; font-size: 8.2pt; }
hr { border: 0; border-top: 1px solid #ccc; }
li { margin-bottom: 2pt; }
pre { white-space: pre-wrap; font-size: 6.6pt; background:#f7f7f7; padding:4pt; line-height:1.25; }
"""
doc=f"<html><head><meta charset='utf-8'><style>{css}</style></head><body>{html}</body></html>"
weasyprint.HTML(string=doc).write_pdf(out)
print('ok', len(store))
