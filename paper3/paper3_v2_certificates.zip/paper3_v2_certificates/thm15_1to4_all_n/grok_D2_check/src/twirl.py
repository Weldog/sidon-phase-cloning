"""Gate C / Q7: project the earlier exact W-certificates (n = 1: r29/g3/exact_cert_T1_k3.json; n = 2: r31/step2/certificates/
cert_n2_1to4.json; n = 3: r32/gateB/certificates/cert_n3_1to4.json; read-only) onto span{b'_k} = Gamma(A):
  y = G_B^{-1} h,  h_k = tr(b'_k^T W),  G_B[i,j] = tr(b'_i^T b'_j);  v = Z y  (floats -> OBSERVED).
Each file stores Wt = C^{-1} W C^{-1} in the occupation (Dicke) basis, C_p^2 = mult(c_b) (T = 1). With w'_rep one word of type c':
  W[p,p'] <p|b|p'> = Wt[p,p'] * mult(c') * sum_{w of type c} <a w| b |a' w'_rep>.
For n < 4 (D < 16) the projection equals the Clifford twirl only if the twirl lies in span{Gamma R(N)} (GNW Remark 4.2: spanning
below n = t-1 not proved) -> LV-C3. At D = 2 G_B is singular: least-squares (pseudo-inverse) coordinates, not unique."""
import json, pickle, math, itertools, numpy as np, sympy as sp
from fractions import Fraction
from relalg import xy, peval
W_ = pickle.load(open('../work/relalg_1to4.pkl', 'rb')); H = pickle.load(open('../work/hmats.pkl', 'rb')); B = W_['B']
def load(n):
    if n == 1:
        d = json.load(open('/workspace/r29/g3/exact_cert_T1_k3.json')); M = np.array([[float(sp.sympify(x)) for x in row] for row in d['W']])
        seed = [(1, 0), (0, 1)]; out = [(4 - l, l) for l in range(5)]; return seed, out, M
    f = {2: '/workspace/r31/step2/certificates/cert_n2_1to4.json', 3: '/workspace/r32/gateB/certificates/cert_n3_1to4.json'}[n]
    d = json.load(open(f)); dlt = d['d']; N_ = d['dims']['total']; M = np.zeros((N_, N_))
    for i, j, a, b in d['W_tilde_upper']:
        val = float(Fraction(a)) + float(Fraction(b))*math.sqrt(dlt); M[i, j] = val; M[j, i] = val
    return [tuple(x) for x in d['seed_basis_occupations']], [tuple(x) for x in d['output_basis_occupations']], M
def word_of(c): return tuple(x for x, k in enumerate(c) for _ in range(k))
def typ(w, Dv):
    c = [0]*Dv
    for x in w: c[x] += 1
    return tuple(c)
def run(n):
    Dv = 2**n; Z = Dv*(Dv+1)*(Dv+2)*(Dv+4)*(Dv+8)
    seed, out, Wt = load(n); d2 = len(out)
    pidx = {(seed.index(s_), out.index(o)): s_i*d2 + o_i for s_i, s_ in enumerate(seed) for o_i, o in enumerate(out) for _ in [0]}
    seedletter = [s_.index(1) for s_ in seed]
    tables = []
    for O in B['orbs']:
        tb = []
        for N in O:
            col = {}
            for vv in N:
                x, y = xy(vv); col.setdefault(y, []).append(x)
            tb.append(col)
        tables.append(tb)
    h = np.zeros(6)
    for ai, a in enumerate(seedletter):
        for ci, c in enumerate(out):
            pp = ai*d2 + ci; X = (a,) + word_of(c); mult_c = math.factorial(4)//math.prod(math.factorial(k) for k in c)
            Xq = [sum(((X[i] >> (n - 1 - q)) & 1) << (4 - i) for i in range(5)) for q in range(n)]
            colW = Wt[:, pp]
            if not np.any(colW): continue
            for k in range(6):
                acc = 0.0
                for col in tables[k]:
                    opts = [col.get(xq, []) for xq in Xq]
                    if any(len(o) == 0 for o in opts): continue
                    for ys in itertools.product(*opts):
                        Y = [sum(((ys[q] >> (4 - i)) & 1) << (n - 1 - q) for q in range(n)) for i in range(5)]
                        a2 = Y[0]
                        if a2 not in seedletter: continue
                        p = seedletter.index(a2)*d2 + out.index(typ(Y[1:], Dv))
                        acc += colW[p]
                h[k] += mult_c*acc
    G = np.array([[float(peval(H['GB'][B['star'][i]][j], Dv)) for j in range(6)] for i in range(6)])
    y = np.linalg.pinv(G) @ h; v = Z*y
    s = math.sqrt(Dv*Dv + 16*Dv + 1664); c = (Dv + 40 + s)/64
    return dict(n=n, D=Dv, h_OBSERVED=h.tolist(), G_rank=int(np.linalg.matrix_rank(G)), v_twirl_OBSERVED=v.tolist(),
                v_formula=[-0.5, -0.5, -c, -0.5, 4*c, c - 1], trace_W_OBSERVED=float(np.trace(Wt*0 + Wt) if False else 0))
if __name__ == '__main__':
    for n in (1, 2, 3):
        print(json.dumps(run(n)), flush=True)
