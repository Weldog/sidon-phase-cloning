"""Gate C: per-D dual SDP inside the 6-dim algebras (floats -> OBSERVED). Scaled variables: y = ytil / Z, u_k = v_k / Z,
Z = D(D+1)(D+2)(D+4)(D+8) (Paper 3 Lemma 3 / GNW eq. (5.3)); K = Z^{-1} sum_k b_k.
S Z = (ytil/24) b4 - sum_k b_k - sum_k v_k b_k (algebra A);  W Z = sum_k v_k b'_k (algebra B = Gamma(A)), v_0 = v_3 (Hermiticity)."""
import pickle, json, numpy as np, cvxpy as cp, math, sys
from relalg import peval
W_ = pickle.load(open('../work/relalg_1to4.pkl', 'rb')); H = pickle.load(open('../work/hmats.pkl', 'rb'))
TA, TB, GA, GB = H['TA'], H['TB'], H['GA'], H['GB']; A, B = W_['A'], W_['B']
r = 6
def lam_closed(D): return 3*(D + 48 + math.sqrt(D*D + 16*D + 1664))/(D*(D+1)*(D+2)*(D+4)*(D+8))
def solve(D, verbose=False):
    Z = D*(D+1)*(D+2)*(D+4)*(D+8)
    tA = np.array([[[float(peval(TA[i][k][j], D)) for j in range(r)] for k in range(r)] for i in range(r)])
    tB = np.array([[[float(peval(TB[i][k][j], D)) for j in range(r)] for k in range(r)] for i in range(r)])
    dA = np.array([float(peval(GA[A['star'][i]][i], D)) for i in range(r)]); dB = np.array([float(peval(GB[B['star'][i]][i], D)) for i in range(r)])
    sA = 1/np.sqrt(np.outer(dA, dA)); sB = 1/np.sqrt(np.outer(dB, dB))
    yt = cp.Variable(); v = cp.Variable(r)
    coefS = [-1 - v[k] for k in range(r)]; coefS[4] = coefS[4] + yt/24
    HS = sum(coefS[k]*(tA[:, k, :]*sA) for k in range(r)); HW = sum(v[k]*(tB[:, k, :]*sB) for k in range(r))
    cons = [v[0] == v[3], (HS + HS.T)/2 >> 0, (HW + HW.T)/2 >> 0]
    pr = cp.Problem(cp.Minimize(yt), cons); pr.solve(solver='CLARABEL')
    return dict(D=D, status=pr.status, value_OBSERVED=pr.value/Z, lam_closed=lam_closed(D), ratio_OBSERVED=pr.value/Z/lam_closed(D),
                ytil=pr.value, v=[float(x) for x in v.value])
if __name__ == '__main__':
    for n in range(1, 13):
        print(json.dumps(solve(2**n)), flush=True)
