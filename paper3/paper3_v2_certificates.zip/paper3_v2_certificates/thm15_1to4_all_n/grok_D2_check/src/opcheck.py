"""Gate C: operator-level check at n = 1, 2 (floats -> OBSERVED). Builds R(N) on (C^D)^{(x)5} (factor 0 = seed, first; no
conjugation), compares Z^{-1} sum R(N) with the stabilizer average (own BFS over H, S, CNOT), builds the D-formula certificate
W, S as operators, and reports eigenvalue extremes on range(P), P = I (x) P_sym^4.  Gamma = transpose of factor 0."""
import pickle, json, itertools, numpy as np, math
from relalg import xy
W_ = pickle.load(open('../work/relalg_1to4.pkl', 'rb')); A, B = W_['A'], W_['B']
def stab_states(n):
    d = 2**n; Hh = np.array([[1, 1], [1, -1]])/np.sqrt(2); Sg = np.diag([1, 1j])
    def one(g, j):
        ops = [np.eye(2)]*n; ops[j] = g; M = ops[0]
        for o in ops[1:]: M = np.kron(M, o)
        return M
    gens = [one(Hh, j) for j in range(n)] + [one(Sg, j) for j in range(n)]
    for a, b in itertools.permutations(range(n), 2):
        M = np.zeros((d, d))
        for x in range(d):
            bits = [(x >> (n - 1 - k)) & 1 for k in range(n)]; bits[b] ^= bits[a]
            y = sum(bit << (n - 1 - k) for k, bit in enumerate(bits)); M[y, x] = 1
        gens.append(M)
    def canon(v):
        k = np.argmax(np.abs(v) > 1e-9); v = v*np.conj(v[k])/abs(v[k]); return tuple(np.round(v, 8))
    v0 = np.zeros(d, complex); v0[0] = 1; seen = {canon(v0): v0}; fr = [v0]
    while fr:
        nf = []
        for v in fr:
            for g in gens:
                w = g @ v; key = canon(w)
                if key not in seen: seen[key] = w; nf.append(w)
        fr = nf
    return list(seen.values())
def Rop(N, n):
    r = np.zeros((32, 32))
    for vv in N: x, y = xy(vv); r[x, y] = 1
    # r indices: x bit (4-i) = copy i. Full operator on copies (0..4) each C^{2^n}, qubit j of copy i
    R = r
    for _ in range(n - 1): R = np.kron(R, r)
    # current tensor order: (qubit1: copies 0..4), (qubit2: copies 0..4), ... -> want (copy0: qubits), (copy1: qubits), ...
    t = R.reshape([2]*(10*n)); rows = [q*5 + i for i in range(5) for q in range(n)]; cols = [10*n//2 + q*5 + i for i in range(5) for q in range(n)]
    return t.transpose(rows + cols).reshape(32**n, 32**n)
def ptrans0(X, d):
    t = X.reshape(d, d**4, d, d**4); return t.transpose(2, 1, 0, 3).reshape(d**5, d**5)
for n in (1, 2):
    d = 2**n; Dv = d; Z = Dv*(Dv+1)*(Dv+2)*(Dv+4)*(Dv+8)
    bA = [sum(Rop(N, n) for N in O) for O in A['orbs']]; bB = [sum(Rop(N, n) for N in O) for O in B['orbs']]
    Kf = sum(bA)/Z
    st = stab_states(n); Ks = np.zeros((d**5, d**5), complex)
    for v in st:
        v5 = v
        for _ in range(4): v5 = np.kron(v5, v)
        Ks += np.outer(v5, v5.conj())
    Ks /= len(st)
    P = bA[4]/24
    gam_err = max(np.abs(ptrans0(bA[k], d) - bB[k]).max() for k in range(6))
    s = math.sqrt(Dv*Dv + 16*Dv + 1664); c = (Dv + 40 + s)/64; lam = 3*(Dv + 48 + s)/Z
    v = [-0.5, -0.5, -c, -0.5, 4*c, c - 1]
    Wop = sum(v[k]*bB[k] for k in range(6))/Z; Sop = lam*P - Kf - ptrans0(Wop, d)
    ev = lambda X: np.linalg.eigvalsh((X + X.T.conj())/2)
    # restrict to range(P)
    w, U = np.linalg.eigh(P); Q = U[:, w > 0.5]
    eS = ev(Q.T @ Sop @ Q); eW = ev(Q.T @ Wop @ Q); eK = ev(Q.T @ Kf @ Q)
    print(json.dumps(dict(n=n, num_stab=len(st), K_formula_maxerr_OBSERVED=float(np.abs(Kf - Ks).max()), P_is_projector_err=float(np.abs(P @ P - P).max()),
        gamma_map_err_OBSERVED=float(gam_err), dimP=int(Q.shape[1]), S_min_eig_OBSERVED=float(eS.min()), W_min_eig_OBSERVED=float(eW.min()),
        lam_OBSERVED=lam, lam_minus_maxeig_K_plus_GammaW_OBSERVED=float(lam - ev(Q.T @ (Kf + ptrans0(Wop, d)) @ Q).max()),
        lmaxK_times_Z_OBSERVED=float(eK.max()*Z))), flush=True)
