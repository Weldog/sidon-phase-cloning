"""Gate C: D-uniform certificate for 1->4 and its exact PSD proof for every D = 2^n >= 16 (n >= 4); exact sympy.
Certificate (scaled by Z = D(D+1)(D+2)(D+4)(D+8)):  s := sqrt(D^2 + 16 D + 1664),  c := (D + 40 + s)/64,
  ytil = Z*lam = 3 (D + 48 + s),  v0 = v1 = v3 = -1/2,  v2 = -c,  v4 = 4c,  v5 = c - 1;
  Z*W = sum_k v_k b'_k  (b'_k = Gamma(b_k)),   Z*S = (ytil/24) b4 - sum_k b_k - sum_k v_k b_k,   S = lam P - K - Gamma(W).
Signs: every block quantity reduces (mod s^2 = D^2+16D+1664) to p(D) + q(D) s; with u = D - 16 >= 0 and D + 8 < s < D + 48
(since (D+8)^2 + 1600 = s^2 and (D+48)^2 - s^2 = 80 D + 640 > 0) we prove the sign exactly."""
import pickle, json, sympy as sp
from regrep import D, yt, v
cond = pickle.load(open('../work/blocks.pkl', 'rb'))
s, u = sp.symbols('s u', positive=True)
DISC = D**2 + 16*D + 1664
c = (D + 40 + s)/64
cert = {yt: 3*(D + 48 + s), v[0]: -sp.Rational(1, 2), v[1]: -sp.Rational(1, 2), v[3]: -sp.Rational(1, 2), v[2]: -c, v[4]: 4*c, v[5]: c - 1}
def red(e):
    """reduce polynomial in s modulo s^2 - DISC -> (p, q) with e = p + q s"""
    e = sp.expand(e); P_ = sp.Poly(e, s); p, q = 0, 0
    for (k,), co in P_.terms():
        base = DISC**(k//2)
        if k % 2: q += co*base
        else: p += co*base
    return sp.expand(p), sp.expand(q)
def coeffs_nonneg(e):
    P_ = sp.Poly(sp.expand(e.subs(D, u + 16)), u); return all(x >= 0 for x in P_.coeffs()), P_.as_expr()
def sign_report(name, e):
    p, q = red(e)
    out = dict(name=name, p=str(sp.factor(p)), q=str(sp.factor(q)))
    if p == 0 and q == 0: out['verdict'] = 'IDENTICALLY 0'; return out
    # cases: p, q >= 0 on D >= 16 -> >= 0;  else use s bounds
    pn, _ = coeffs_nonneg(p); qn, _ = coeffs_nonneg(q)
    if pn and qn: out['verdict'] = '>= 0 (p, q have nonneg coeffs in u = D - 16)'; return out
    # p + q s with q >= 0: >= p + q (D+8);   q <= 0: >= p + q (D+48)
    for bnd, qsign in (((D + 8), 1), ((D + 48), -1)):
        okq, _ = coeffs_nonneg(qsign*q)
        if okq:
            ok, poly = coeffs_nonneg(p + q*bnd)
            if ok: out['verdict'] = '>= 0 via s %s %s and nonneg coeffs of p + q*(%s) in u' % ('>' if qsign > 0 else '<', bnd, bnd); return out
    # p + q s with opposite signs: compare squares
    out['verdict'] = 'UNDECIDED by simple bounds'; return out
if __name__ == '__main__':
    print(json.dumps(dict(certificate={str(k): str(val) for k, val in cert.items()})))
    rep = []
    for k, val in cond.items():
        vals = val if isinstance(val, list) else [val]
        for i, e in enumerate(vals):
            r_ = sign_report('%s[%d]' % (k, i), e.subs(cert)); rep.append(r_); print(json.dumps(r_), flush=True)
    # trace-form nondegeneracy, independent of GNW: det G_A, det G_B as polynomials in D
    H = pickle.load(open('../work/hmats.pkl', 'rb')); W_ = pickle.load(open('../work/relalg_1to4.pkl', 'rb'))
    def P(p): return sum(val*D**k for k, val in p.items())
    for name, G, Alg in (('A', H['GA'], W_['A']), ('B', H['GB'], W_['B'])):
        M = sp.Matrix(6, 6, lambda i, j: P(G[Alg['star'][i]][j]))      # G_ij = tr(b_i^T b_j) = tr(b_{i*} b_j)
        dG = sp.factor(M.det()); print(json.dumps(dict(trace_form=name, symmetric=bool(sp.simplify(M - M.T) == sp.zeros(6)), det=str(dG),
              det_at_D={str(d): str(dG.subs(D, d)) for d in (2, 4, 8, 16)})), flush=True)
