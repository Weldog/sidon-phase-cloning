"""Gate C: width of the optimal face inside the algebra (floats -> OBSERVED). Fix ytil = Z*lam(D) (+ relative slack eps) and
min/max each v_k subject to the block conditions via the H-criterion SDP of algsdp.py."""
import json, numpy as np, cvxpy as cp, math
from algsdp import TA, TB, GA, GB, A, B, r, peval
def face(D, eps=1e-7):
    Z = D*(D+1)*(D+2)*(D+4)*(D+8); yt0 = 3*(D + 48 + math.sqrt(D*D + 16*D + 1664))
    tA = np.array([[[float(peval(TA[i][k][j], D)) for j in range(r)] for k in range(r)] for i in range(r)])
    tB = np.array([[[float(peval(TB[i][k][j], D)) for j in range(r)] for k in range(r)] for i in range(r)])
    dA = np.array([float(peval(GA[A['star'][i]][i], D)) for i in range(r)]); dB = np.array([float(peval(GB[B['star'][i]][i], D)) for i in range(r)])
    sA = 1/np.sqrt(np.outer(dA, dA)); sB = 1/np.sqrt(np.outer(dB, dB))
    v = cp.Variable(r); yt = yt0*(1 + eps)
    coefS = [-1 - v[k] for k in range(r)]; coefS[4] = coefS[4] + yt/24
    HS = sum(coefS[k]*(tA[:, k, :]*sA) for k in range(r)); HW = sum(v[k]*(tB[:, k, :]*sB) for k in range(r))
    cons = [v[0] == v[3], (HS + HS.T)/2 >> 0, (HW + HW.T)/2 >> 0]
    out = {}
    for k in (0, 1, 2, 4, 5):
        lo = cp.Problem(cp.Minimize(v[k]), cons); lo.solve(solver='CLARABEL'); hi = cp.Problem(cp.Maximize(v[k]), cons); hi.solve(solver='CLARABEL')
        out['v%d' % k] = [lo.value, hi.value]
    s = math.sqrt(D*D + 16*D + 1664); c = (D + 40 + s)/64
    return dict(D=D, eps=eps, ranges_OBSERVED=out, formula=dict(v0=-0.5, v1=-0.5, v2=-c, v4=4*c, v5=c - 1))
if __name__ == '__main__':
    for D in (2, 4, 8, 16, 64, 1024):
        print(json.dumps(face(D)), flush=True)
