"""Gate C: left-regular representation of the 6-dim algebras A (S lives here) and B = Gamma(A) (W lives here); exact sympy.
For n >= 4 (D >= 16) the b_O are linearly independent (GNW Lemma 4.5 + disjoint orbits), the trace form G_ij = tr(b_i^T b_j) is
positive definite, and X >= 0 on range(P) iff every eigenvalue of L_X (G-self-adjoint) is >= 0 (CA (own))."""
import pickle, json, sympy as sp
W_ = pickle.load(open('../work/relalg_1to4.pkl', 'rb'))
D = sp.Symbol('D', positive=True); yt = sp.Symbol('ytil'); v = sp.symbols('v0:6'); t = sp.Symbol('t')
def P(p): return sum(val*D**k for k, val in p.items())
r = 6
def L(Alg, coef):
    f = Alg['f']; M = sp.zeros(r, r)
    for i in range(r):
        for k in range(r):
            for l, p in f[i][k].items(): M[l, k] += coef[i]*P(p)
    return M.applyfunc(sp.expand)
A, B = W_['A'], W_['B']
coefS = [-1 - v[k] for k in range(r)]; coefS[4] += yt/24        # Z*S = (ytil/24) b4 - sum b_k - sum v_k b_k
LS = L(A, coefS); LW = L(B, list(v)); LK = L(A, [1]*r)
if __name__ == '__main__':
    sub = {v[3]: v[0]}
    cK = sp.factor(LK.charpoly(t).as_expr()); print('charpoly(L_{ZK}) =', cK, flush=True)
    cS = sp.factor(LS.subs(sub).charpoly(t).as_expr()); print('charpoly(L_{ZS}) =', cS, flush=True)
    cW = sp.factor(LW.subs(sub).charpoly(t).as_expr()); print('charpoly(L_{ZW}) =', cW, flush=True)
    GA = sp.Matrix(r, r, lambda i, j: 0)
    pickle.dump(dict(LS=LS, LW=LW, LK=LK, cS=cS, cW=cW, cK=cK), open('../work/regrep.pkl', 'wb'))
