"""Assemble gateC.md from gateC_body.md + addendum + logs (verbatim) + scripts (verbatim) (own code)."""
import os
C = '/workspace/r32/gateC'; out = [open(f'{C}/gateC_body.md').read()]
out += ['```', open(f'{C}/logs/integrity_check.log').read().strip(), '```',
        'sha256_prior_before_gateC.txt = sha256_prior_after_gateC.txt (byte-identical files, 463 entries); both are in the zip.\n',
        '## 10. Addendum C0 (verbatim copy of addendum_gateB_negctrl.md)\n', open(f'{C}/addendum_gateB_negctrl.md').read(),
        '\n## 11. Logs (verbatim)\n']
for f in ['predictions_hash.log', 'logs/predictions_reverify.log', 'logs/c0_inputs_sha256.log', 'logs/relalg.log', 'logs/hmats.log',
          'logs/algsdp.log', 'logs/regrep.log', 'logs/blocks.log', 'logs/proof_all_D.log', 'logs/finite_D_check.log', 'logs/opcheck.log',
          'logs/face.log', 'logs/twirl.log', 'logs/twirl_resid.log', 'logs/twirl_n1_dist.log']:
    out += [f'### {f}', '```', open(f'{C}/{f}').read().rstrip(), '```']
out.append('\n## 12. Scripts (verbatim)\n')
for f in ['relalg.py', 'hmats.py', 'algsdp.py', 'regrep.py', 'blocks.py', 'proof_all_D.py', 'finite_D_check.py', 'opcheck.py', 'face.py',
          'twirl.py', 'twirl_resid.py', 'twirl_n1_dist.py', 'symb.py', 'make_gateC.py', 'build_pdf.py']:
    out += [f'### src/{f}', '```', open(f'{C}/src/{f}').read().rstrip(), '```']
out.append('\n(src/symb.py was an exploratory script whose run was stopped after printing H_S under the ansatz; its rank step was too slow, and it was superseded by regrep.py. Its partial output is not used for any claim. OBSERVED.)')
open(f'{C}/gateC.md', 'w').write('\n'.join(out) + '\n'); print('ok')
