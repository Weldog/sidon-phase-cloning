"""Gate C: H-matrices (polynomials in D) for the 6-orbit compressed algebras (own code).
PSD criterion (own lemma, CA (own)): for a *-algebra spanned by b_0..b_{r-1} (possibly linearly dependent) containing the unit P of
range(P), a Hermitian X in it satisfies X >= 0 on range(P) iff H_X[i,j] = tr(b_i^T X b_j) is PSD (real symmetric here)."""
import pickle, json, sympy as sp
from relalg import padd, pmul
W = pickle.load(open('../work/relalg_1to4.pkl', 'rb'))
Dsym = sp.Symbol('D', positive=True)
def topoly(p): return sum(v*Dsym**k for k, v in p.items())
def T3(Alg):
    r = len(Alg['orbs']); f, tr, star = Alg['f'], Alg['tr'], Alg['star']
    G = [[{} for _ in range(r)] for _ in range(r)]
    for l in range(r):
        for j in range(r):
            acc = {}
            for m_, c in f[l][j].items(): acc = padd(acc, pmul(c, tr[m_]))
            G[l][j] = acc
    out = [[[{} for _ in range(r)] for _ in range(r)] for _ in range(r)]
    for i in range(r):
        for k in range(r):
            for j in range(r):
                acc = {}
                for l, c in f[star[i]][k].items(): acc = padd(acc, pmul(c, G[l][j]))
                out[i][k][j] = acc
    return G, out
A, B, gam = W['A'], W['B'], W['gam']
GA, TA = T3(A); GB, TB = T3(B)
def describe(Alg, name):
    for l, O in enumerate(Alg['orbs']):
        N = O[0]
        print(json.dumps(dict(alg=name, orbit=l, size=len(O), star=Alg['star'][l], trace=str(sp.factor(topoly(Alg['tr'][l]))),
                              rep=sorted('%05d|%05d' % (int(bin(v >> 5)[2:]), int(bin(v & 31)[2:])) for v in N))))
describe(A, 'A'); describe(B, 'B')
print(json.dumps(dict(gamma_orbit_map=gam)))
for name, Alg in (('A', A), ('B', B)):
    r = len(Alg['orbs'])
    for i in range(r):
        for k in range(r):
            print(json.dumps(dict(alg=name, prod='b%d*b%d' % (i, k), equals={'b%d' % l: str(sp.factor(topoly(c))) for l, c in sorted(Alg['f'][i][k].items())})))
pickle.dump(dict(GA=GA, TA=TA, GB=GB, TB=TB), open('../work/hmats.pkl', 'wb'))
