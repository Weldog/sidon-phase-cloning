"""Gate C / Q7 addendum: at D = 2 (G_B rank 5) compare the projected n = 1 certificate with the formula as operators:
||W_twirl - W_formula||_F^2 = (dv)^T G_B (dv) / Z^2, relative to ||W_formula||_F^2 (floats -> OBSERVED)."""
import json, pickle, numpy as np
from relalg import peval
H = pickle.load(open('../work/hmats.pkl', 'rb')); B = pickle.load(open('../work/relalg_1to4.pkl', 'rb'))['B']
G = np.array([[float(peval(H['GB'][B['star'][i]][j], 2)) for j in range(6)] for i in range(6)])
L = [json.loads(l) for l in open('../logs/twirl.log') if l.startswith('{')]
r = [x for x in L if x['n'] == 1][0]; vt = np.array(r['v_twirl_OBSERVED']); vf = np.array(r['v_formula']); dv = vt - vf
w, U = np.linalg.eigh(G); ker = U[:, np.abs(w) < 1e-9*abs(w).max()]
print(json.dumps(dict(rel_frobenius_dist_OBSERVED=float(np.sqrt(dv @ G @ dv / (vf @ G @ vf))), kernel_G_B_at_D2=ker.ravel().tolist())))
