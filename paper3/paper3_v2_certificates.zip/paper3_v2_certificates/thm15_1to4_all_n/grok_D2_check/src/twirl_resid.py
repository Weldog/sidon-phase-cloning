"""Gate C / Q7: is each earlier W itself in span{b'_k}? residual^2 = ||W||_F^2 - y^T G_B y  (orthogonal projection, floats -> OBSERVED).
||W||_F^2 = sum Wt[p,p']^2 mult(c_p) mult(c_p') (W = C Wt C, C_p^2 = mult(c_p))."""
import json, math, pickle, numpy as np
from twirl import load
from relalg import peval
H = pickle.load(open('../work/hmats.pkl', 'rb')); B = pickle.load(open('../work/relalg_1to4.pkl', 'rb'))['B']
L = {x['n']: x for x in (json.loads(l) for l in open('../logs/twirl.log') if l.startswith('{'))}
for n in (1, 2, 3):
    Dv = 2**n; Z = Dv*(Dv+1)*(Dv+2)*(Dv+4)*(Dv+8); seed, out, Wt = load(n)
    mult = np.array([math.factorial(4)//math.prod(math.factorial(k) for k in c) for _ in seed for c in out], float)
    nW2 = float(np.sum(Wt**2*np.outer(mult, mult)))
    G = np.array([[float(peval(H['GB'][B['star'][i]][j], Dv)) for j in range(6)] for i in range(6)])
    y = np.array(L[n]['v_twirl_OBSERVED'])/Z; nP2 = float(y @ G @ y)
    print(json.dumps(dict(n=n, normW2_OBSERVED=nW2, normProj2_OBSERVED=nP2, rel_residual_OBSERVED=math.sqrt(max(nW2 - nP2, 0)/nW2))))
