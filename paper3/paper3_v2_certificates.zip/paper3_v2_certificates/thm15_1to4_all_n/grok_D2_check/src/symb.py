"""Gate C: symbolic H_S, H_W in (D, ytil, v) (exact, sympy)."""
import pickle, json, sympy as sp
W_ = pickle.load(open('../work/relalg_1to4.pkl', 'rb')); H = pickle.load(open('../work/hmats.pkl', 'rb'))
D = sp.Symbol('D', positive=True); yt = sp.Symbol('ytil'); v = sp.symbols('v0:6'); c = sp.Symbol('c')
def P(p): return sum(val*D**k for k, val in p.items())
r = 6
def Hmat(T, coef): return sp.Matrix(r, r, lambda i, j: sp.expand(sum(coef[k]*P(T[i][k][j]) for k in range(r))))
coefS = [-1 - v[k] for k in range(r)]; coefS[4] += yt/24
HS = Hmat(H['TA'], coefS); HW = Hmat(H['TB'], list(v))
if __name__ == '__main__':
    print('HS symmetric:', sp.simplify(HS - HS.T.subs({v[0]: v[3], v[3]: v[0]})) == sp.zeros(r) )
    ans = {v[0]: -sp.Rational(1, 2), v[3]: -sp.Rational(1, 2), v[1]: -sp.Rational(1, 2), v[2]: -c, v[4]: 4*c, v[5]: c - 1}
    hs = HS.subs(ans).applyfunc(sp.factor); hw = HW.subs(ans).applyfunc(sp.factor)
    print('HS(ansatz) ='); sp.pprint(hs, wrap_line=False)
    print('HW(ansatz) ='); sp.pprint(hw, wrap_line=False)
    print('rank HS generic', hs.rank(), 'rank HW generic', hw.rank())
    pickle.dump(dict(HS=HS, HW=HW), open('../work/symb.pkl', 'wb'))
