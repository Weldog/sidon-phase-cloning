"""R13d Gate C: relation algebra for 1->4 (T = 1, m = 4, s = 5), every n at once (own code).
Relations N = t-dimensional subspaces of F_2^5 (+) F_2^5, elements (x, y) encoded as v = (x << 5) | y; coordinate i of x is bit (4 - i).
Coordinate 0 = the seed copy (FIRST factor, R1-01); coordinates 1..4 = the m = 4 output copies.
Sigma = Sigma_{5,5}: |x| = |y| mod 4 on N, dim N = 5, 1_{10} in N (GNW arXiv:1712.08628 Def. Sigma_{t,t}; Paper 3 Def. 2).
R(N) = r(N)^{(x)n}, r(N) = sum_{(x,y) in N} |x><y| (GNW Sec. 1.2 / 4.1; Paper 3 Def. 2).
Composition (Paper 3 Lemma 4): R(N1) R(N2) = D^{d} R(N1 o N2), d = dim(N_R(N1) cap N_L(N2)).
Trace: tr R(N) = D^{dim{x : (x,x) in N}}.  Transpose: R(N)^T = R(N^T).
Gamma (transpose of the seed factor = coordinate 0, in the computational basis): Gamma R(N) = R(swap0(N)), swap0 exchanges x_0 <-> y_0.
Compression P = I (x) P_sym^4 = (1/24) sum_pi R(pi) (pi permuting coordinates 1..4): basis b_O = sum_{N in O} R(N) over orbits O of
S_4 x S_4 acting on the x- and y-coordinates 1..4; P R(N) P = b_O / |O|.  Polynomials in D are dicts {exponent: integer}."""
import itertools, json, sys, pickle
from collections import Counter

T_ = 5
FULL = (1 << 10) - 1
def wt(x): return bin(x).count('1')
def xy(v): return v >> 5, v & 31
def mk(x, y): return (x << 5) | y

def span(vecs):
    s = {0}
    for v in vecs:
        if v not in s: s |= {u ^ v for u in s}
    return frozenset(s)

def iso(v):
    x, y = xy(v); return (wt(x) - wt(y)) % 4 == 0

def sigma():
    """all 5-dim totally isotropic subspaces containing 1_10 (DFS over spans)"""
    start = span([FULL]); assert all(iso(v) for v in start)
    seen = {start}; frontier = [start]; out = set()
    while frontier:
        nxt = []
        for S in frontier:
            for v in range(1 << 10):
                if v in S or not iso(v): continue
                S2 = frozenset(S | {u ^ v for u in S})
                if S2 in seen: continue
                if all(iso(u) for u in S2):
                    seen.add(S2)
                    if len(S2) == 32: out.add(S2)
                    else: nxt.append(S2)
        frontier = nxt
    return sorted(out, key=lambda S: sorted(S))

def compose(N1, N2):
    """(N1 o N2, d) with R(N1)R(N2) = D^d R(N1 o N2)"""
    byleft = {}
    for v in N2:
        y, z = xy(v); byleft.setdefault(y, []).append(z)
    out = set()
    for v in N1:
        x, y = xy(v)
        for z in byleft.get(y, ()): out.add(mk(x, z))
    k = sum(1 for v in N1 if xy(v)[0] == 0 and mk(xy(v)[1], 0) in N2)
    d = k.bit_length() - 1; assert 1 << d == k
    return frozenset(out), d

def fixdim(N):
    k = sum(1 for v in N if xy(v)[0] == xy(v)[1]); d = k.bit_length() - 1; assert 1 << d == k; return d
def transpose(N): return frozenset(mk(xy(v)[1], xy(v)[0]) for v in N)
def swap0(N):
    out = set()
    for v in N:
        x, y = xy(v); bx, by = (x >> 4) & 1, (y >> 4) & 1
        out.add(mk((x & 15) | (by << 4), (y & 15) | (bx << 4)))
    return frozenset(out)
def permx(perm, x):
    """perm: tuple of the images of coordinates 1..4 (as 1..4); coordinate i is bit 4-i"""
    out = x & 16
    for i in range(1, 5):
        if (x >> (4 - i)) & 1: out |= 1 << (4 - perm[i - 1])
    return out
PERMS = list(itertools.permutations(range(1, 5)))
def act(p, q, N): return frozenset(mk(permx(p, xy(v)[0]), permx(q, xy(v)[1])) for v in N)

def padd(a, b, s=1):
    c = Counter(a)
    for k, v in b.items(): c[k] += s*v
    return {k: v for k, v in c.items() if v}
def pmul(a, b):
    c = Counter()
    for k1, v1 in a.items():
        for k2, v2 in b.items(): c[k1 + k2] += v1*v2
    return {k: v for k, v in c.items() if v}
def peval(a, D): return sum(v*D**k for k, v in a.items())

def build(rels):
    """orbits of S_4 x S_4 on a family rels (closed under the action), structure constants, traces."""
    rels = list(rels); idx = {N: i for i, N in enumerate(rels)}
    orb_of = [-1]*len(rels); orbs = []
    for i, N in enumerate(rels):
        if orb_of[i] >= 0: continue
        O = {act(p, q, N) for p in PERMS for q in PERMS}
        assert all(M in idx for M in O), 'family not closed under S4 x S4'
        for M in O: orb_of[idx[M]] = len(orbs)
        orbs.append(sorted(O, key=lambda S: sorted(S)))
    r = len(orbs); reps = [O[0] for O in orbs]
    star = [orb_of[idx[transpose(O[0])]] for O in orbs]
    # structure constants: b_i b_k = sum_l f[i][k][l] b_l  (coefficient on the representative of l)
    f = [[{} for _ in range(r)] for _ in range(r)]; closed = True
    rep_index = {rep: l for l, rep in enumerate(reps)}
    for i in range(r):
        for k in range(r):
            acc = {}
            for N1 in orbs[i]:
                for N2 in orbs[k]:
                    C, d = compose(N1, N2)
                    if C not in idx: closed = False; continue
                    if C in rep_index: acc.setdefault(rep_index[C], Counter())[d] += 1
            f[i][k] = {l: dict(c) for l, c in acc.items()}
    tr = [Counter() for _ in range(r)]
    for l, O in enumerate(orbs):
        for N in O: tr[l][fixdim(N)] += 1
    tr = [dict(c) for c in tr]
    return dict(orbs=orbs, reps=reps, star=star, f=f, tr=tr, closed=closed, sizes=[len(O) for O in orbs])

if __name__ == '__main__':
    import time; t0 = time.time()
    S = sigma(); print(json.dumps(dict(stage='sigma', count=len(S), secs=round(time.time() - t0, 1))), flush=True)
    Sset = set(S)
    assert all(transpose(N) in Sset for N in S)
    A = build(S)
    print(json.dumps(dict(stage='algebra_A', orbits=len(A['orbs']), sizes=A['sizes'], closed_under_composition=A['closed'],
                          secs=round(time.time() - t0, 1))), flush=True)
    Sw = [swap0(N) for N in S]; assert len(set(Sw)) == 270
    Swset = set(Sw); assert all(transpose(N) in Swset for N in Sw)
    B = build(Sw)
    # orbit correspondence: swap0 commutes with the S4 x S4 action, so orbit O of Sigma maps to orbit swap0(O)
    Bindex = {frozenset(O2): l for l, O2 in enumerate(map(frozenset, B['orbs']))}
    gam = [Bindex[frozenset(swap0(N) for N in O)] for O in A['orbs']]
    print(json.dumps(dict(stage='algebra_B', orbits=len(B['orbs']), sizes=B['sizes'], closed_under_composition=B['closed'],
                          gamma_orbit_map_is_bijection=len(set(gam)) == len(gam), secs=round(time.time() - t0, 1))), flush=True)
    pickle.dump(dict(S=S, A=A, B=B, gam=gam), open('../work/relalg_1to4.pkl', 'wb'))
