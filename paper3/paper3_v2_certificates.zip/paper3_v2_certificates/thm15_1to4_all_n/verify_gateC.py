# Claude's independent check of Grok's Gate C certificate, on the algebra rebuilt in alg_1to4.py
import pickle, sympy as sp, itertools, mpmath as mp
exec(open('alg_1to4.py').read().split("D=sp.Symbol")[0])     # reuse ONLY the enumeration/orbit code (no Grok code)
G=pickle.load(open('alg.pkl','rb')); D=sp.Symbol('D',positive=True)
CA,CB=G['CA'],G['CB']
# identify Grok's labels: b4 = identity orbit; b1 = size-6 orbit; b5 = orbit containing the transposition (0 1) graph
def perm_graph(p):   # p: permutation of 0..4 as tuple
    def ap(x): return sum(((x>>i)&1)<<p[i] for i in range(5))
    return frozenset(pack(ap(x),x) for x in range(32))
tr01=perm_graph((1,0,2,3,4)); k5=orb[idx[tr01]]
sizes=G['sizes']; k4=G['k_id']; k1=sizes.index(6)
k2=[k for k in range(6) if sizes[k]==96 and k!=k5][0]
k0,k3=[k for k in range(6) if sizes[k]==24 and k!=k4]
lab={k0:0,k1:1,k2:2,k3:3,k4:4,k5:5}       # mine -> Grok's label (b0/b3 are a transpose pair, used symmetrically)
inv={v:k for k,v in lab.items()}
print("my orbit -> Grok label:",lab)
s=sp.Symbol('s',positive=True)
c=(D+40+s)/64; lam=3*(D+48+s)            # Z*lambda
# Z*W in B-basis (Grok labels), Z*S in A-basis
ZW={0:-sp.Rational(1,2),1:-sp.Rational(1,2),3:-sp.Rational(1,2),2:-c,4:4*c,5:c-1}
ZS={4:lam/24-1-4*c,0:-sp.Rational(1,2),1:-sp.Rational(1,2),3:-sp.Rational(1,2),2:c-1,5:-c}
def Lmat(C,x):   # left multiplication by X = sum_i x_i b_i (Grok labels) in my basis order
    M=sp.zeros(6,6)
    for g,xi in x.items():
        i=inv[g]
        for j in range(6):
            for k in range(6): M[k,j]+=xi*C[i][j][k]
    return M
LW=Lmat(CB,ZW); LS=Lmat(CA,ZS)
# unit check: b4/24 acts as identity in both algebras
print("b4/24 is the unit:", sp.simplify(Lmat(CA,{4:sp.Rational(1,24)})-sp.eye(6))==sp.zeros(6,6), sp.simplify(Lmat(CB,{4:sp.Rational(1,24)})-sp.eye(6))==sp.zeros(6,6))
# Gram determinant (independence) in algebra A: G_ij = tr(b_i^T b_j)
TA=G['TA']; trA=G['trA']
def tr_of(C,tr,x):   # trace of sum_k x_k b_k
    return sum(xk*tr[k] for k,xk in x.items())
Gm=sp.zeros(6,6)
for i in range(6):
    for j in range(6):
        prod={k:CA[TA[i]][j][k] for k in range(6)}           # b_i^T b_j = b_{T(i)} b_j
        Gm[i,j]=sp.expand(sum(prod[k]*trA[k] for k in range(6)))
detG=sp.factor(Gm.det()); print("det G_A =",detG)
# numeric eigenvalues of L_W, L_S at many D (50-digit precision), with s = sqrt(D^2+16D+1664)
mp.mp.dps=50
worst=[]
for n in list(range(1,21)):
    Dv=2**n; sv=mp.sqrt(Dv*Dv+16*Dv+1664)
    sub={D:Dv,s:sv}
    lw=mp.matrix(LW.subs(sub).evalf(60).tolist()); ls=mp.matrix(LS.subs(sub).evalf(60).tolist())
    ew=[mp.re(e) for e in mp.eig(lw)[0]]; es=[mp.re(e) for e in mp.eig(ls)[0]]
    worst.append((n,float(min(ew)),float(min(es)),float(max(ew)),float(max(es))))
for w in worst: print("n=%2d  min eig L_ZW = %+.3e  min eig L_ZS = %+.3e   (max %.3e, %.3e)"%w)
