# Certificates and checkers for "Exact Optimal Cloning of Stabilizer States, and the Price of Measuring First" (v2)

Every certificate is exact (rational or quadratic-field arithmetic) unless marked numeric.
Requirements: Python 3 with numpy, scipy, sympy, mpmath. `MANIFEST_SHA256.txt` lists the SHA-256 of every file.

## Runners
- `./run_all.sh` re-runs every bundled check at sizes that fit in about 1 GB of memory per process (it runs the n = 3
  certificates for 1→4 and 1→5, the Bell checker F1 for n ≤ 3 and F2 in `--quick` mode).
- `run_full_checks.ps1` (Windows PowerShell; or run the same three commands by hand) runs the three larger checks:
  `fresh_checker_n3.py certificates/cert_n3_2to4.json`, `check_gateF1.py --n4-range`, `check_gateF2.py`.
- Both judge a check as PASS only if it exits with status 0 AND its log contains the expected success marker, print
  PASS/FAIL per check, and exit with status 1 if any check fails.
- Not bundled: the exhaustive stabilizer-output search for Proposition 19 at n = 1 (m = 4, 5).

| Paper item | Folder / command | What it checks | Producer · independent check |
|---|---|---|---|
| Part I (Thm 10, Cor 11) | `part1/paper3_code.zip` | v1 bundle (unchanged) | as in v1 |
| Thm 14 (seed values, m = 4) | `thm14_seed_values/`: `m4_classify.py`, `m4_types.py`, `s0_boundary.py` | 902 isotropic subspaces, 0 violations; dominance inequalities (all coefficients ≥ 0); boundary D = 2^k | Grok Bot (scripts transcribed verbatim from its report) · GPT re-enumerated and recomputed |
| Thm 15 (1→4, every n), D ≥ 4 | `thm15_1to4_all_n/`: `alg_1to4.py`, then `verify_gateC.py`, `verify_gateC_charpoly.py` | algebra rebuilt from the definitions; Gram determinant; characteristic polynomials t³(t−α)(t−τ)² | Grok Bot certificate · Claude rebuilt independently; GPT re-derived |
| Thm 15, lower bound | `thm15_1to4_all_n/claude_gateC_sandwich.py` | λ(D) is the larger root of the 2×2 compression, every D | Claude · GPT |
| Thm 15, D = 2 | `thm15_1to4_all_n/grok_D2_check/src/finite_D_check.py` | H-matrices PSD at D = 2, 4, 8, 16 | Grok Bot · GPT (63 exact minors in Q(√17)) |
| Thm 18, n = 1 | `thm18_2to4/n1/claude_cert_checker.py` | six exact PPT dual certificates; negative control | Grok Bot · Claude's checker |
| Thm 18, n = 2 | `thm18_2to4/n2/claude_checker_n2.py` | seven certificates; states regenerated independently | Grok Bot · Claude's checker |
| Thm 18, n = 3 | `thm18_2to4/n3/fresh_checker_n3.py certificates/cert_n3_*.json` | three certificates (2→4 at dimension 11,880) | Grok Bot (its own checker, included) · GPT's separate checker (reported) |
| Thm 18, n ≥ 4 | `thm18_2to4/all_D/check_gateF3.py`; `rebuild_t6.py` | 21-dimensional algebras, dual for every D ≥ 16; all 4590 relations and every structure constant regenerated | Grok Bot · Claude (0 mismatches); GPT re-ran |
| Prop 17 (Bell sampling) | `prop17_bell/check_gateF1.py`, `check_gateF2.py`, `claude_bell_sampling_n4.py` | outcome structure; per-outcome value g(D); n = 4 value 1/96 (numeric, Lanczos) | Grok Bot · GPT line by line; Claude numeric |
| Prop 19, n = 1 search (m = 4, 5) | **not bundled** (reported in the R13b round) | exhaustive stabilizer-output search | Grok Bot · m = 4 reproduced numerically by GPT; m = 5 not re-verified |

Paths inside scripts written by Claude were made relative for this bundle; no logic was changed.

## Clean runs (24 Oct 2026) — sandbox (4 GB RAM, 1 CPU) and the author's Windows PC (`run_full_checks.ps1`); results in `logs_expected/`
| Check | Result |
|---|---|
| thm14 classify / types / boundary | 902 subspaces, 0 violations; every coefficient ≥ 0; boundary positive |
| thm15 algebra, numeric spectra (n = 1–20), exact characteristic polynomials, sandwich, Grok D = 2/4/8/16 | all pass |
| thm18 n = 1 (6 certificates + negative control) | all pass; negative control rejected |
| thm18 n = 2 (7 certificates) | all pass |
| thm18 n = 3 | 1→4 and 1→5 pass in the sandbox (`thm18_n3_small.log`); **2→4 (dimension 11,880) passes on the author's PC** (6 min; `logs_expected/author_pc_run/`); also passed in the producer's run and GPT's independent checker |
| thm18 all-D: Claude rebuild of every structure constant | 0 mismatches |
| thm18 all-D: Grok checker | 54 PASS / 0 FAIL |
| prop17: Grok F1 checker | n ≤ 3 copy in the sandbox: 34 PASS / 0 FAIL; **full run with n = 4 (`--n4-range`) on the author's PC: 46 PASS / 0 FAIL** |
| prop17: Grok F2 checker | `--quick` in the sandbox: 39 PASS / 0 FAIL; **full run with n = 5 on the author's PC: 43 PASS / 0 FAIL** |
| prop17: Claude n = 4 Bell value | 1/96 > PGM-seed value 0.0087758 (numeric) |

**Every bundled check has been run to completion outside the producer's environment, with 0 failures.** For the three larger runs the evidence is the author's run (`logs_expected/author_pc_run/`: full logs and the console transcript), not a second independent machine; GPT's round-2 rerun covered the smaller checks.
