import sys, numpy as np, math, time
from scipy.sparse.linalg import LinearOperator, eigsh
sys.path.insert(0,'../common'); import h2_stabilizer as h2
t0=time.time(); n=4; S=np.array(h2.stab_states(n)); N=len(S); D=2**n
amp=np.einsum('sj,sj->s',S,S)/math.sqrt(D)          # Bell outcome P = I : (S)^T S / sqrt(D)
p=np.abs(amp)**2; idx=np.where(p>1e-14)[0]; Sm=S[idx]; w=p[idx]/N; K=len(idx)
print("states",N,"with p(I)>0:",K,flush=True)
Sc=Sm.conj(); CH=1500
def mv(v):
    v=v.reshape(D,D,D,D); out=np.zeros((D,D,D,D),dtype=complex)
    for c0 in range(0,K,CH):
        s=Sm[c0:c0+CH]; sc=Sc[c0:c0+CH]; ww=w[c0:c0+CH]
        t=np.einsum('ki,ijlm->kjlm',sc,v,optimize=True); t=np.einsum('kj,kjlm->klm',sc,t); t=np.einsum('kl,klm->km',sc,t)
        c=np.einsum('km,km->k',sc,t)*ww
        out+=np.einsum('k,ki,kj,kl,km->ijlm',c,s,s,s,s,optimize=True)
    return out.reshape(-1)
op=LinearOperator((D**4,D**4),matvec=mv,dtype=complex)
lam=eigsh(op,k=1,which='LA',tol=1e-12,maxiter=400)[0][0]
V=D*(D+1)/2*lam
s=math.sqrt(D*D+32*D+20992); Z6=D*(D+1)*(D+2)*(D+4)*(D+8)*(D+16); seed=(D*(D+1)/2)*15*(D+160+s)/Z6
print(f"n=4: per-outcome lambda = {lam:.12e}  predicted g(D) = {6/(D*D*(D+1)*(D+2)):.12e}")
print(f"n=4 2->4: Bell value = {V:.12f}  3/(D(D+2)) = {3/(D*(D+2)):.12f}  PGM-seed value = {seed:.12f}  Bell beats seed: {V>seed}  time {round(time.time()-t0)}s",flush=True)
