"""Standalone exact checker for R13f Gate F2 (Grok Bot, own code). Needs python3 + numpy only, plus the data files
orbit0_2to4.json (E1 orbit O_0, 18 relations of Sigma_{6,6}) and orbits56_66_3to4.json (E2 orbits O_56, O_66 of Sigma_{7,7}).
Imports no producing script. Usage: python3 check_gateF2.py [--quick]   (--quick skips n = 5 and the n = 4 chi Gram)
Conventions: D = 2^n; Pauli label (a, b) in F_2^n x F_2^n, P = i^{a.b} X^a Z^b (Hermitian; real symmetric iff a.b even);
stabilizer states in affine/quadratic normal form with scaled amplitudes s = 2^{r/2} psi in {0, +-1, +-i}; p(P|psi) = |psi^T P psi|^2 / D
(Bell measurement {(P (x) I)|Phi+>/sqrt D} on psi (x) psi). Exact: Gaussian integers in int64/complex128 with asserted lossless rounding,
Fractions for rationals, integer polynomial arithmetic for the all-D sign statements.
Checks (labels as in gateF2.md):
 C1  enumeration complete (count N_n, pairwise distinct rays), n = 1..4
 C2  every psi: |s^T P s|^2 in {0, 4^r}; antisymmetric P never occur; the outcome support is an affine subspace (coset) of size D, n = 1..4
 C3  real stabilizer states R_I: count 2^n prod_{k=0}^{n-1}(2^k+1) = 2N/(D+1), distinct; at n <= 4 equal to {psi : |psi^T psi| = 1}; n = 1..5
 C4  R_P = U_P R_I as ray sets, U_P = (I+P)/2 + i(I-P)/2, for every symmetric P, n = 1..4
 C5  Gershgorin row sums on R_I: every row (n <= 4; 64 rows at n = 5) = prod_{k=0}^{n-1}(2^{k-1}+1) = 6N/(D(D+1)(D+2)), and the overlap
     distribution #{b : |<a|b>|^2 = 2^-k} = [n k]_2 2^{k(k-1)/2} 2^k
 C6  q-binomial identities used in the proof, n = 1..40
 C7  #maximal totally singular subspaces of the hyperbolic quadratic space F_2^{2r} opposite a fixed one = 2^{r(r-1)/2}, r = 1..3 (brute force)
 C8  exact g = Rayleigh(chi_P) = Gershgorin bound, V = D(D+1)/2 g = 3/(D(D+2)), n = 1..5
 C9  chi_P: norm D(D+2)/3, overlap <psi^4|chi_P> = conj(psi^T P psi)^2, Gram <chi_P|chi_Q> = (D/3)(D delta + 2 c(P,Q)), n = 1..4
 C10 commutation-sign matrix C on symmetric Paulis: C^2 = (D^2/2) I + (D/2) C, multiplicity of eigenvalue D = (D+1)(D+2)/6 (=> output-marginal
     rank), n = 1..6; numeric rank cross-check (OBSERVED) n <= 5
 C11 rho_0 = rho_B for every n: site-level multiset identity (1152 terms = 64 x 18 r_N); dense b_0 * 32D = B at n = 1, 2
 C12 rho_56 = rho_B3 for every n: site-level multiset identity (41472 terms = 256 x 162 r_N); dense B3 = 256 b_56 at n = 1
 C13 marginals: seed marginal of rho_B = Pi_sym2/D_2 (n = 1, 2), of rho_B3 = Pi_sym3/D_3 (n = 1); output marginal of rho_B has rank
     (D+1)(D+2)/6 with all nonzero eigenvalues equal (n = 1, 2, exact rational check of rho_out^2 = rho_out * 6/((D+1)(D+2)))
 C14 D_3 g_56 = 3/(D(D+2)) (polynomial identity); exact sign of V - (seed value) for 2->4 and 3->4, n = 1..12, and for all real D >= 16 (2->4)
     resp. D >= 128 (3->4) by shifted-polynomial coefficient positivity"""
import itertools, json, os, sys, random
import numpy as np
from fractions import Fraction as Fr
from collections import Counter
HERE = os.path.dirname(os.path.abspath(__file__)); QUICK = '--quick' in sys.argv
PASS, FAIL = [], []
def check(name, ok):
    (PASS if ok else FAIL).append(name); print(('PASS ' if ok else 'FAIL ') + name, flush=True)
def Ncount(n):
    o = 2**n
    for k in range(1, n + 1): o *= 2**k + 1
    return o
def qbin(n, k):
    if k < 0 or k > n: return 0
    num = den = 1
    for i in range(k): num *= 2**(n - i) - 1; den *= 2**(i + 1) - 1
    return num // den
# ---------- stabilizer states ----------
def rrefs(n, r):
    out = []
    for piv in itertools.combinations(range(n), r):
        free = [(i, c) for i in range(r) for c in range(n) if c > piv[i] and c not in piv]
        for bits in itertools.product((0, 1), repeat=len(free)):
            rows = [1 << (n - 1 - piv[i]) for i in range(r)]
            for (i, c), bt in zip(free, bits):
                if bt: rows[i] |= 1 << (n - 1 - c)
            out.append((piv, rows))
    return out
def states(n, real_only=False):
    D = 2**n; V, R = [], []
    for r in range(n + 1):
        Yl = list(itertools.product((0, 1), repeat=r)); Ys = np.array(Yl, dtype=np.int64).reshape(len(Yl), r)
        pairs = [(j, k) for j in range(r) for k in range(j + 1, r)]
        Qterms = np.array([[y[j] * y[k] for (j, k) in pairs] for y in Ys], dtype=np.int64).reshape(len(Ys), len(pairs))
        Ls = list(itertools.product((0, 2) if real_only else range(4), repeat=r))
        Ql = list(itertools.product((0, 1), repeat=len(pairs))); Qs = np.array(Ql, dtype=np.int64).reshape(len(Ql), len(pairs))
        for piv, rows in rrefs(n, r):
            nonpiv = [c for c in range(n) if c not in piv]
            for bb in itertools.product((0, 1), repeat=len(nonpiv)):
                b = sum(1 << (n - 1 - c) for c, bt in zip(nonpiv, bb) if bt)
                xs = []
                for y in Ys:
                    x = b
                    for j in range(r):
                        if y[j]: x ^= rows[j]
                    xs.append(x)
                xs = np.array(xs)
                for l in Ls:
                    lin = Ys @ np.array(l, dtype=np.int64).reshape(r) if r else np.zeros(len(Ys), np.int64)
                    E = (lin[None, :] + 2 * (Qs @ Qterms.T)) % 4        # (numQ, 2^r)
                    vals = (1j) ** E
                    for row in vals:
                        v = np.zeros(D, complex); v[xs] = row; V.append(v); R.append(r)
    return np.array(V), np.array(R)
def raykey(w):
    k = int(np.argmax(np.abs(w) > 1e-9)); u = w / w[k]
    re, im = np.round(u.real), np.round(u.imag); assert np.abs(u - re - 1j * im).max() < 1e-9
    return (re.astype(np.int8).tobytes(), im.astype(np.int8).tobytes())
def pauli_apply(Sv, a, b, n):
    """rows of Sv are vectors; returns rows P v with P = i^{a.b} X^a Z^b"""
    D = 2**n; x = np.arange(D); xa = x ^ a
    sign = np.array([(-1)**bin(b & int(y)).count('1') for y in xa])
    ph = 1j**(bin(a & b).count('1') % 4)
    return ph * sign[None, :] * Sv[:, xa]
def is_sym(a, b): return bin(a & b).count('1') % 2 == 0
def comm(p, q):   # +1 if commute, -1 if anticommute: symplectic form a.b' + b.a'
    return (-1)**((bin(p[0] & q[1]).count('1') + bin(p[1] & q[0]).count('1')) % 2)
res_n = {}
for n in range(1, 5 if True else 0):
    D = 2**n; S, R = states(n); N = Ncount(n)
    keys = {raykey(v) for v in S}
    check(f'C1 n={n}: {len(S)} states = N_n = {N}, pairwise distinct rays', len(S) == N and len(keys) == N)
    paulis = [(a, b) for a in range(D) for b in range(D)]; sym = [p for p in paulis if is_sym(*p)]
    amp = {}
    for (a, b) in paulis:
        amp[(a, b)] = np.einsum('ij,ij->i', S, pauli_apply(S, a, b, n))      # s^T P s (Gaussian integers)
    ok2 = True; asym0 = True; coset = True; supsize = True
    for p in paulis:
        m2 = np.round(np.abs(amp[p])**2).astype(np.int64); ok2 &= bool(np.all((m2 == 0) | (m2 == 4**R)))
        if not is_sym(*p): asym0 &= bool(np.all(m2 == 0))
    A = np.array([np.round(np.abs(amp[p])**2).astype(np.int64) > 0 for p in paulis]).T   # states x paulis
    lab = np.array([(a << n) | b for (a, b) in paulis])
    for i in range(len(S)):
        sup = set(lab[A[i]].tolist()); supsize &= len(sup) == D
        s0 = next(iter(sup)); W = {s0 ^ t for t in sup}
        coset &= all((u ^ v) in W for u in W for v in W) if n <= 3 else all((u ^ v) in W for u in list(W)[:8] for v in W)
    check(f'C2 n={n}: |s^T P s|^2 in {{0, 4^r}} for all states and all {D*D} Paulis; antisymmetric outcomes have probability 0; '
          f'every support has size D = {D} and is a coset of a subspace', ok2 and asym0 and supsize and coset)
    # C3/C4
    Sr, Rr = states(n, real_only=True); NR = 2**n
    for k in range(n): NR *= 2**k + 1
    realset = {raykey(v) for v in Sr}
    fromall = {raykey(S[i]) for i in range(len(S)) if A[i][paulis.index((0, 0))]}
    check(f'C3 n={n}: |R_I| = {len(Sr)} = 2^n prod_(k<n)(2^k+1) = 2N/(D+1) = {Fr(2*N, D+1)}, distinct, and R_I = {{psi : |psi^T psi| = 1}}',
          len(Sr) == NR == Fr(2 * N, D + 1) and len(realset) == NR and realset == fromall)
    ok4 = True; idx = {p: i for i, p in enumerate(paulis)}
    for (a, b) in sym:
        RP = {raykey(S[i]) for i in range(len(S)) if A[i][idx[(a, b)]]}
        PS = pauli_apply(Sr, a, b, n); assert np.abs(PS.imag).max() == 0
        US = ((Sr + PS) + 1j * (Sr - PS)) / 2
        ok4 &= {raykey(w) for w in US} == RP and len(RP) == NR
    check(f'C4 n={n}: R_P = U_P R_I exactly (as ray sets) for all {len(sym)} symmetric P, |R_P| = {NR}', ok4)
    res_n[n] = dict(S=S, R=R, Sr=Sr, Rr=Rr, N=N, NR=NR, sym=sym, amp=amp)
# real states at n = 5
if not QUICK:
    n = 5; D = 32; Sr, Rr = states(n, real_only=True); NR = 2**n
    for k in range(n): NR *= 2**k + 1
    N = Ncount(n); keys = {raykey(v) for v in Sr}
    check(f'C3 n=5: |R_I| = {len(Sr)} = 2^n prod_(k<n)(2^k+1) = 2N/(D+1) = {Fr(2*N, D+1)}, distinct', len(Sr) == NR == Fr(2 * N, D + 1) and len(keys) == NR)
    res_n[5] = dict(Sr=Sr, Rr=Rr, N=N, NR=NR)
# C5 row sums
for n in sorted(res_n):
    D = 2**n; Sr = np.round(res_n[n]['Sr'].real).astype(np.int64); Rr = res_n[n]['Rr']
    target = Fr(1)
    for k in range(n): target *= Fr(2**k + 2, 2)                  # prod (2^{k-1}+1)
    rows = range(len(Sr)) if n <= 4 else [0] + random.Random(5).sample(range(len(Sr)), 63)
    okS = True; okH = True
    for i in rows:
        dots = Sr @ Sr[i]; nz = dots != 0
        k2 = Rr[nz] + Rr[i] - 2 * np.round(np.log2(np.abs(dots[nz]))).astype(np.int64)   # |<a|b>|^2 = 2^{-k}
        assert np.all(np.abs(dots[nz]) == 2**((Rr[nz] + Rr[i] - k2) // 2))
        h = Counter(k2.tolist()); okH &= all(h.get(k, 0) == qbin(n, k) * 2**(k * (k - 1) // 2) * 2**k for k in range(n + 1)) and sum(h.values()) == nz.sum()
        okS &= sum(Fr(c, 4**k) for k, c in h.items()) == target
    check(f'C5 n={n}: Gershgorin row sum sum_b |<a|b>|^4 over R_I = {target} = prod(2^(k-1)+1) = 6N/(D(D+1)(D+2)) for {len(rows)} rows; '
          f'overlap distribution [n k]_2 2^(k(k-1)/2) 2^k', okS and okH and target == Fr(6 * res_n[n]['N'], D * (D + 1) * (D + 2)))
    res_n[n]['rowsum'] = target
# C6
ok6 = True
for n in range(1, 41):
    D = 2**n; N = Ncount(n)
    s1 = sum(Fr(qbin(n, r) * 2**(r * (r - 1) // 2), 2**r) for r in range(n + 1))
    s2 = sum(qbin(n, r) * 2**(r * (r - 1) // 2) for r in range(n + 1))
    p1 = Fr(1); p2 = 1
    for k in range(n): p1 *= Fr(2**k + 2, 2); p2 *= 2**k + 1
    ok6 &= s1 == p1 == Fr(6 * N, D * (D + 1) * (D + 2)) and s2 == p2 and Fr(2**n * p2) == Fr(2 * N, D + 1)
check('C6: sum_r [n r]_2 2^(r(r-1)/2) 2^-r = prod_(k<n)(1+2^(k-1)) = 6N/(D(D+1)(D+2)) and sum_r [n r]_2 2^(r(r-1)/2) = prod_(k<n)(1+2^k), '
      '2^n prod(1+2^k) = 2N/(D+1), n = 1..40', ok6)
# C7
ok7 = True
for r in range(1, 4):
    dim = 2 * r; pts = range(1 << dim)
    q = lambda v: bin((v >> r) & (v & ((1 << r) - 1))).count('1') % 2      # q(x, y) = x.y
    om = lambda u, v: (bin((u >> r) & (v & ((1 << r) - 1))).count('1') + bin((v >> r) & (u & ((1 << r) - 1))).count('1')) % 2
    sing = [v for v in pts if q(v) == 0]
    subs = set()
    def grow(basis, span):
        if len(basis) == r: subs.add(frozenset(span)); return
        for v in sing:
            if v in span: continue
            if all(om(v, w) == 0 for w in basis):
                nspan = span | {v ^ w for w in span}
                if all(q(x) == 0 for x in nspan): grow(basis + [v], nspan)
    grow([], {0})
    L0 = frozenset(v for v in pts if v & ((1 << r) - 1) == 0)        # {(x, 0)}
    tot = 1
    for i in range(r): tot *= 2**i + 1
    opp = sum(1 for L in subs if L & L0 == {0})
    ok7 &= L0 in subs and len(subs) == tot and opp == 2**(r * (r - 1) // 2)
check('C7: hyperbolic F_2^{2r}, r = 1..3: #maximal t.s. subspaces = prod_(i<r)(2^i+1), #opposite to a fixed one = 2^(r(r-1)/2)', ok7)
# C8
for n in sorted(res_n):
    D = 2**n; N = res_n[n]['N']; NR = res_n[n]['NR']; g = Fr(6, D * D * (D + 1) * (D + 2))
    ray = Fr(NR, N * D) / Fr(D * (D + 2), 3); up = res_n[n]['rowsum'] / (N * D); V = Fr(D * (D + 1), 2) * g
    check(f'C8 n={n}: Rayleigh(chi_P) = |R_P|/(N D) / (D(D+2)/3) = {ray} = g; Gershgorin = rowsum/(N D) = {up} = g; V = {V} = 3/(D(D+2))',
          ray == g == up and V == Fr(3, D * (D + 2)))
# C9 chi_P
for n in range(1, 5):
    if QUICK and n == 4: continue
    D = 2**n; S = res_n[n]['S']; sym = res_n[n]['sym']; amp = res_n[n]['amp']
    chis = []
    for (a, b) in sym:
        Pm = pauli_apply(np.eye(D, dtype=complex), a, b, n).T; assert np.abs(Pm.imag).max() == 0; Pm = np.round(Pm.real).astype(np.int64)
        T = np.einsum('ij,kl->ijkl', Pm, Pm); acc = np.zeros_like(T)
        for pm in itertools.permutations(range(4)): acc += T.transpose(pm)
        chis.append(acc.reshape(-1))                                  # 24 chi_P (real integers)
    Cm = np.array(chis); G = Cm @ Cm.T
    exp = np.array([[192 * D * (D * (p == q) + 2 * comm(p, q)) for q in sym] for p in sym])     # 576 (D/3)(D delta + 2c)
    okG = bool((G == exp).all()) and all(G[i, i] == 576 * D * (D + 2) // 3 for i in range(len(sym)))
    test = sym if n <= 3 else sym[:2]; okO = True
    for j, p in enumerate(sym):
        if p not in test: continue
        X = chis[j].reshape(D, D, D, D).astype(complex)
        for c0 in range(0, len(S), 2000):
            Sc = np.conj(S[c0:c0 + 2000])
            v = np.einsum('ijkl,ni->njkl', X, Sc); v = np.einsum('njkl,nj->nkl', v, Sc); v = np.einsum('nkl,nk->nl', v, Sc); v = np.einsum('nl,nl->n', v, Sc)
            okO &= bool(np.abs(v - 24 * np.conj(amp[p][c0:c0 + 2000])**2).max() < 1e-6)
    check(f'C9 n={n}: |chi_P|^2 = D(D+2)/3, Gram <chi_P|chi_Q> = (D/3)(D delta_PQ + 2 c(P,Q)) for all {len(sym)}^2 pairs; '
          f'overlap <psi^4|chi_P> = conj(psi^T P psi)^2 for all states and {len(test)} outcomes', okG and okO)
# C10
for n in range(1, 7):
    D = 2**n; sym = [(a, b) for a in range(D) for b in range(D) if is_sym(a, b)]
    lab = np.array([[a, b] for a, b in sym])
    pc = np.vectorize(lambda x: bin(x).count('1') % 2)
    Cm = 1 - 2 * pc((lab[:, 0][:, None] & lab[:, 1][None, :]) ^ (lab[:, 1][:, None] & lab[:, 0][None, :]))
    I = np.eye(len(sym), dtype=np.int64)
    ok = bool((2 * (Cm @ Cm) == D * D * I + D * Cm).all())
    trC = int(np.trace(Cm)); m1 = Fr(trC + len(sym) * Fr(D, 2), Fr(3 * D, 2))
    ok &= m1 == Fr((D + 1) * (D + 2), 6)
    if n <= 5: ok &= int(np.linalg.matrix_rank((D * I + 2 * Cm).astype(float))) == (D + 1) * (D + 2) // 6
    check(f'C10 n={n}: C^2 = (D^2/2) I + (D/2) C; eigenvalues D (mult (D+1)(D+2)/6 = {m1}) and -D/2; rank(D I + 2C) = {m1}'
          + (' (numeric rank cross-check OBSERVED)' if n <= 5 else ''), ok)
# C11 / C12 site identities
I2 = np.eye(2); Xp = np.array([[0, 1], [1, 0]]); Zp = np.diag([1, -1]); Yp = 1j * Xp @ Zp
P1 = [(I2, 1), (Xp, 1), (Zp, 1), (Yp, -1)]; phi = np.array([1, 0, 0, 1], complex)
def permmat(p, t):
    M = np.zeros((2**t, 2**t), np.int64)
    for x in range(2**t):
        bt = [(x >> (t - 1 - c)) & 1 for c in range(t)]; M[sum(bt[p[c]] << (t - 1 - c) for c in range(t)), x] = 1
    return M
def pairop(s): w = np.kron(s, I2) @ phi; return np.outer(w, w)
def relmats(rels, t):
    out = []
    for Nn in rels:
        m = np.zeros((2**t, 2**t), np.int64)
        for v in Nn: m[v >> t, v & (2**t - 1)] = 1
        out.append(m)
    return out
def site_multiset(t, Kfun, G):
    base = {}
    for e in (0, 1):
        m = sum((sg**e) * Kfun(s) for s, sg in P1); assert np.abs(m.imag).max() == 0; base[e] = np.round(m.real).astype(np.int64)
    terms = Counter(); mats = {}
    for e in (0, 1):
        for A in G:
            AB = A @ base[e]
            for Bm in G:
                M = AB @ Bm.T; assert (M % 2 == 0).all(); k = (M // 2).tobytes(); terms[k] += 1; mats[k] = M // 2
    return terms, mats
o0 = [frozenset(x) for x in json.load(open(os.path.join(HERE, 'orbit0_2to4.json')))['orbit0']]
r0 = relmats(o0, 6)
G6 = [permmat((0, 1) + tuple(2 + q for q in p), 6) for p in itertools.permutations(range(4))]
terms, mats = site_multiset(6, lambda s: np.kron(np.kron(pairop(s), pairop(s)), pairop(s)), G6)
rk = Counter(m.tobytes() for m in r0)
okm = set(terms) == set(rk) and all(c == 64 for c in terms.values()) and len(rk) == 18
# dense n = 1, 2: B = sum_P v_P v_P^T vs b_0
def dense_check_2to4(n):
    D = 2**n; t = 6
    def kron_n(m, n):
        out = m
        for _ in range(n - 1): out = np.kron(out, m)
        return out
    # reorder site-major (q, c) -> copy-major (c, q)
    perm = np.zeros(D**t, np.int64)
    for idx in range(D**t):
        bits_sm = [(idx >> (t * n - 1 - j)) & 1 for j in range(t * n)]        # site-major: j = q*t + c
        cm = 0
        for q in range(n):
            for c in range(t): cm |= bits_sm[q * t + c] << (t * n - 1 - (c * n + q))
        perm[idx] = cm
    b0_sm = sum(kron_n(m, n) for m in r0)
    b0 = np.zeros_like(b0_sm); b0[np.ix_(perm, perm)] = b0_sm
    syms = [(a, b) for a in range(D) for b in range(D) if is_sym(a, b)]
    B = np.zeros((D**t, D**t), np.int64)
    for (a, b) in syms:
        Pm = np.round(pauli_apply(np.eye(D, dtype=complex), a, b, n).T.real).astype(np.int64); ph = Pm.reshape(-1)
        T = np.einsum('ij,kl->ijkl', Pm, Pm); acc = np.zeros_like(T)
        for pm in itertools.permutations(range(4)): acc += T.transpose(pm)
        v = np.kron(ph, acc.reshape(-1)); B += np.outer(v, v)
    return bool((b0 * 32 * D == B).all()), b0, B, syms
okd = []
dense = {}
for n in (1, 2):
    o, b0, B, syms = dense_check_2to4(n); okd.append(o); dense[n] = (b0, B, syms)
check('C11: rho_0 = rho_B for EVERY n: the 1152 site terms M/2 (M = pi~ (sum_s sgn(s)^eps u_s u_s^T) pi~\'^T) are exactly 64 copies of each of the 18 r_N, '
      'so sum_P v_P v_P^T = (1/2) sum M^{(x)n} = 32 D b_0; dense cross-check b_0 * 32D = B exact at n = 1, 2', okm and all(okd))
d56 = json.load(open(os.path.join(HERE, 'orbits56_66_3to4.json')))
r56 = relmats([frozenset(x) for x in d56['orbit56']], 7)
G7 = [permmat(tuple(a) + tuple(3 + q for q in b), 7) for a in itertools.permutations(range(3)) for b in itertools.permutations(range(4))]
terms7, _ = site_multiset(7, lambda s: np.kron(np.kron(np.kron(pairop(s), I2), pairop(s)), pairop(s)), G7)
rk7 = Counter(m.tobytes() for m in r56)
okm7 = set(terms7) == set(rk7) and all(c == 256 for c in terms7.values()) and len(rk7) == 162
# dense n = 1 for 3->4
T3 = sum(permmat(p, 3) for p in itertools.permutations(range(3))); T4 = sum(permmat(p, 4) for p in itertools.permutations(range(4)))
B3 = np.zeros((128, 128), np.int64); b56 = sum(r56)
for s in (np.eye(2, dtype=np.int64), np.array([[0, 1], [1, 0]]), np.diag([1, -1])):
    ph = np.kron(s, np.eye(2, dtype=np.int64)) @ np.array([1, 0, 0, 1]); c = T4 @ np.kron(ph, ph)
    B3 += np.kron(T3 @ np.kron(np.outer(ph, ph), np.eye(2, dtype=np.int64)) @ T3.T, np.outer(c, c))
check('C12: rho_56 = rho_B3 for EVERY n (3->4 Bell strategy, copy 2 discarded): the 41472 site terms M/2 are exactly 256 copies of each of the 162 r_N (N in O_56), '
      'so B3 = 2^(n-1) * 256 * b_56; dense cross-check B3 = 256 b_56 exact at n = 1', okm7 and bool((B3 == 256 * b56).all()))
# C13 marginals
okm = True
for n in (1, 2):
    D = 2**n; b0, B, syms = dense[n]; D2 = D * (D + 1) // 2
    Bt = B.reshape(D * D, D**4, D * D, D**4)
    seed = np.einsum('iaja->ij', Bt); out = np.einsum('aibj->ij', Bt.transpose(0, 1, 2, 3)) if False else np.einsum('aiaj->ij', Bt)
    # rho_B = B / tr B ; seed marginal must be Pi_sym2 / D_2
    Psym = np.zeros((D * D, D * D))
    for x in range(D):
        for y in range(D):
            Psym[x * D + y, x * D + y] += 0.5; Psym[x * D + y, y * D + x] += 0.5
    trB = int(np.trace(B))
    okm &= bool((2 * seed * D2 == trB * np.round(2 * Psym).astype(np.int64)).all())
    # output marginal: rho_out^2 = rho_out * 6/((D+1)(D+2)) exactly (integers), rank (D+1)(D+2)/6
    lhs = out.astype(object).dot(out.astype(object)) * (D + 1) * (D + 2)
    okm &= bool((lhs == out.astype(object) * 6 * trB).all()) and int(np.trace(out)) * 6 == trB * 6 and \
        int(np.linalg.matrix_rank(out.astype(float))) == (D + 1) * (D + 2) // 6
Bt3 = B3.reshape(8, 16, 8, 16); seed3 = np.einsum('iaja->ij', Bt3)
P3 = T3 / 6; okm &= bool(np.allclose(seed3 / np.trace(B3), P3 / 4)) and bool((seed3 * 24 == int(np.trace(B3)) * T3).all())
check('C13: seed marginals Pi_sym2/D_2 (rho_B, n = 1, 2) and Pi_sym3/D_3 (rho_B3, n = 1); output marginal of rho_B satisfies rho_out^2 = '
      '(6/((D+1)(D+2))) rho_out exactly, rank (D+1)(D+2)/6 = 2, 5 (n = 1, 2)', okm)
# C14
def pmul(a, b):
    c = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): c[i + j] += x * y
    return c
def padd(a, b, s=1):
    m = max(len(a), len(b)); return [(a[i] if i < len(a) else 0) + s * (b[i] if i < len(b) else 0) for i in range(m)]
def lin(c): return [c, 1]                      # D + c (coefficient list, low degree first)
def prod(*ps):
    o = [1]
    for p in ps: o = pmul(o, p)
    return o
def shift(p, s):                               # p(D) -> p(s + x)
    o = [0]
    for c in reversed(p): o = padd(pmul(o, [s, 1]), [c])
    return o
# D_3 g_56 = 3/(D(D+2)) with D_3 = D(D+1)(D+2)/6, g_56 = 18/(D^2(D+1)(D+2)^2); cross-multiplied below
okp = pmul([18], prod([0, 1], lin(1), lin(2), [0, 1], lin(2))) == pmul([0, 0, 3 * 6], prod(lin(1), lin(2), lin(2)))   # 18 * D(D+1)(D+2) * D(D+2) == 3 * 6 * D^2 (D+1)(D+2)^2
def sqrt_parts(m):
    c = 1; d = m; f = 2
    while f * f <= d:
        while d % (f * f) == 0: d //= f * f; c *= f
        f += 1
    return c, d
def sign_cmp(gv, A, Bc, rad, Z):               # sign of gv - A (Bc + sqrt(rad)) / Z, exact
    r0 = Fr(A * Bc, Z); c, d = sqrt_parts(rad); cc = Fr(A * c, Z)
    x = gv - r0
    if x <= 0: return -1
    return 1 if x * x > cc * cc * d else (-1 if x * x < cc * cc * d else 0)
signs2, signs3 = [], []
for n in range(1, 13):
    D = 2**n; Z6 = D * (D + 1) * (D + 2) * (D + 4) * (D + 8) * (D + 16); Z7 = Z6 * (D + 32)
    g2 = Fr(6, D * D * (D + 1) * (D + 2)); g3 = Fr(18, D * D * (D + 1) * (D + 2)**2)
    signs2.append(sign_cmp(g2, 15, D + 160, D * D + 32 * D + 20992, Z6)); signs3.append(sign_cmp(g3, 135, D + 576, D * D + 64 * D + 296960, Z7))
ok_s = signs2 == [-1] * 3 + [1] * 9 and signs3 == [-1] * 6 + [1] * 6
# all real D >= 16 (2->4): L = 2(D+4)(D+8)(D+16) - 5D^2 - 800D > 0 and L^2 - 25 D^2 (D^2+32D+20992) > 0
L2 = padd(pmul([2], prod(lin(4), lin(8), lin(16))), [0, 800, 5], -1)
Q2 = padd(pmul(L2, L2), pmul([0, 0, 25], [20992, 32, 1]), -1)
L3 = padd(pmul([2], prod(lin(4), lin(8), lin(16), lin(32))), pmul([0, 15], prod(lin(2), lin(576))), -1)
Q3 = padd(pmul(L3, L3), pmul(pmul([0, 0, 225], prod(lin(2), lin(2))), [296960, 64, 1]), -1)
def allpos(p, s): q = shift(p, s); return all(c >= 0 for c in q) and q[0] > 0
ok_all = allpos(L2, 16) and allpos(Q2, 16) and allpos(L3, 128) and allpos(Q3, 128)
check(f'C14: D_3 g_56 = 3/(D(D+2)) (polynomial identity); exact sign(V - D_T lambda_T), n = 1..12: 2->4 {signs2}, 3->4 {signs3}; '
      'g > lambda_2 for all real D >= 16 and g_56 > lambda_3 for all real D >= 128 (shifted coefficients >= 0, constant > 0)', okp and ok_s and ok_all)
print(f'\nPASS: {len(PASS)}  FAILS: {len(FAIL)}')
sys.exit(1 if FAIL else 0)
