#!/usr/bin/env python3
"""Standalone exact checker for R13f Gate F1 (2 -> 4 cloning of n-qubit stabilizer states, Bell sampling beats the PGM seed
at n = 4). Needs only numpy (and the data file orbit0_2to4.json for C10-C12). No import of any producing script.
Usage: python3 check_gateF1.py [--n4-range]   (C11 at n = 4 takes ~10 min and runs only with --n4-range)
Every check is exact: Python integers / Fractions; numpy arrays only hold small Gaussian integers (|entry| <= 2^n or
products bounded far below 2^53), and every float->int conversion is asserted to be lossless.
Conventions: D = 2^n; Bell basis |Phi_P> = (P (x) I) D^{-1/2} sum_x |x>|x>, P = i^{a.b} X^a Z^b (Hermitian); symmetric iff
a.b even; p(P|psi) = |psi^T P psi|^2 / D; output chi_P = Pi_sym4(Phi'_P (x) Phi'_P), Phi'_P = sum_x P|x>|x>;
A_P = (1/N) sum_psi p(P|psi) |psi^{(x)4}><psi^{(x)4}|; Bell value V = sum_P lambda_max(A_P) (average global fidelity);
seed value = D_2 * 15 (D + 160 + sqrt(D^2 + 32 D + 20992)) / Z6, Z6 = D(D+1)(D+2)(D+4)(D+8)(D+16) (ledger v7 §3)."""
import itertools, json, sys, os
from fractions import Fraction as F
import numpy as np
PASS, FAIL = [], []
def check(name, ok):
    (PASS if ok else FAIL).append(name); print(('PASS ' if ok else 'FAIL ') + name, flush=True)

def stab(n):
    """normal form 2^{-r/2} sum_y i^{l.y} (-1)^{sum_{j<k} Q_jk y_j y_k} |A^T y + b>; returns scaled vectors (entries 0, +-1, +-i) and r"""
    D = 2**n; V, Rr = [], []
    for r in range(n + 1):
        Ys = list(itertools.product((0, 1), repeat=r)); pr = [(j, k) for j in range(r) for k in range(j + 1, r)]
        for piv in itertools.combinations(range(n), r):
            free = [(i, c) for i in range(r) for c in range(n) if c > piv[i] and c not in piv]
            for bits in itertools.product((0, 1), repeat=len(free)):
                rows = [1 << (n - 1 - piv[i]) for i in range(r)]
                for (i, c), bt in zip(free, bits):
                    if bt: rows[i] |= 1 << (n - 1 - c)
                npv = [c for c in range(n) if c not in piv]
                for bb in itertools.product((0, 1), repeat=len(npv)):
                    b = sum(1 << (n - 1 - c) for c, bt in zip(npv, bb) if bt); xs = []
                    for y in Ys:
                        x = b
                        for j in range(r):
                            if y[j]: x ^= rows[j]
                        xs.append(x)
                    for l in itertools.product(range(4), repeat=r):
                        for Q in itertools.product((0, 1), repeat=len(pr)):
                            v = np.zeros(D, complex)
                            for y, x in zip(Ys, xs):
                                v[x] = 1j**((sum(l[j] * y[j] for j in range(r)) + 2 * sum(q * y[j] * y[k] for q, (j, k) in zip(Q, pr))) % 4)
                            V.append(v); Rr.append(r)
    return np.array(V), np.array(Rr)

def gint(z):
    re, im = np.round(z.real), np.round(z.imag); assert np.abs(z.real - re).max() == 0 and np.abs(z.imag - im).max() == 0
    return re.astype(np.int64), im.astype(np.int64)

def papply(S, a, b, n):
    x = np.arange(2**n) ^ a; sg = np.array([(-1)**bin(b & int(u)).count('1') for u in x])
    return 1j**(bin(a & b).count('1') % 4) * sg[None, :] * S[:, x]

def chi24(a, b, n):
    Pm = papply(np.eye(2**n, dtype=complex), a, b, n).T; T = np.einsum('ij,kl->ijkl', Pm, Pm); acc = np.zeros_like(T)
    for p in itertools.permutations(range(4)): acc += T.transpose(p)
    return acc, Pm

def ov4(Sc, C):
    t = np.einsum('ka,abcd->kbcd', Sc, C); t = np.einsum('kb,kbcd->kcd', Sc, t); t = np.einsum('kc,kcd->kd', Sc, t)
    return np.einsum('kd,kd->k', Sc, t)

def qbin(n, k):
    a, b = 1, 1
    for i in range(k): a *= 2**(n - i) - 1; b *= 2**(i + 1) - 1
    return a // b

def seed_parts(D):
    """seed value as (rational part, coefficient of sqrt(d), d) with sqrt(D^2+32D+20992) = c*sqrt(d), d squarefree"""
    m = D * D + 32 * D + 20992; c = 1; d = m; f = 2
    while f * f <= d:
        while d % (f * f) == 0: d //= f * f; c *= f
        f += 1
    Z6 = D * (D + 1) * (D + 2) * (D + 4) * (D + 8) * (D + 16); k = F(D * (D + 1) // 2 * 15, Z6)
    return k * (D + 160), k * c, d

def compare(V, D):
    """exact sign of V - seed = (V - r0) - c sqrt(d): returns +1/-1"""
    r0, c, d = seed_parts(D); u = V - r0
    if u <= 0: return -1
    return 1 if u * u > c * c * d else -1

data = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'orbit0_2to4.json')
for n in (1, 2, 3, 4):
    D = 2**n; S, R = stab(n); N = len(S)
    Nf = 2**n
    for k in range(1, n + 1): Nf *= 2**k + 1
    keys = set()
    for v in S:
        k0 = int(np.argmax(np.abs(v) > 0.5)); w = v * np.conj(v[k0]); keys.add(tuple(gint(w)[0]) + tuple(gint(w)[1]))
    check(f'C1 n={n}: {N} stabilizer states = 2^n prod(2^k+1) = {Nf}, pairwise distinct up to phase', N == Nf and len(keys) == N)
    M2 = {}
    for a in range(D):
        for b in range(D):
            re, im = gint((S * papply(S, a, b, n)).sum(axis=1)); M2[(a, b)] = re * re + im * im
    tot = sum(M2.values())
    check(f'C2 n={n}: sum_P p(P|psi) = 1 exactly for every psi', all(int(tot[i]) == D * 4**int(R[i]) for i in range(N)))
    sym = [P for P in M2 if bin(P[0] & P[1]).count('1') % 2 == 0]; asym = [P for P in M2 if P not in sym]
    check(f'C3 n={n}: antisymmetric outcomes ({len(asym)}) never occur', all(int(M2[P].max()) == 0 for P in asym))
    NR = 2**n
    for k in range(1, n + 1): NR *= 2**(k - 1) + 1
    okp = all(len(np.where(M2[P] > 0)[0]) == NR and all(int(M2[P][i]) == 4**int(R[i]) for i in np.where(M2[P] > 0)[0]) for P in sym)
    check(f'C4 n={n}: each of the {len(sym)} = D(D+1)/2 symmetric outcomes has exactly N_R = {NR} states with p = 1/D (others p = 0)', okp and len(sym) == D * (D + 1) // 2)
    g = F(6, D * D * (D + 1) * (D + 2)); V = F(0); okn = okr = oku = oko = True
    test_ov = sym if n <= 3 else [(0, 0), (0, 1), (5, 10), (15, 15)]
    for P in sym:
        C, Pm = chi24(P[0], P[1], n); cr, ci = gint(C)
        cn = F(int((cr * cr).sum() + (ci * ci).sum()), 576); okn &= cn == F(D * (D + 2), 3)
        idx = np.where(M2[P] > 0)[0]; Ss = S[idx]; r = R[idx]
        if P in test_ov:
            mr, mi = gint((Ss * papply(Ss, P[0], P[1], n)).sum(axis=1)); m = mr + 1j * mi
            for c0 in range(0, len(idx), 3000):
                lhs = ov4(np.conj(Ss[c0:c0 + 3000]), C); oko &= bool(np.abs(lhs - 24 * np.conj(m[c0:c0 + 3000])**2).max() == 0)
        # Rayleigh quotient of chi_P: (1/N) sum p |psi^T P psi|^4 / ||chi||^2 ; on the support p = 1/D and |psi^T P psi| = 1
        lo = F(sum(F(int(M2[P][i]), D * 4**int(R[i])) * F(int(M2[P][i])**2, 16**int(R[i])) for i in idx), N) / cn; okr &= lo == g
        # Gershgorin on the Gram matrix G_ab = (1/N) sqrt(p_a p_b) <psi_a|psi_b>^4, |<a|b>|^4 = |m_ab|^4 / 4^{r_a + r_b}
        mr, mi = gint(np.conj(Ss) @ Ss.T); a4 = (mr * mr + mi * mi)**2; w = (4**(n - r)).astype(np.int64)
        rows = (a4 * w[None, :]).sum(axis=1) * w; up = F(int(rows.max()), 4**(2 * n) * N * D); oku &= up == g
        V += lo
    check(f'C5 n={n}: ||chi_P||^2 = D(D+2)/3 = {F(D * (D + 2), 3)} for every symmetric P', okn)
    check(f'C6 n={n}: overlap identity <psi^4|chi_P> = conj(psi^T P psi)^2 exactly ({len(test_ov)} outcomes, all states)', oko)
    check(f'C7 n={n}: Rayleigh quotient of chi_P = g(D) = {g} for every symmetric P (lower bound on lambda_max(A_P))', okr)
    check(f'C8 n={n}: Gershgorin bound max_a sum_b |G_ab| = g(D) for every symmetric P (upper bound) => lambda_max(A_P) = g exactly', oku)
    check(f'C9 n={n}: Bell value V = D(D+1)/2 * g = {V} = 3/(D(D+2))', V == F(3, D * (D + 2)))
    r0, c, d = seed_parts(D); sg = compare(V, D)
    check(f'C10 n={n}: seed value = {r0} + {c}*sqrt({d}); exact sign(V - seed) = {sg:+d} (expected {"+1" if n >= 4 else "-1"})', sg == (1 if n >= 4 else -1))
    if n == 4:
        check('C10b n=4: seed value = (11 + sqrt(85))/2304, V - seed = (13 - sqrt(85))/2304 > 0 because 13^2 = 169 > 85',
              (r0, c, d) == (F(11, 2304), F(1, 2304), 85) and V - r0 == F(13, 2304) and 13**2 > 85)
    # C11-C12: operator identity rho_0 = rho_B (E1 orbit-0 state = Choi-type state of the Bell strategy)
    if os.path.exists(data) and (n <= 3 or '--n4-range' in sys.argv):
        orb = [frozenset(N_) for N_ in json.load(open(data))['orbit0']]
        def isrel(N_):
            pts = set(N_); ok = len(pts) == 64 and 0 in pts and 4095 in pts
            ok &= all((u ^ v) in pts for u in pts for v in pts)                                    # subspace (64 = 2^6 points)
            ok &= all((bin(u >> 6).count('1') - bin(u & 63).count('1')) % 4 == 0 for u in pts)     # q-isotropic (q = |x| - |y| mod 4)
            return ok
        def perm6(p, x): return sum(((x >> (5 - p[c])) & 1) << (5 - c) for c in range(6))
        G2 = [p for p in itertools.permutations(range(6)) if set(p[:2]) == {0, 1}]                # S_2 x S_4 on copies
        orbit_gen = {frozenset((perm6(p, u >> 6) << 6) | perm6(q, u & 63) for u in orb[0]) for p in G2 for q in G2}
        tr_closed = all(frozenset(((u & 63) << 6) | (u >> 6) for u in N_) in set(orb) for N_ in orb)
        if n == 1: check('C11a: the 18 orbit-0 elements are 6-dim q-isotropic subspaces of F_2^12 containing 1_12, form ONE (S2xS4)^2 orbit, closed under transpose',
                         all(isrel(N_) for N_ in orb) and orbit_gen == set(orb) and len(orb) == 18 and tr_closed)
        lam = 6 * D * (D + 2); nP = D * (D + 1) // 2
        rmat = []
        for N_ in orb:
            m_ = np.zeros((64, 64), np.int64)
            for u in N_: m_[u >> 6, u & 63] = 1
            rmat.append(m_)
        trb = sum(int(np.trace(m_))**n for m_ in rmat); trb2 = sum(int(np.trace(m1 @ m2))**n for m1 in rmat for m2 in rmat)
        # Rayleigh test <v_P| b_0 |v_P> = lam |v_P|^2 with v_P = Phi'_P (x) 24 chi_P (real integer vectors)
        def f(x, q): return sum(((x >> (5 - c)) & 1) * 2**(n - 1 - q) * D**(5 - c) for c in range(6))
        vec = {}
        for P in sym:
            C, Pm = chi24(P[0], P[1], n); vec[P] = (gint(Pm)[0].reshape(-1), gint(C)[0].reshape(-1))
        lhs = {P: 0 for P in sym}
        for N_ in orb:                                   # relations outer (memory), outcomes inner
            X = np.zeros(1, np.int64); Y = np.zeros(1, np.int64); el = sorted(N_)
            for q in range(n):
                X = (X[:, None] + np.array([f(u >> 6, q) for u in el])[None, :]).reshape(-1); Y = (Y[:, None] + np.array([f(u & 63, q) for u in el])[None, :]).reshape(-1)
            for P in sym:
                v = np.outer(vec[P][0], vec[P][1]).reshape(-1); lhs[P] += int((v[X] * v[Y]).sum())
            del X, Y
        okR = all(lhs[P] == lam * int((vec[P][0]**2).sum()) * int((vec[P][1]**2).sum()) for P in sym)
        check(f'C12 n={n}: b_0 = sum of the 18 R(N): tr b_0 = {trb} = {nP}*{lam}, tr b_0^2 = {nP}*{lam}^2, <v_P|b_0|v_P> = {lam}|v_P|^2 for all {nP} P '
              f'=> b_0 = {lam} * sum_P v^_P v^_P^T, i.e. rho_0 = rho_B (Bell strategy, separable)', okR and trb == nP * lam and trb2 == nP * lam * lam)
print(f'\nPASS: {len(PASS)}  FAILS: {len(FAIL)}')
sys.exit(1 if FAIL else 0)
