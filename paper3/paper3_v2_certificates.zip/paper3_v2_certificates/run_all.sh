#!/bin/bash
# Re-runs every bundled check at sizes that fit in ~1 GB of memory per process (Python 3 with numpy, scipy, sympy, mpmath).
# The three larger runs (n = 3, 2->4 certificate; full Bell-sampling checks at n = 4, 5) are in run_full_checks.ps1
# (or run them by hand, see README). Each check writes logs/<name>.log and is judged PASS only if it exits with status 0
# AND its log contains the expected success marker. The script exits 1 if any check fails.
cd "$(dirname "$0")"; mkdir -p logs; FAILED=0
run(){ name=$1; dir=$2; marker=$3; need=$4; shift 4; t0=$SECONDS
  ( cd "$dir" && "$@" ) > logs/$name.log 2>&1; rc=$?
  got=$(grep -c -E "$marker" logs/$name.log)
  if [ $rc -eq 0 ] && [ "$got" -ge "$need" ]; then st=PASS; else st=FAIL; FAILED=1; fi
  echo "$st  $name  (exit $rc, markers $got/$need, $((SECONDS-t0)) s)"; }
run thm14_classify    thm14_seed_values '"claim_holds": true' 1            python3 m4_classify.py
run thm14_types       thm14_seed_values '"dt_all_coeffs_nonneg": true, .*"dDelta_all_coeffs_nonneg": true' 2  python3 m4_types.py
run thm14_boundary    thm14_seed_values '"all_nonneg": true, .*"const_pos": true' 2  python3 s0_boundary.py
run thm15_algebra     thm15_1to4_all_n  'Sigma_\{5,5\}\| = 270' 1          python3 alg_1to4.py
run thm15_numeric     thm15_1to4_all_n  'b4/24 is the unit: True True' 1  python3 verify_gateC.py
run thm15_charpoly    thm15_1to4_all_n  'mod s\^2 relation: True' 2       python3 verify_gateC_charpoly.py
run thm15_sandwich    thm15_1to4_all_n  'for every D: True' 1             python3 claude_gateC_sandwich.py
run thm15_D2_grok     thm15_1to4_all_n/grok_D2_check/src '"HS_psd": true, .*"HW_psd": true' 4  python3 finite_D_check.py
run thm18_n1          thm18_2to4/n1     'ALL=ok' 6                         python3 claude_cert_checker.py
run thm18_n2          thm18_2to4/n2     'ALL=ok' 7                         python3 claude_checker_n2.py
run thm18_n3_small    thm18_2to4/n3     '"PASS": true' 2                   python3 fresh_checker_n3.py certificates/cert_n3_1to4.json certificates/cert_n3_1to5.json
run thm18_allD_grok   thm18_2to4/all_D  'SUMMARY: [0-9]+ PASS / 0 FAIL' 1  python3 check_gateF3.py
run thm18_allD_claude thm18_2to4/all_D  'mismatches vs exported table: 0' 2  python3 rebuild_t6.py
run prop17_F1_n_le_3  prop17_bell       'FAILS: 0' 1                       python3 check_gateF1_n_le_3.py
run prop17_F2_quick   prop17_bell       'FAILS: 0' 1                       python3 check_gateF2.py --quick
run prop17_n4_claude  prop17_bell       'Bell beats seed: True' 1          python3 claude_bell_sampling_n4.py
if [ $FAILED -eq 0 ]; then echo "ALL CHECKS PASSED"; else echo "SOME CHECK FAILED"; fi
exit $FAILED
