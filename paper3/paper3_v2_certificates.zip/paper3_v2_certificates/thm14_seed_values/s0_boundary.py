"""Gate B §0(b) (own code): close the Gate A boundary case D = 2^k symbolically for all a = 2^T >= 2.
The polynomials are copied verbatim from r32/gateA/logs (m4_types, field 'boundary_D=2^k'); substitute a = 2 + v (v >= 0) and
check that every coefficient in v is >= 0 and the constant term is > 0 (then the value is > 0 for every real a >= 2)."""
import sympy as sp, json
a, v = sp.symbols('a v')
P = {1: (a + 1)*(a + 2)*(2*a + 1)*(4*a - 5)/2, 2: (a + 1)*(a + 2)*(8*a**2 + 6*a - 23)/2}
for k, f in P.items():
    g = sp.Poly(sp.expand(f.subs(a, 2 + v)), v); co = g.all_coeffs()
    print(json.dumps(dict(k=k, poly_in_v=str(g.as_expr()), coeffs=[str(x) for x in co], all_nonneg=all(x >= 0 for x in co),
                          const=str(co[-1]), const_pos=bool(co[-1] > 0))))
