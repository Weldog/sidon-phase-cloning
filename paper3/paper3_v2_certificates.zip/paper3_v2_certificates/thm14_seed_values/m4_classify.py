"""m = 4 class classification for EVERY n, by a finite check (own code, exact).
Copy matrix X (4 x n); pattern map P(y) = X y in F_2^4 (y in F_2^n); character of the multiset = the Z4 form q = Q o P,
Q(u) = |u| mod 4 (bit counts mod 4 = Q(P e_i); pair counts mod 2 = beta(P e_i, P e_j), beta = dot product).
Two multisets X, X' have the same character iff L = {(P y, P' y)} is totally isotropic for Q (+) -Q on F_2^4 (+) F_2^4.
Claim: for every totally isotropic L there is sigma in S_4 with u' + sigma(u) in {0, 1111} for all (u, u') in L.
Then X' = sigma X + 1111 a^T for some a in F_2^n (a.y = the {0,1111}-coefficient, linear in y): X' is a common translate.
Since the property passes to subspaces, every n reduces to this finite check (L has dimension <= 8, independent of n).
Used in gateA.md Sec. 3.4 (class types and quotients are derived there).
[Transcribed verbatim by Claude from Grok Bot's R13d Gate A report for the certificate bundle.]"""
import itertools, json
m = 4; ALL = (1 << m) - 1
Q = lambda u: bin(u).count('1') % 4
vecs = [(u, v) for u in range(16) for v in range(16) if Q(u) == Q(v)]
def iso_pair(a, b):
    (u, v), (x, y) = a, b
    return Q(u ^ x) == Q(v ^ y)
perms = [p for p in itertools.permutations(range(m))]
def act(p, u): return sum(((u >> i) & 1) << p[i] for i in range(m))
# BFS over totally isotropic subspaces (as frozensets of pairs encoded u*16+v)
def span(gens):
    S = {(0, 0)}
    for g in gens: S |= {(s[0] ^ g[0], s[1] ^ g[1]) for s in S}
    return frozenset(S)
level = {frozenset({(0, 0)})}; total = 0; maxdim = 0; bad = 0
while level:
    nxt = set()
    for L in level:
        total += 1
        ok = any(all((v ^ act(p, u)) in (0, ALL) for (u, v) in L) for p in perms)
        if not ok: bad += 1
        for g in vecs:
            if g in L: continue
            if all(iso_pair(g, l) for l in L) and Q(g[0]) == Q(g[1]):
                L2 = span(list(L) + [g])
                if all(Q(a ^ c) == Q(b ^ d) for (a, b) in L2 for (c, d) in [g]):
                    nxt.add(L2)
    if level: maxdim = max(maxdim, max(len(L) for L in level).bit_length() - 1)
    level = nxt
print(json.dumps(dict(m=m, totally_isotropic_subspaces=total, max_dim=maxdim, violations=bad, claim_holds=bad == 0)))
