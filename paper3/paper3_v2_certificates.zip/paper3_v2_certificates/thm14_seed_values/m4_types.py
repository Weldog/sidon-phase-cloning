"""m = 4, every n (own code; exact symbolic in D = 2^n and a = 2^T, s = T + 4). Uses m4_classify.py: each chi-class is a
common-translation orbit {c + a} (if the 4 vectors sum to 0) or a singleton. Translation-orbit types (c normalised to contain 0):
  k = 0: {0,0,0,0} (trivial class);  k = 1: {0,0,x,x} (mult 6);  k = 2: {0,x,y,x+y} (mult 24); in all three Stab = span(c) = W.
Quotient (A = G Dm form, Z-scaled) on the orbits {abar = 0}, {abar != 0} of F_2^n / W (h = D/2^k cosets):
  K_k = mu [[c_k, (h-1) c_{k+1}], [c_{k+1}, c_{k+1} + (h-2) c_{k+2}]],  w(abar, abar') = k + dim span(abar, abar').
Singletons: rho = mu c_k / Z (k = dim span c, mu <= 4, 12, 24, 24 for k = 1, 2, 3, 4) < c_0 / Z = M11 <= lam_triv.
Checks lam_M > lam_K for k = 1, 2 symbolically (D >= 2^(k+1)) plus the boundary D = 2^k (1x1 class).
[Transcribed verbatim by Claude from Grok Bot's R13d Gate A report for the certificate bundle.]"""
import sympy as sp, json
D, a, u, v = sp.symbols('D a u v', positive=True)
def cs(m):
    qf = lambda w: a*sp.Rational(2)**(m - w - 2) + 1                      # c_w / c_{w+1} = 2^{s-w-2} + 1, s = T + m, 2^T = a
    c = {4: sp.Integer(1)}
    for w in (3, 2, 1, 0): c[w] = sp.expand(qf(w)*c[w + 1])
    return c
m = 4; c = cs(m); Cm = 1
tM = c[0] + Cm*(c[1] + (D - 2)*c[2]); dM = c[0]*Cm*(c[1] + (D - 2)*c[2]) - Cm*(D - 1)*c[1]**2
lamM = (tM + sp.sqrt(tM**2 - 4*dM))/2
out = []
for k, mu in [(1, 6), (2, 24)]:
    h = D/2**k
    tK = mu*(c[k] + c[k + 1] + (h - 2)*c[k + 2]); dK = mu**2*(c[k]*(c[k + 1] + (h - 2)*c[k + 2]) - (h - 1)*c[k + 1]**2)
    dt = sp.expand(tM - tK); dDel = sp.expand((tM**2 - 4*dM) - (tK**2 - 4*dK))
    D0 = 2**(k + 1)
    P1 = sp.Poly(sp.expand(dt.subs({D: D0 + u, a: 2 + v})), u, v); P2 = sp.Poly(sp.expand(dDel.subs({D: D0 + u, a: 2 + v})), u, v)
    r = dict(k=k, mu=mu, D_from=D0, dt=str(sp.factor(dt)), dDelta=str(sp.factor(dDel)),
             dt_all_coeffs_nonneg=all(x >= 0 for x in P1.coeffs()), dt_at_corner=str(P1.eval((0, 0))),
             dDelta_all_coeffs_nonneg=all(x >= 0 for x in P2.coeffs()))
    # boundary D = 2^k: the class is one element, rho = mu c_k; lam_M >= M11 = c_0 and c_0 / c_k vs mu
    r['boundary_D=2^k'] = str(sp.factor(c[0] - mu*c[k])) + ' (> 0 for a >= 2 shows M11 > rho)'
    r['boundary_positive_a2_to_a1024'] = all((c[0] - mu*c[k]).subs(a, 2**T) > 0 for T in range(1, 11))
    print(json.dumps(r)); out.append(r)
# singletons: mu_max(k) c_k < c_0 for all a >= 2
sing = {1: 4, 2: 12, 3: 24, 4: 24}
print(json.dumps(dict(singletons={k: str(sp.factor(c[0] - mu*c[k])) for k, mu in sing.items()},
                      singleton_bound_coeffs_nonneg={k: all(x >= 0 for x in sp.Poly(sp.expand((c[0] - mu*c[k]).subs(a, 2 + v)), v).coeffs()) for k, mu in sing.items()})))
