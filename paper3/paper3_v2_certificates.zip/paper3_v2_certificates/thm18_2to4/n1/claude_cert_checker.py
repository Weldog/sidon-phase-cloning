# Claude's INDEPENDENT checker for Grok's Gate 3 certificates, written from README_certificates.md alone
# (Grok's g3_verify.py / fresh_checker.py were not read or used). Exact arithmetic only.
import json, sys
from fractions import Fraction as Fr
from math import comb

class Q:  # element a + b*sqrt(d) of Q(sqrt d), d squarefree non-square (or d=0 -> rational)
    __slots__=('a','b','d')
    def __init__(s,a,b=0,d=0): s.a=Fr(a); s.b=Fr(b); s.d=d
    def _co(s,o): return o if isinstance(o,Q) else Q(o,0,s.d)
    def __add__(s,o): o=s._co(o); return Q(s.a+o.a, s.b+o.b, s.d or o.d)
    def __sub__(s,o): o=s._co(o); return Q(s.a-o.a, s.b-o.b, s.d or o.d)
    def __neg__(s): return Q(-s.a,-s.b,s.d)
    def __mul__(s,o):
        o=s._co(o); d=s.d or o.d
        return Q(s.a*o.a + s.b*o.b*d, s.a*o.b + s.b*o.a, d)
    def inv(s):
        den=s.a*s.a - s.b*s.b*s.d; assert den!=0
        return Q(s.a/den, -s.b/den, s.d)
    def __truediv__(s,o): return s*s._co(o).inv()
    def iszero(s): return s.a==0 and s.b==0
    def sign(s):
        a,b,d=s.a,s.b,s.d
        if b==0 or d==0: return (a>0)-(a<0)
        if a>=0 and b>=0: return 1
        if a<=0 and b<=0: return -1
        if a>0>b: v=a*a-b*b*d; return (v>0)-(v<0)
        v=b*b*d-a*a; return (v>0)-(v<0)
    def __eq__(s,o): o=s._co(o); return (s-o).iszero()
def rat(x): return Fr(x)
def elem(o,d):
    if isinstance(o,str): return Q(rat(o),0,d)
    assert int(o['d']) in (0,d); return Q(rat(o['a']), rat(o['b']), d)

def Ktilde(T,m):
    # README §2: six states, mu_{j,l}(S) = a^{T+m-j-l} b^{j+l}; Ktilde = (1/6) sum_S mu * conj(mu')
    # Gaussian-integer representation: states (a,b) up to the 1/sqrt2 factor; scale 1 or 1/2^{T+m}
    st=[((1,0),(0,0),1),((0,0),(1,0),1),((1,0),(1,0),2),((1,0),(-1,0),2),((1,0),(0,1),2),((1,0),(0,-1),2)]
    def gmul(x,y): return (x[0]*y[0]-x[1]*y[1], x[0]*y[1]+x[1]*y[0])
    def gpow(x,e):
        r=(1,0)
        for _ in range(e): r=gmul(r,x)
        return r
    idx=[(j,l) for j in range(T+1) for l in range(m+1)]
    n=len(idx); K=[[Fr(0)]*n for _ in range(n)]; IM=[[Fr(0)]*n for _ in range(n)]
    for a,b,norm in st:
        scale=Fr(1, norm**(T+m)) if norm==2 else Fr(1)
        mus=[gmul(gpow(a,T+m-j-l), gpow(b,j+l)) for (j,l) in idx]
        for p in range(n):
            for q in range(n):
                x=mus[p]; y=(mus[q][0],-mus[q][1]); z=gmul(x,y)
                K[p][q]+=Fr(z[0])*scale/6; IM[p][q]+=Fr(z[1])*scale/6
    assert all(v==0 for r in IM for v in r), "imaginary part did not cancel"
    return K
def Gamma(X,T,m):   # README §3: (X^Γ)[(j,l),(j',l')] = X[(j',l),(j,l')]
    P=lambda j,l: j*(m+1)+l; n=(T+1)*(m+1); Y=[[None]*n for _ in range(n)]
    for j in range(T+1):
        for l in range(m+1):
            for j2 in range(T+1):
                for l2 in range(m+1): Y[P(j,l)][P(j2,l2)]=X[P(j2,l)][P(j,l2)]
    return Y
def is_psd(M):      # README test (i): diagonal-pivot LDL^T with zero handling, exact
    M=[row[:] for row in M]; idxs=list(range(len(M)))
    while idxs:
        for i in idxs:
            if M[i][i].sign()<0: return False
        zero=[i for i in idxs if M[i][i].iszero()]
        for i in zero:
            if any(not M[i][j].iszero() for j in idxs): return False
        idxs=[i for i in idxs if i not in zero]
        if not idxs: return True
        p=idxs[0]; piv=M[p][p]; rest=idxs[1:]
        for i in rest:
            f=M[i][p]/piv
            for j in rest: M[i][j]=M[i][j]-f*M[p][j]
        idxs=rest
    return True

def check(fn):
    J=json.load(open(fn)); T,k=int(J['T']),int(J['k']); m=T+k; d=int(J['d']); n=(T+1)*(m+1)
    R={}
    lam=elem(J['lam'],d)
    Kt=Ktilde(T,m); R['K_recomputed_equal']=all(Kt[p][q]==rat(J['K_tilde'][p][q]) for p in range(n) for q in range(n))
    ci=[Fr(1,comb(T,j)*comb(m,l)) for j in range(T+1) for l in range(m+1)]
    R['Cinv2']=ci==[rat(x) for x in J['Cinv2_diag']]
    W=[[elem(x,d) for x in r] for r in J['W_tilde']]; S=[[elem(x,d) for x in r] for r in J['S_tilde']]
    R['shapes']=len(W)==n and all(len(r)==n for r in W) and len(S)==n and len(J['primal_witness_psi_tilde'])==n
    R['W_symmetric']=all(W[i][j]==W[j][i] for i in range(n) for j in range(n))
    GW=Gamma(W,T,m)
    R['slack_identity']=all(S[i][j]==((lam*ci[i]) if i==j else Q(0,0,d))-Q(Kt[i][j],0,d)-GW[i][j] for i in range(n) for j in range(n))
    R['W_psd']=is_psd(W); R['S_psd']=is_psd(S)
    psi=[elem(x,d) for x in J['primal_witness_psi_tilde']]
    supp=all(psi[j*(m+1)+l].iszero() for j in range(1,T+1) for l in range(m+1))
    num=Q(0,0,d); den=Q(0,0,d)
    for i in range(n):
        den=den+psi[i]*psi[i]*ci[i]
        for j in range(n): num=num+psi[i]*Q(Kt[i][j],0,d)*psi[j]
    R['primal_witness']=supp and not all(x.iszero() for x in psi) and num==lam*den
    R['ALL']=all(R.values())
    return T,k,f"{lam.a} + {lam.b}*sqrt({d})",R

if __name__=='__main__':
    base='./'
    for c in ['1to3','2to3','1to4','1to5','2to4','3to4']:
        T,k,lam,R=check(base+f'cert_n1_{c}.json')
        print(f"{c}: lambda = {lam}  ->  " + ", ".join(f"{a}={'ok' if b else 'FAIL'}" for a,b in R.items()))
    # negative control: perturb lambda by 1e-6 in one certificate -> slack identity or PSD must fail
    J=json.load(open(base+'cert_n1_1to4.json'))
    J['lam']['a']=str(Fr(J['lam']['a'])-Fr(1,10**6)); json.dump(J,open('./neg_1to4.json','w'))
    print("negative control (lambda lowered by 1e-6):", check('./neg_1to4.json')[3]['ALL'])
