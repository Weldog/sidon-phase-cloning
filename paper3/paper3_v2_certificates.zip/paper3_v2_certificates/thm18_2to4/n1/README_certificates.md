# Gate 3 certificates (n = 1): exact PPT dual certificates for the PGM-seed optimum. README for independent checking

Private; nothing published or sent. Grok Bot, 23 Oct 2026 (PT). All files here were produced by my own code (`r29/g3_exact.py` in gate 3, re-encoded by `r30/export_certs.py`). They are **not** independently verified. This README is written so that a checker can be built from it alone.

## 1. What the certificates prove, and what they do not

**Proved by each certificate, once checked** (CA, own code until someone else checks it). Take n = 1 (one qubit) and (T,k) in the case list below, with m = T+k. Then

  P_PPT := max { tr(K ρ) : ρ ⪰ 0 on Sym^T ⊗ Sym^m, tr ρ = 1, ρ^Γ ⪰ 0 } = λ,

where λ is the stated number and equals λmax(B_{T,k}). Since product states φ⊗χ are PPT, the product-state optimum Λ := max_{φ,χ} ⟨φ⊗χ|K|φ⊗χ⟩ satisfies λmax(B) ≤ Λ ≤ P_PPT = λ = λmax(B). Hence **Λ = λmax(B)**: the PGM seed φ = |0^T⟩ is optimal among all product seeds, and even among PPT-entangled seed/output pairs.

**Relies on (not certified here).**
- The operational reading "EB* = D_T·Λ, the best measure-and-prepare (entanglement-breaking) cloning fidelity" is **Lemma R** (ledger F6: DERIVED, needs referee). The certificate itself is a statement about the matrix K only.
- The achievability EB* ≥ D_T λmax(B) is an explicit scheme (PGM, then U^{⊗m}χ*), valid for T ≤ 3.

**Cases** (file `certificates/cert_n1_<case>.json`):

| case | T | k | m | dim Sym^T × dim Sym^m = n | λ (exact) | d |
|---|---|---|---|---|---|---|
| 1to3 | 1 | 2 | 3 | 2 × 4 = 8 | 5/24 | 0 (rational) |
| 2to3 | 2 | 1 | 3 | 3 × 4 = 12 | 3/16 | 0 |
| 1to4 | 1 | 3 | 4 | 2 × 5 = 10 | 5/48 + √17/48 | 17 |
| 1to5 | 1 | 4 | 5 | 2 × 6 = 12 | 11/96 + √41/96 | 41 |
| 2to4 | 2 | 2 | 4 | 3 × 5 = 15 | 3/32 + √65/96 | 65 |
| 3to4 | 3 | 1 | 4 | 4 × 5 = 20 | 17/192 + √257/192 | 257 |

The cloning values are D_T·λ, with D_T = T+1 at n = 1: 5/12, 9/16, (5+√17)/24, (11+√41)/48, 9/32+√65/32, (17+√257)/48.

## 2. The operator K and the basis

**States.** The six one-qubit stabilizer states S = a|0⟩ + b|1⟩, each with weight 1/6:

| S | (a, b) |
|---|---|
| \|0⟩ | (1, 0) |
| \|1⟩ | (0, 1) |
| \|+⟩ | (1, 1)/√2 |
| \|−⟩ | (1, −1)/√2 |
| \|+i⟩ | (1, i)/√2 |
| \|−i⟩ | (1, −i)/√2 |

**Bases.**
- Sym^T(C²) has the orthonormal Dicke basis |D^T_j⟩, j = 0..T, where j is the number of 1s. Likewise |D^m_l⟩, l = 0..m, for Sym^m.
- Product index: p = j·(m+1) + l, with j the outer index (the Sym^T / seed / measured factor) and l the inner index (the Sym^m / output factor). All matrices are n×n with n = (T+1)(m+1), rows and columns in this order.

**Operator.** K := (1/6) Σ_S |S^{⊗T}⟩⟨S^{⊗T}| ⊗ |S^{⊗m}⟩⟨S^{⊗m}|, restricted to Sym^T ⊗ Sym^m. This is the compression of the stabilizer moment operator in ledger F6. Since ⟨D^T_j|S^{⊗T}⟩ = √C(T,j)·a^{T−j}b^j,

  K[(j,l),(j′,l′)] = √(C(T,j)C(m,l)C(T,j′)C(m,l′)) · K̃[(j,l),(j′,l′)],
  K̃[(j,l),(j′,l′)] = (1/6) Σ_S μ_{j,l}(S) · conj(μ_{j′,l′}(S)),  with μ_{j,l}(S) = a^{T+m−j−l} b^{j+l}.

K̃ is real rational: the imaginary parts cancel between \|+i⟩ and \|−i⟩.

**Scaling.** Let C = diag(c_p) with c_p = √(C(T,j)·C(m,l)). Then K = C K̃ C. Every matrix in the JSON is in this rational scaled form X̃ = C^{−1} X C^{−1}, and C^{−2} = diag(1/(C(T,j)C(m,l))) is the field `Cinv2_diag`.

**Seed operator.** B_{T,k} := ⟨0^T|K|0^T⟩ (partial inner product on the Sym^T factor) = (1/6)Σ_S |⟨0|S⟩|^{2T}|S^{⊗m}⟩⟨S^{⊗m}|. It is the j = j′ = 0 block of K.

## 3. Primal (PPT relaxation) and dual

**Partial transpose Γ.** It acts on the **Sym^T (seed, first, outer-index j) factor**, in the Dicke basis:

  (X^Γ)[(j,l),(j′,l′)] := X[(j′,l),(j,l′)].

The same formula applies to scaled matrices, because the diagonal congruence by C commutes with Γ (c_p factorises as c_j·c′_l).

Why this is a valid relaxation: for a product state, (|φ⟩⟨φ| ⊗ |χ⟩⟨χ|)^Γ = |φ̄⟩⟨φ̄| ⊗ |χ⟩⟨χ| ⪰ 0 in any fixed basis. So every product state is feasible.

**Primal.** max tr(Kρ) subject to ρ ⪰ 0 (complex Hermitian n×n), tr ρ = 1, ρ^Γ ⪰ 0.

**Dual and weak duality.** For a real y and a real symmetric W, suppose:
- (D1) W ⪰ 0;
- (D2) S := y·I − K − W^Γ ⪰ 0.

Then every primal-feasible ρ has y − tr(Kρ) = tr(Sρ) + tr(W^Γρ) = tr(Sρ) + tr(Wρ^Γ) ≥ 0. So P_PPT ≤ y.

In scaled form, congruence by C^{−1} gives the equivalent conditions:
- W̃ ⪰ 0;
- S̃ := y·C^{−2} − K̃ − W̃^Γ ⪰ 0, where W̃ = C^{−1}WC^{−1} and S̃ = C^{−1}SC^{−1}.

The certificates use y = λ.

**Primal witness (lower bound, zero gap).**
- ψ̃ is a real vector supported on the j = 0 block. The orthonormal vector is ψ = C^{−1}ψ̃/‖·‖, i.e. ψ = |0^T⟩ ⊗ χ*.
- Its value is ⟨ψ|K|ψ⟩/⟨ψ|ψ⟩ = (ψ̃ᵀ K̃ ψ̃)/(ψ̃ᵀ C^{−2} ψ̃).
- It is a product state, hence PPT-feasible and also a seed-strategy value. If the value equals λ, then P_PPT ≥ Λ ≥ λmax(B) ≥ λ.
- Together with the dual, all of these equal λ.

## 4. JSON fields (`certificates/cert_n1_<case>.json`)

**Encoding of field elements.**
- A rational is a string "p/q" or "p": decimal integers, q > 0, sign on p.
- An element of Q(√d) is an object {"a": rational, "b": rational, "d": integer}, meaning a + b·√d with the positive square root.
- d = 0 means the entry is rational, and then b must be "0".
- Within one file every element has the same d (the top-level `d`). d is squarefree and is not a perfect square: 17, 41, 65 = 5·13, 257.

| field | shape | encoding | meaning |
|---|---|---|---|
| case, T, k, m, n_qubits | scalars | string / int | case id; n_qubits = 1 |
| d | int | 0 or squarefree | the radical of the case |
| dims | object | ints | seed_factor_SymT = T+1, output_factor_Symm = m+1, total = n |
| basis, scaling | strings | text | as in §2 |
| lam | 1 element | Q(√d) | the claimed value λ = y (dual objective) = primal witness value = λmax(B) |
| Cinv2_diag | n | rational | C^{−2} diagonal, entry p = 1/(C(T,j)C(m,l)) |
| K_tilde | n×n | rational | K̃. Provided for convenience; a checker should **recompute** it from §2 and compare |
| W_tilde | n×n | Q(√d) | the dual variable W̃ (scaled) |
| S_tilde | n×n | Q(√d) | the slack S̃ = λC^{−2} − K̃ − W̃^Γ. Provided; the checker must verify the identity |
| primal_witness_psi_tilde | n | Q(√d) | ψ̃ (zero outside the j = 0 block) |
| source | string | text | provenance |

**Extra files.** `certificates/rational_neartight_n1_<case>.json` are **secondary**, purely rational near-tight certificates: fields T, k, y (rational string), W (n×n rational strings, scaled form W̃). They prove P_PPT ≤ y with y − λ ≤ 3.0e−8, and are useful as a cross-check without radicals.

## 5. Checklist: what a checker must verify (all exactly; no floating point)

For each of the six files:
1. **Shape.** n = (T+1)(m+1). Every matrix is n×n, every vector has length n, and all elements have the file's d.
2. **K̃.** Recompute K̃ from §2 (six states, μ_{j,l}, weight 1/6). Check that it equals `K_tilde` entrywise and is real symmetric.
3. **C^{−2}.** `Cinv2_diag[p]` = 1/(C(T,j)C(m,l)) for p = j(m+1)+l.
4. **Symmetry.** W̃ is symmetric (W̃ = W̃ᵀ). This also makes S̃ symmetric: W̃^Γ is symmetric when W̃ is.
5. **Equality constraint (slack identity).** S̃ = λ·diag(Cinv2_diag) − K̃ − Γ(W̃), entrywise in Q(√d), with Γ as in §3 on the j index.
6. **PSD: W̃ ⪰ 0**, exactly over Q(√d) ⊂ ℝ.
7. **PSD: S̃ ⪰ 0**, exactly. (6 and 7 together are the dual feasibility (D1), (D2) in scaled form. The dual objective is λ.)
8. **Primal witness.** ψ̃ ≠ 0. ψ̃_p = 0 for every p with j ≥ 1 (so it is |0^T⟩ ⊗ χ, a product state). ψ̃ᵀK̃ψ̃ = λ·ψ̃ᵀdiag(Cinv2_diag)ψ̃ exactly.
9. **Conclusion.** If 1–8 pass, then dual objective λ = primal value λ, so P_PPT = Λ = λmax(B_{T,k}) = λ.
   - Optional: check λ against the characteristic polynomial of B. It is not needed, because step 8 plus the dual already pin λmax(B) = λ.

**Exact arithmetic in Q(√d), d > 0 not a square.**
- Sign of a + b√d:
  - if a, b ≥ 0 (not both 0): positive;
  - if a, b ≤ 0: negative;
  - if a > 0 > b: sign(a² − b²d);
  - if a < 0 < b: sign(b²d − a²).
  - Zero iff a = b = 0.
- Inverse: (a + b√d)^{−1} = (a − b√d)/(a² − b²d). The denominator is nonzero unless a = b = 0, since d is not a square.

**Exact PSD tests (any one suffices, for a real symmetric matrix M).**
- (i) **Diagonal-pivot LDLᵀ with zero handling.** Repeat on the remaining matrix:
  - if some diagonal entry is < 0: NOT PSD;
  - if a diagonal entry is 0, its whole row and column must be 0 (else NOT PSD); drop it;
  - otherwise pick a diagonal pivot π > 0 and replace the rest by the Schur complement M′ = M_rest − v vᵀ/π.
  - PSD iff the procedure ends without failure.
- (ii) **All principal minors ≥ 0.** Not just the leading ones; 2^n − 1 determinants.
- (iii) **Characteristic polynomial.** With det(xI + M) = Σ_k e_k x^{n−k}, M is PSD iff e_k ≥ 0 for all k; the e_k are the elementary symmetric functions of the eigenvalues. Gate 3 used (iii).

## 6. Reference verifier

`g3_verify.py` (verbatim copy of `r29/g3_verify.py`; it imports `g3_setup.py`, `g3_exact.py`, `g3_cert.py` from r29) reads the **original** sympy-string files `r29/g3/exact_cert_*.json`. It uses test (iii) for PSD and real-root counting for the B check. Its log is `r29/g3_verify.log`. It is for reference only.

A fresh checker written from this README alone is `fresh_checker.py`, with log `fresh_checker.log`. It is own code, not independent.

## 7. Encoding history (honest record)

- The gate-3 files `r29/g3/exact_cert_T{T}_k{k}.json` stored entries as **sympy expression strings** such as "-1/24 + sqrt(17)/96". They were exact but implicit.
- For this export each entry was converted to {"a","b","d"}, asserting a + b√d − x = 0 exactly (`export_certs.py`). K̃, C^{−2}, S̃ and the primal witness ψ̃ were **added**, computed exactly from the same data. No values changed.
- The rational near-tight files `r29/g3/cert_*.json` were already "p/q" strings and were copied unchanged.
