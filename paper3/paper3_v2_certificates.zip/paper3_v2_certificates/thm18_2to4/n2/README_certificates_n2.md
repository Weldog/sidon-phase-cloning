# n = 2 certificates (R13c Step 3): exact PPT dual certificates for the PGM-seed optimum at two qubits. README for independent checking

Private; nothing published or sent. Grok Bot, 23 Oct 2026 (PT). Every file here was produced by my own code (`src/n2_cert.py`, `src/export_n2.py`). **Not independently verified.** A checker can be written from this README and the JSON files alone; no code of mine is needed.

## 1. What each certificate proves, and what it relies on

Fix n = 2 qubits (D = 4) and a case (T, k) from the table, with m = T + k. Once checked, each certificate proves (CA, own code, until someone else checks it):

  P_PPT := max { tr(Kρ) : ρ ⪰ 0 on Sym^T(C^4) ⊗ Sym^m(C^4), tr ρ = 1, ρ^Γ ⪰ 0 } = λ,

where λ is the stated number and equals λmax(B_{T,k}).

Product states φ⊗χ are PPT. So the product-state optimum Λ := max_{φ,χ} ⟨φ⊗χ|K|φ⊗χ⟩ satisfies λmax(B) ≤ Λ ≤ P_PPT = λ = λmax(B). Hence **Λ = λmax(B)**: the PGM seed φ = |00⟩^{⊗T} is optimal among all seeds, and even among PPT seed/output states.

**Relies on (not certified here):**
- The operational reading EB* = D_T·Λ (best measure-and-prepare cloning fidelity). This is Lemma R (ledger v4 F6, PROVED; equality for 1 ≤ T ≤ 3), with D_T = dim Sym^T(C^4) = C(T+3, 3).
- Achievability is the PGM followed by preparing U^{⊗m}χ*.

**Restricting to Sym^T ⊗ Sym^m loses nothing.** Let Π = P_sym^T ⊗ P_sym^m, both real projectors. For any ρ on (C^4)^{⊗T} ⊗ (C^4)^{⊗m} that is PPT across the T|m cut:
- (ΠρΠ)^Γ = Π ρ^Γ Π ⪰ 0;
- tr(K ΠρΠ) = tr(Kρ), since K is supported on the range of Π;
- tr(ΠρΠ) ≤ 1.

So the PPT value over the full space equals the one above. (DERIVED, one line.)

**Which factor Γ transposes does not matter.** Γ transposes the Sym^T (seed) factor. For a real symmetric W̃, transposing the output factor instead gives the same matrix entrywise: W[(a,b′),(a′,b)] = W[(a′,b),(a,b′)]. So the same certificate also certifies the relaxation with Γ on Sym^m. (DERIVED, one line; LV-S2-2.)

| case | T | k | m | dim Sym^T × dim Sym^m = n | λ (exact) | d | rank W̃ | rank S̃ |
|---|---|---|---|---|---|---|---|---|
| 1to2 | 1 | 1 | 2 | 4 × 10 = 40 | 1/20 | 0 | 0 | 20 |
| 1to3 | 1 | 2 | 3 | 4 × 20 = 80 | 1/32 | 0 | 30 | 45 |
| 2to3 | 2 | 1 | 3 | 10 × 20 = 200 | 3/128 | 0 | 140 | 144 |
| 1to4 | 1 | 3 | 4 | 4 × 35 = 140 | 13/960 + √109/960 | 109 | 84 | 84 |
| 1to5 | 1 | 4 | 5 | 4 × 56 = 224 | 13/960 + √226/1920 | 226 | 165 | 164 |
| 2to4 | 2 | 2 | 4 | 10 × 35 = 350 | 41/3840 + √1321/3840 | 1321 | 290 | 290 |
| 3to4 | 3 | 1 | 4 | 20 × 35 = 700 | 29/3072 + √18577/15360 | 18577 | 640 | 640 |

λ is a root of the minimal polynomials 20x − 1; 32x − 1; 128x − 3; 15360x² − 416x + 1; 122880x² − 3328x + 15; 122880x² − 2624x + 3; 4915200x² − 92800x + 51.

The cloning values are D_T·λ, with D_T = 4, 10, 20 for T = 1, 2, 3.

## 2. States, bases, operator

**States** (file `stab_states_n2.json`). There are 60 entries. Each has amplitudes amp_x for x = 0, 1, 2, 3, each a Gaussian integer [re, im] ∈ {0, ±1, ±i}, and an integer k with 2^k = support size. The state is |S⟩ = 2^{−k/2} Σ_x amp_x |x⟩. The labelling is x = 2·x1 + x2, where x1 is the first qubit.

**Bases.**
- Sym^t(C^4) has the orthonormal basis |c⟩ indexed by occupation vectors c = (c_0, c_1, c_2, c_3) with Σ c_x = t. This is the normalised symmetrisation of |x_1…x_t⟩ with c_x copies of x.
- The order is given explicitly in the JSON: `seed_basis_occupations` (t = T, index a) and `output_basis_occupations` (t = m, index b).
- One has ⟨c|S^{⊗t}⟩ = √mult(c) · 2^{−kt/2} · Π_x amp_x^{c_x}, with mult(c) = t!/Π_x c_x!.
- Product index: p = a·d2 + b, with d2 = dim Sym^m. All matrices are n×n in this order.

**Operator.** K := (1/60) Σ_S |S^{⊗T}⟩⟨S^{⊗T}| ⊗ |S^{⊗m}⟩⟨S^{⊗m}| on Sym^T ⊗ Sym^m (the compression in ledger F6).

**Scaling.** Let C = diag(c_p) with c_p² = mult(c_a)·mult(c_b). Then K = C K̃ C, where

  K̃[p, p′] = (1/60) Σ_S 2^{−k_S(T+m)} · Re( μ_p(S) · conj(μ_{p′}(S)) ),  μ_{(a,b)}(S) = Π_x amp_x^{(c_a)_x + (c_b)_x}  (with 0^0 = 1).

The imaginary parts cancel exactly, because the state set is closed under complex conjugation; K̃ is real rational.

Every matrix in the JSON is in the scaled form X̃ = C^{−1} X C^{−1}. `Cinv2_diag[p]` = 1/(mult(c_a)·mult(c_b)).

**Seed operator.** B_{T,k} := ⟨0^T|K|0^T⟩, where a = 0 is the occupation (T,0,0,0), i.e. |00⟩^{⊗T}. It is the a = a′ = 0 block of K.

## 3. Primal, PPT relaxation, dual

**Partial transpose.** Γ transposes the **Sym^T (seed, outer index a) factor** in this real basis:

  (X^Γ)[(a,b),(a′,b′)] := X[(a′,b),(a,b′)].

The same formula holds for scaled matrices, since c_p factorises as c_a·c_b. A transpose in a different basis gives a unitarily congruent PPT cone, so the value is unchanged.

**Primal.** max tr(Kρ) subject to ρ ⪰ 0, tr ρ = 1, ρ^Γ ⪰ 0.

**Dual (weak duality).** Let y be real and W real symmetric with:
- (D1) W ⪰ 0;
- (D2) S := y·I − K − W^Γ ⪰ 0.

Then for every feasible ρ, y − tr(Kρ) = tr(Sρ) + tr(Wρ^Γ) ≥ 0, so P_PPT ≤ y.

In scaled form (congruence by C^{−1}) the conditions read:
- W̃ ⪰ 0;
- S̃ := y·C^{−2} − K̃ − Γ(W̃) ⪰ 0.

The certificates take y = λ.

**Primal witness.** ψ̃ is supported on the a = 0 block (seed |00⟩^{⊗T}). The state is ψ = C^{−1}ψ̃/‖·‖ = |00⟩^{⊗T} ⊗ χ*, and its value is (ψ̃ᵀK̃ψ̃)/(ψ̃ᵀC^{−2}ψ̃). It is a product state, so it is PPT and also a seed-strategy value.

**Block reduction (used only to make the PSD tests small).** The JSON lists:
- `S_blocks`: a partition of {0..n−1}. S̃ must vanish between different parts.
- `W_blocks`: likewise for W̃.

A real symmetric matrix that is zero between the parts of a partition is PSD iff each principal block is PSD (it is a direct sum after a permutation). The checker must verify the vanishing, then test each block.

**Where the blocks come from** (for the reader; the check does not depend on it):
- The block label of index p = (a, b) is a character of the diagonal Clifford group D_2 = ⟨S_1, S_2, CZ⟩, of order 32 mod phases.
- For an occupation c, let χ(c) = (w1 mod 4, w2 mod 4, c_3 mod 2), with w1 = c_2 + c_3 and w2 = c_1 + c_3.
- S-block label: χ(c_a) + χ(c_b). W-block label: χ(c_b) − χ(c_a), componentwise mod (4, 4, 2).
- Why blocks lose no optimality (proof):
  - Let U be a 2-qubit Clifford, V = U^{⊗T} ⊗ U^{⊗m} and Ṽ = Ū^{⊗T} ⊗ U^{⊗m}.
  - V K V† = K, because U permutes the stabilizer states up to phases.
  - (Ṽ X Ṽ†)^Γ = V X^Γ V†. Check on product operators: (ĀxĀ† ⊗ ByB†)^{T_1} = (AxᵀA†) ⊗ ByB†, then extend linearly.
  - So if (y, W) is feasible, (y, ṼWṼ†) is feasible, with slack VSV†.
  - Averaging over a finite group G (phases cancel) keeps W ⪰ 0 and S ⪰ 0, by convexity and linearity of Γ. So an optimal dual with W Ṽ-invariant and S V-invariant exists.
  - For G ⊇ D_2: S_1^α S_2^β CZ^γ acts on |c⟩ by i^{αw1+βw2}(−1)^{γc_3}. An invariant matrix vanishes between unequal characters. For W the character of the seed factor is conjugated (the Ū), which gives the minus sign.
- The search also imposed invariance under AGL(2,2), the permutations x ↦ Ax ⊕ b. These are real permutation matrices, so Ū = U, and they map blocks to blocks.
- The group used is G_1 = D_2 ⋊ AGL(2,2), the monomial Clifford group, of order 768 mod phases. It contains G_0 = Stab_Cl(|00⟩) = D_2 ⋊ GL(2,2), of order 192 = 11520/60.
- The checker needs none of this.

## 4. JSON fields (`cert_n2_<case>.json`)

**Encoding.**
- A rational is the string "p/q" or "p".
- A Q(√d) element is either {"a", "b", "d"} (meaning a + b√d, positive root) or, inside the sparse lists, the pair of strings a, b.
- d = 0 means rational, and then b = 0.
- d is squarefree: 109, 226 = 2·113, 1321, 18577 = 13·1429.

| field | content |
|---|---|
| case, T, k, m, n_qubits (= 2), D (= 4), d | scalars |
| lam | λ as {"a", "b", "d"} |
| dims | seed_factor_SymT = d1, output_factor_Symm = d2, total = n = d1·d2 |
| seed_basis_occupations, output_basis_occupations | lists of occupation vectors (index order) |
| index_rule | p = a·d2 + b |
| Cinv2_diag | n rationals, 1/(mult(c_a)·mult(c_b)) |
| K_tilde_upper | [p, q, rational] for p ≤ q, nonzero entries only. Convenience copy: the checker must **recompute** K̃ from §2 and compare |
| W_tilde_upper | [p, q, a, b] for p ≤ q, nonzero entries only. W̃ is symmetric; absent entries are 0 |
| S_tilde_upper | [p, q, a, b]: convenience copy of S̃ = λC^{−2} − K̃ − Γ(W̃). The checker must verify it |
| primal_witness_psi_tilde | [p, a, b], nonzero entries of ψ̃ (all with a = 0, i.e. p < d2) |
| S_blocks, W_blocks | lists of {character, indices}: partitions of {0..n−1} |
| source | provenance |

## 5. Checklist (all exact; no floating point)

0. **States.** `stab_states_n2.json` has 60 unit vectors (Σ|amp_x|² = 2^k), pairwise non-proportional. Each has exactly 4 Pauli operators P (mod phase) with |⟨S|P|S⟩| = 1, so it is a stabilizer state. Since |Stab(2)| = 60, this is the whole set.
1. **Shapes.** The basis lists are all occupation vectors of the right t, without repetition. n = d1·d2. Indices are in range. The block lists are partitions of {0..n−1}.
2. **K̃.** Recompute from §2 and compare entrywise with K_tilde_upper (absent = 0). The imaginary parts must vanish.
3. **C^{−2}.** Check Cinv2_diag.
4. **Slack identity.** S̃ = λ·diag(Cinv2_diag) − K̃ − Γ(W̃) entrywise (full n×n, with W̃ symmetrised from the upper list). It must equal S_tilde_upper (absent = 0).
5. **Block vanishing.** W̃[p,q] = 0 whenever p, q lie in different W_blocks, and S̃[p,q] = 0 whenever they lie in different S_blocks.
6. **W̃ ⪰ 0.** Each W block, exactly over Q(√d).
7. **S̃ ⪰ 0.** Each S block, exactly. (6 and 7 are the dual feasibility (D1), (D2); the dual objective is λ.)
8. **Primal witness.** ψ̃ ≠ 0 and supported on p < d2 (a = 0, the seed |00⟩^{⊗T}). ψ̃ᵀK̃ψ̃ = λ·ψ̃ᵀ diag(Cinv2_diag) ψ̃ exactly.
9. **Conclusion.** If 0–8 pass, the dual objective λ equals the primal value λ, so P_PPT = Λ = λmax(B_{T,k}) = λ.
   - Optional: λ satisfies the stated minimal polynomial.
   - Optional: S̃ψ̃ = 0 and W̃ψ̃ = 0 (complementary slackness; ψ̃ is real).

**Arithmetic in Q(√d)** (as in the n = 1 README).
- Sign of a + b√d:
  - if a, b ≥ 0 (not both 0): positive;
  - if a, b ≤ 0: negative;
  - if a > 0 > b: sign(a² − b²d);
  - if a < 0 < b: sign(b²d − a²).
- Inverse: (a − b√d)/(a² − b²d).

**PSD test.** Diagonal-pivot LDLᵀ with zero handling. Repeat on the remaining matrix:
- any negative diagonal means NOT PSD;
- a zero diagonal needs a zero row, which is then dropped;
- otherwise pivot on a positive diagonal and take the Schur complement.

The matrix is PSD iff the procedure ends without failure. All principal minors, or the characteristic-polynomial test, also work.

**Negative controls a checker should reject:**
- λ replaced by λ − 10^{−6}, keeping W̃ and recomputing S̃: step 7 must fail.
- Γ omitted (S̃ = λC^{−2} − K̃ − W̃): step 4 or step 7 must fail whenever W̃ ≠ 0.
- One entry of ψ̃ changed: step 8 fails.
- One entry of K_tilde_upper changed: step 2 fails.
