# Claude's INDEPENDENT checker for Grok's n = 2 certificates, written from README_certificates_n2.md alone.
# Grok's fresh_checker_n2.py / src/* were not read or used. Exact arithmetic only.
import json, sys, itertools, numpy as np
from fractions import Fraction as Fr
from math import factorial, prod
sys.path.insert(0,'../../common'); import h2_stabilizer as h2     # Claude's own stabilizer generator (earlier sessions)

class Q:
    __slots__=('a','b','d')
    def __init__(s,a,b=0,d=0): s.a=Fr(a); s.b=Fr(b); s.d=d
    def __add__(s,o): return Q(s.a+o.a, s.b+o.b, s.d or o.d)
    def __sub__(s,o): return Q(s.a-o.a, s.b-o.b, s.d or o.d)
    def __mul__(s,o): d=s.d or o.d; return Q(s.a*o.a+s.b*o.b*d, s.a*o.b+s.b*o.a, d)
    def scale(s,r): return Q(s.a*r, s.b*r, s.d)
    def inv(s): den=s.a*s.a-s.b*s.b*s.d; assert den!=0; return Q(s.a/den,-s.b/den,s.d)
    def iszero(s): return s.a==0 and s.b==0
    def sign(s):
        a,b,d=s.a,s.b,s.d
        if b==0 or d==0: return (a>0)-(a<0)
        if a>=0 and b>=0: return 1
        if a<=0 and b<=0: return -1
        v=(a*a-b*b*d) if a>0>b else (b*b*d-a*a); return (v>0)-(v<0)
Z=lambda d: Q(0,0,d)

def check_states(fn):
    J=json.load(open(fn)); S=J['states']; assert len(S)==60
    vecs=[]
    for s in S:
        amp=[complex(a,b) for a,b in s['amplitudes_gaussian_int']]; k=s['k']
        assert sum(abs(x)**2 for x in amp)==2**k          # unit norm after 2^{-k/2}
        vecs.append((np.array(amp)/2**(k/2), [tuple(a) for a in s['amplitudes_gaussian_int']], k))
    mine=np.array(h2.stab_states(2))                     # Claude's own 60 states
    def match(v): return any(abs(abs(np.vdot(w,v))-1)<1e-12 for w in mine)
    assert all(match(v) for v,_,_ in vecs)
    G=np.abs(np.array([v for v,_,_ in vecs]).conj()@np.array([v for v,_,_ in vecs]).T)
    assert np.all(G[~np.eye(60,dtype=bool)]<1-1e-9)        # pairwise non-proportional
    return vecs

def occs(t): return [c for c in itertools.product(range(t+1),repeat=4) if sum(c)==t]
def mult(c): return factorial(sum(c))//prod(factorial(x) for x in c)
def gpow(z,e):
    r=(1,0)
    for _ in range(e): r=(r[0]*z[0]-r[1]*z[1], r[0]*z[1]+r[1]*z[0])
    return r

def check(fn, vecs, neg=None):
    J=json.load(open(fn)); T,k=int(J['T']),int(J['k']); m=T+k; d=int(J['d']); R={}
    SA=[tuple(c) for c in J['seed_basis_occupations']]; SB=[tuple(c) for c in J['output_basis_occupations']]
    d1,d2=len(SA),len(SB); n=d1*d2
    R['bases']=sorted(SA)==sorted(occs(T)) and sorted(SB)==sorted(occs(m)) and len(set(SA))==d1 and len(set(SB))==d2 and n==J['dims']['total']
    lam=Q(Fr(J['lam']['a']),Fr(J['lam']['b']),d)
    if neg=='lam': lam=lam-Q(Fr(1,10**6),0,d)
    # K~ recomputed: K~ = (1/60) sum_S 2^{-k_S t} Re(mu mu^*), t=T+m ; integer accumulation per k
    t=T+m; N=np.zeros((n,n),dtype=object)
    occ=[(a,b) for a in SA for b in SB]
    for _,amp,ks in vecs:
        mu=[]
        for ca,cb in occ:
            z=(1,0)
            for x in range(4): z=( (z[0]*gpow(amp[x],ca[x]+cb[x])[0]-z[1]*gpow(amp[x],ca[x]+cb[x])[1]),
                                    (z[0]*gpow(amp[x],ca[x]+cb[x])[1]+z[1]*gpow(amp[x],ca[x]+cb[x])[0]) )
            mu.append(z)
        re=np.array([z[0] for z in mu],dtype=object); im=np.array([z[1] for z in mu],dtype=object)
        w=2**((2-ks)*t)                                  # common denominator 60*4^t
        N+= w*(np.outer(re,re)+np.outer(im,im))          # Re(mu_p conj mu_q) = re_p re_q + im_p im_q
    den=60*4**t
    Kt=lambda p,q: Fr(int(N[p,q]),den)
    given={(p,q):Fr(v) for p,q,v in J['K_tilde_upper']}
    R['K_recomputed']=all((Kt(p,q)==given.get((p,q),Fr(0))) for p in range(n) for q in range(p,n) if N[p,q]!=0 or (p,q) in given)
    ci=[Fr(1,mult(a)*mult(b)) for a in SA for b in SB]
    R['Cinv2']=ci==[Fr(x) for x in J['Cinv2_diag']]
    W={}
    for p,q,a,b in J['W_tilde_upper']:
        W[(p,q)]=Q(Fr(a),Fr(b),d); W[(q,p)]=Q(Fr(a),Fr(b),d)
    # Gamma(W)[(a,b),(a',b')] = W[(a',b),(a,b')]  ->  W at ((a1,b1),(a2,b2)) feeds GW at ((a2,b1),(a1,b2))
    GW={}
    for (P,Qq),v in W.items():
        a1,b1=divmod(P,d2); a2,b2=divmod(Qq,d2)
        key=(a2*d2+b1, a1*d2+b2)
        if neg=='nogamma': key=(P,Qq)
        GW[key]=v
    Sg={}
    for p,q,a,b in J['S_tilde_upper']: Sg[(p,q)]=Q(Fr(a),Fr(b),d)
    cand=set((p,p) for p in range(n)) | set((p,q) for (p,q) in GW if p<=q) | set(Sg) | set((p,q) for p in range(n) for q in range(p,n) if N[p,q]!=0)
    S={}
    ok=True
    for (p,q) in cand:
        e=Q(0,0,d)
        if p==q: e=e+lam.scale(ci[p])
        e=e-Q(Kt(p,q),0,d)
        if (p,q) in GW: e=e-GW[(p,q)]
        if not e.iszero(): S[(p,q)]=e; S[(q,p)]=e
        g=Sg.get((p,q),Z(d))
        if neg not in ('lam','nogamma') and not (e-g).iszero(): ok=False
    R['slack_identity']=ok if neg not in ('lam','nogamma') else 'recomputed'
    def blocks(key):
        lab={}
        for bi,blk in enumerate(J[key]):
            for i in blk['indices']: lab[i]=bi
        return lab
    wl,sl=blocks('W_blocks'),blocks('S_blocks')
    R['partitions']=sorted(wl)==list(range(n)) and sorted(sl)==list(range(n))
    R['W_blocks_vanish']=all(wl[p]==wl[q] for (p,q) in W)
    R['S_blocks_vanish']=all(sl[p]==sl[q] for (p,q) in S)
    def psd(idx, M):
        A={(i,j):M.get((i,j),Z(d)) for i in idx for j in idx}; rem=list(idx)
        while rem:
            if any(A[(i,i)].sign()<0 for i in rem): return False
            zero=[i for i in rem if A[(i,i)].iszero()]
            for i in zero:
                if any(not A[(i,j)].iszero() for j in rem): return False
            rem=[i for i in rem if i not in zero]
            if not rem: return True
            p0=rem[0]; piv=A[(p0,p0)].inv(); rest=rem[1:]
            for i in rest:
                f=A[(i,p0)]*piv
                if f.iszero(): continue
                for j in rest: A[(i,j)]=A[(i,j)]-f*A[(p0,j)]
            rem=rest
        return True
    R['W_psd']=all(psd(b['indices'],W) for b in J['W_blocks'])
    R['S_psd']=all(psd(b['indices'],S) for b in J['S_blocks'])
    psi={int(p):Q(Fr(a),Fr(b),d) for p,a,b in J['primal_witness_psi_tilde']}
    num=Z(d); dn=Z(d)
    for p,x in psi.items():
        dn=dn+(x*x).scale(ci[p])
        for q,y in psi.items(): num=num+(x*y).scale(Kt(min(p,q),max(p,q)))
    R['primal_witness']=bool(psi) and all(p<d2 for p in psi) and (num-lam*dn).iszero()
    keys=['bases','K_recomputed','Cinv2','slack_identity','partitions','W_blocks_vanish','S_blocks_vanish','W_psd','S_psd','primal_witness']
    R['ALL']=all(R[x] is True for x in keys) if neg is None else (R['W_psd'] and R['S_psd'] and R['S_blocks_vanish'])
    return J['case'], f"{lam.a} + {lam.b}*sqrt({d})", R

if __name__=='__main__':
    base='./'
    vecs=check_states(base+'stab_states_n2.json'); print("states: 60 unit vectors, = Claude's own 60 stabilizer states (up to phase), pairwise distinct", flush=True)
    cases=sys.argv[1:] or ['1to2','1to3','2to3','1to4','1to5','2to4','3to4']
    for c in cases:
        if c.startswith('neg:'):
            _,how,cc=c.split(':'); case,lam,R=check(base+f'cert_n2_{cc}.json',vecs,neg=how)
            print(f"NEGATIVE CONTROL {how} on {cc}: certificate accepted? {R['ALL']}  (must be False)", flush=True); continue
        case,lam,R=check(base+f'cert_n2_{c}.json',vecs)
        print(f"{case}: lambda = {lam}  " + ", ".join(f"{a}={'ok' if b is True else b}" for a,b in R.items()), flush=True)
