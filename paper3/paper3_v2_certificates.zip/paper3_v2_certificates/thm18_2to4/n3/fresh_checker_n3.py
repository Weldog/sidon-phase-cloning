"""Fresh exact checker for the n = 3 certificates, written from README_certificates_n3.md alone (own code, so NOT independent).
Exact only: fractions.Fraction for every field computation; numpy is used ONLY for exact int64 integer arithmetic when recomputing
the integer numerators of K~ (bound checked: |entries| <= 1080 * 8^s < 2^62).  No imports from src/.
Usage: python fresh_checker_n3.py [--neg=lam|nogamma|psi|K] files..."""
import json, sys, itertools
import numpy as np
from fractions import Fraction as Fr
from math import factorial, comb

NQ, DD, NS = 3, 8, 1080
def R(s): return Fr(s)

class Fd:
    def __init__(self, d): self.d = d
    def sign(self, x):
        a, b = x
        if b == 0: return (a > 0) - (a < 0)
        if a == 0: return (b > 0) - (b < 0)
        if a > 0 and b > 0: return 1
        if a < 0 and b < 0: return -1
        if a > 0: return 1 if a*a > b*b*self.d else -1
        return 1 if b*b*self.d > a*a else -1
    def mul(self, x, y): return (x[0]*y[0] + self.d*x[1]*y[1], x[0]*y[1] + x[1]*y[0])
    def inv(self, x):
        nn = x[0]*x[0] - self.d*x[1]*x[1]; return (x[0]/nn, -x[1]/nn)

Z = (Fr(0), Fr(0))
def psd(F, M):
    """diagonal-pivot LDL^T with zero handling on a dict-of-dicts symmetric matrix"""
    M = {i: dict(r) for i, r in M.items()}; alive = set(M)
    while alive:
        pos = None
        for i in sorted(alive):
            s = F.sign(M[i].get(i, Z))
            if s < 0: return False
            if s == 0:
                if any(M[i].get(j, Z) != Z for j in alive): return False
            elif pos is None: pos = i
        alive = {i for i in alive if F.sign(M[i].get(i, Z)) != 0}
        if pos is None: return True
        alive.discard(pos); ip = F.inv(M[pos][pos])
        col = {i: M[i].get(pos, Z) for i in alive}
        for i in alive:
            if col[i] == Z: continue
            f = F.mul(col[i], ip)
            for j in alive:
                v = M[pos].get(j, Z)
                if v != Z:
                    t = F.mul(f, v); o = M[i].get(j, Z); M[i][j] = (o[0] - t[0], o[1] - t[1])
    return True

def gmul(x, y): return (x[0]*y[0] - x[1]*y[1], x[0]*y[1] + x[1]*y[0])
def gconj(x): return (x[0], -x[1])
P1 = {'I': [[(1, 0), (0, 0)], [(0, 0), (1, 0)]], 'X': [[(0, 0), (1, 0)], [(1, 0), (0, 0)]],
      'Y': [[(0, 0), (0, -1)], [(0, 1), (0, 0)]], 'Z': [[(1, 0), (0, 0)], [(0, 0), (-1, 0)]]}
def bits(x): return [(x >> (NQ - 1 - j)) & 1 for j in range(NQ)]          # x = 4 x1 + 2 x2 + x3

def check_states(path):
    S = json.load(open(path))['states']; assert len(S) == NS
    paulis = []
    for word in itertools.product('IXYZ', repeat=NQ):          # dense 8x8 Gaussian-integer matrices
        Mx = [[(1, 0)]*DD for _ in range(DD)]
        for x in range(DD):
            for y in range(DD):
                e = (1, 0)
                for j in range(NQ): e = gmul(e, P1[word[j]][bits(x)[j]][bits(y)[j]])
                Mx[x][y] = e
        paulis.append(Mx)
    vecs = []
    for s in S:
        amp = [tuple(a) for a in s['amplitudes_gaussian_int']]; k = s['k']
        assert len(amp) == DD and all(a in [(0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)] for a in amp)
        assert sum(a[0]**2 + a[1]**2 for a in amp) == 2**k
        cnt = 0
        for Mx in paulis:
            ov = (0, 0)
            for x in range(DD):
                if amp[x] == (0, 0): continue
                acc = (0, 0)
                for y in range(DD):
                    if amp[y] != (0, 0) and Mx[x][y] != (0, 0):
                        t = gmul(Mx[x][y], amp[y]); acc = (acc[0] + t[0], acc[1] + t[1])
                t = gmul(gconj(amp[x]), acc); ov = (ov[0] + t[0], ov[1] + t[1])
            if ov[0]**2 + ov[1]**2 == 4**k: cnt += 1
        assert cnt == 2**NQ, cnt
        vecs.append((amp, k))
    keys = set()
    for amp, k in vecs:                                   # non-proportional: normalise first nonzero amplitude to (1,0)
        x0 = next(x for x in range(DD) if amp[x] != (0, 0)); u = gconj(amp[x0])
        keys.add(tuple(gmul(a, u) for a in amp))
    assert len(keys) == NS, 'proportional states'
    return vecs

def mult(c):
    r = factorial(sum(c))
    for v in c: r //= factorial(v)
    return r

def K_numerators(vecs, s):
    """G[c, c'] = sum_S 2^{(3 - k) s} mu_c(S) conj mu_c'(S) over size-s multisets c (occupation vectors), exact int64.
    Returns the real part; asserts that the imaginary part vanishes identically."""
    L = [tuple(sum(1 for t in M if t == x) for x in range(DD)) for M in itertools.combinations_with_replacement(range(DD), s)]
    Li = {c: i for i, c in enumerate(L)}; nL = len(L)
    G = np.zeros((nL, nL), dtype=np.int64); H = np.zeros((nL, nL), dtype=np.int64)
    assert NS*8**s < 2**62
    for amp, k in vecs:
        re = np.zeros(nL, dtype=np.int64); im = np.zeros(nL, dtype=np.int64)
        for i, c in enumerate(L):
            v = (1, 0)
            for x in range(DD):
                for _ in range(c[x]): v = gmul(v, amp[x])
            re[i], im[i] = v
        nz = np.nonzero((re != 0) | (im != 0))[0]; w = 2**((NQ - k)*s); r_, i_ = re[nz], im[nz]
        G[np.ix_(nz, nz)] += w*(np.outer(r_, r_) + np.outer(i_, i_))          # Re(mu_c conj mu_c')
        H[np.ix_(nz, nz)] += w*(np.outer(i_, r_) - np.outer(r_, i_))          # Im(mu_c conj mu_c')
    assert (H == 0).all(), 'K~ has an imaginary part'
    return G, Li

_GC = {}
def check(path, vecs, neg=None):
    J = json.load(open(path)); d = J['d']; F = Fd(d); T, m = J['T'], J['m']; s = T + m
    assert J['n_qubits'] == NQ and J['D'] == DD
    lam = (R(J['lam']['a']), R(J['lam']['b'])); assert J['lam']['d'] == d
    if d: assert all(d % (p*p) for p in range(2, int(d**0.5) + 1))
    A = [tuple(c) for c in J['seed_basis_occupations']]; B = [tuple(c) for c in J['output_basis_occupations']]
    # 1. shapes
    assert len(set(A)) == len(A) and all(len(c) == DD and sum(c) == T and min(c) >= 0 for c in A)
    assert len(set(B)) == len(B) and all(len(c) == DD and sum(c) == m and min(c) >= 0 for c in B)
    assert len(A) == comb(T + DD - 1, DD - 1) and len(B) == comb(m + DD - 1, DD - 1)
    d1, d2 = len(A), len(B); n = d1*d2; assert J['dims'] == dict(seed_factor_SymT=d1, output_factor_Symm=d2, total=n)
    for key in ('S_blocks', 'W_blocks'):
        allidx = sorted(i for b in J[key] for i in b['indices']); assert allidx == list(range(n))
    occ = lambda p: (A[p // d2], B[p % d2])
    # 2. K~ recomputed (all n^2 entries: via union multisets u(p) = c_a + c_b)
    if s not in _GC: _GC[s] = K_numerators(vecs, s)
    G, Li = _GC[s]; den = NS*8**s
    u = np.array([Li[tuple(x + y for x, y in zip(*occ(p)))] for p in range(n)])
    Kf = {(p, q): R(x) for p, q, x in J['K_tilde_upper']}
    if neg == 'K':
        key0 = next(iter(Kf)); Kf[key0] += Fr(1, 10**9)
    assert all(p <= q for p, q in Kf)
    for (p, q), v in Kf.items():
        assert v == Fr(int(G[u[p], u[q]]), den), 'K_tilde mismatch (listed entry)'
    nnz = 0                                              # count the nonzero recomputed upper entries: must equal the listed ones
    for p in range(n):
        row = G[u[p], u[p:]]; nzq = np.nonzero(row)[0]; nnz += len(nzq)
    assert nnz == len(Kf), ('K_tilde mismatch (absent nonzero entries)', nnz, len(Kf))
    Kc = {key: v for key, v in Kf.items()}
    Ksym = lambda p, q: Fr(int(G[u[p], u[q]]), den)
    # 3. C^{-2}
    ci = [R(x) for x in J['Cinv2_diag']]
    assert ci == [Fr(1, mult(occ(p)[0])*mult(occ(p)[1])) for p in range(n)]
    if neg == 'lam': lam = (lam[0] - Fr(1, 10**6), lam[1])
    # 4. slack identity
    W = {}
    for p, q, a, b in J['W_tilde_upper']:
        W[(p, q)] = (R(a), R(b)); W[(q, p)] = (R(a), R(b))
    Gm = lambda p, q: ((q // d2)*d2 + p % d2, (p // d2)*d2 + q % d2)       # (X^Gamma)[p,q] = X[Gm(p,q)]
    Sc = {}
    for p in range(n): Sc[(p, p)] = (lam[0]*ci[p], lam[1]*ci[p])
    for (p, q), v in Kc.items():
        for key in {(p, q), (q, p)}:
            o = Sc.get(key, Z); Sc[key] = (o[0] - v, o[1])
    for (P, Q), v in W.items():
        key = Gm(P, Q) if neg != 'nogamma' else (P, Q)
        o = Sc.get(key, Z); Sc[key] = (o[0] - v[0], o[1] - v[1])
    Sc = {key: v for key, v in Sc.items() if v != Z}
    res = {}
    Sf = {}
    for p, q, a, b in J['S_tilde_upper']:
        Sf[(p, q)] = (R(a), R(b)); Sf[(q, p)] = (R(a), R(b))
    res['S_identity'] = (Sf == Sc)
    assert all(Sc.get((q, p)) == v for (p, q), v in Sc.items())
    # 5. block vanishing
    for key, M in (('W_blocks', W), ('S_blocks', Sc)):
        lab = {}
        for bi, b in enumerate(J[key]):
            for i in b['indices']: lab[i] = bi
        res[key + '_vanish'] = all(lab[p] == lab[q] for (p, q) in M)
    # 6, 7. PSD per block
    for key, M, nm in (('W_blocks', W, 'W_psd'), ('S_blocks', Sc, 'S_psd')):
        rows = {}
        for (p, q), v in M.items(): rows.setdefault(p, {})[q] = v
        ok = True
        for b in J[key]:
            I = b['indices']; Iset = set(I)
            sub = {i: {j: v for j, v in rows.get(i, {}).items() if j in Iset} for i in I}
            ok &= psd(F, sub)
        res[nm] = ok
    # 8. primal witness
    psi = {p: (R(a), R(b)) for p, a, b in J['primal_witness_psi_tilde']}
    if neg == 'psi':
        p1 = next(p for p in range(d2) if p not in psi); psi[p1] = (Fr(1), Fr(0))
    assert psi and all(p < d2 for p in psi)
    num = Z; dn = Z
    for p, x in psi.items():
        t = F.mul(x, x); dn = (dn[0] + t[0]*ci[p], dn[1] + t[1]*ci[p])
        for q, y in psi.items():
            t = F.mul(x, y); kk = Ksym(p, q); num = (num[0] + t[0]*kk, num[1] + t[1]*kk)
    res['primal_ok'] = (num == F.mul(lam, dn))
    cs = True                                            # optional: complementary slackness
    for Mx in (W, Sc):
        acc = {}
        for (p, q), v in Mx.items():
            if q in psi:
                t = F.mul(v, psi[q]); o = acc.get(p, Z); acc[p] = (o[0] + t[0], o[1] + t[1])
        cs &= all(v == Z for v in acc.values())
    res['compl_slack'] = cs
    res['PASS'] = all(res[x] for x in ('S_identity', 'W_blocks_vanish', 'S_blocks_vanish', 'W_psd', 'S_psd', 'primal_ok'))
    return dict(case=J['case'], n=n, d=d, **res)

if __name__ == '__main__':
    args = sys.argv[1:]; neg = None
    if args and args[0].startswith('--neg='): neg = args[0][6:]; args = args[1:]
    vecs = check_states('certificates/stab_states_n3.json'); print(json.dumps(dict(states='1080 stabilizer states OK')), flush=True)
    for f in args:
        try: r = check(f, vecs, neg)
        except AssertionError as e: r = dict(file=f, PASS=False, assertion=str(e))
        r['neg'] = neg; print(json.dumps(r), flush=True)
