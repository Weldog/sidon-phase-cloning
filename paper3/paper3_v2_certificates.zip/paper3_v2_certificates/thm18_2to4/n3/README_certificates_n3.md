# n = 3 certificates (R13d Gate B): exact PPT dual certificates for the PGM-seed optimum at three qubits. README for independent checking

Private; nothing published or sent. Grok Bot, 23 Oct 2026 (PT). Every file here was produced by my own code (`src/n3_cert.py`, `src/export_n3.py`). **Not independently verified.** A checker can be written from this README and the JSON files alone; no code of mine is needed. The format is the n = 2 format (r31/step2/certificates/README_certificates_n2.md); only n, D, the state set and the block labels change.

## 1. What each certificate proves, and what it relies on

Fix n = 3 qubits (D = 8) and a case (T, k) from the table, with m = T + k. Once checked, each certificate proves (CA, own code, until someone else checks it):

  P_PPT := max { tr(Kρ) : ρ ⪰ 0 on Sym^T(C^8) ⊗ Sym^m(C^8), tr ρ = 1, ρ^Γ ⪰ 0 } = λ,

where λ is the stated number and equals λmax(B_{T,k}) (Gate A, exact).

Product states φ⊗χ are PPT. So the product-state optimum Λ := max_{φ,χ} ⟨φ⊗χ|K|φ⊗χ⟩ satisfies λmax(B) ≤ Λ ≤ P_PPT = λ = λmax(B). Hence **Λ = λmax(B)**: the PGM seed φ = |000⟩^{⊗T} is optimal among all seeds, and even among PPT seed/output states.

**Relies on (not certified here):**
- The operational reading EB* = D_T·Λ (Lemma R, ledger F6), with D_T = dim Sym^T(C^8) = C(T+7, 7) (8 for T = 1, 36 for T = 2).
- Achievability is the PGM followed by preparing U^{⊗m}χ*.

**Restricting to Sym^T ⊗ Sym^m loses nothing.** Π = P_sym^T ⊗ P_sym^m is a real projector, (ΠρΠ)^Γ = Πρ^ΓΠ ⪰ 0, tr(KΠρΠ) = tr(Kρ), tr(ΠρΠ) ≤ 1. (DERIVED, one line, as at n = 2.)

**Which factor Γ transposes does not matter.** For a real symmetric W̃, transposing the output factor gives the same matrix entrywise. (DERIVED, one line, as at n = 2.)

| case | T | k | m | dim Sym^T × dim Sym^m = n | λ (exact) | d | rank W̃ | rank S̃ |
|---|---|---|---|---|---|---|---|---|
| 1to4 | 1 | 3 | 4 | 8 × 330 = 2640 | 7/5760 + √29/5760 | 29 | 1848 | 1848 |
| 1to5 | 1 | 4 | 5 | 8 × 792 = 6336 | 5/3072 | 0 | 5355 | 5292 |
| 2to4 | 2 | 2 | 4 | 36 × 330 = 11880 | 7/9216 + √37/9216 | 37 | 10836 | 10836 |

λ is a root of the minimal polynomials 1658880x² − 4032x + 1; 3072x − 5; 7077888x² − 10752x + 1. The cloning values are D_T·λ: (7+√29)/720, 5/384, (7+√37)/256.

## 2. States, bases, operator

**States** (file `stab_states_n3.json`). There are 1080 entries. Each has amplitudes amp_x for x = 0..7, each a Gaussian integer [re, im] ∈ {0, ±1, ±i}, and an integer k with 2^k = support size. The state is |S⟩ = 2^{−k/2} Σ_x amp_x |x⟩. Labelling: x = 4·x1 + 2·x2 + x3, where x1 is the first qubit.

**Bases.**
- Sym^t(C^8) has the orthonormal basis |c⟩ indexed by occupation vectors c = (c_0, …, c_7) with Σ c_x = t.
- The order is given explicitly in the JSON: `seed_basis_occupations` (t = T, index a) and `output_basis_occupations` (t = m, index b).
- ⟨c|S^{⊗t}⟩ = √mult(c) · 2^{−kt/2} · Π_x amp_x^{c_x}, mult(c) = t!/Π_x c_x!.
- Product index: p = a·d2 + b, d2 = dim Sym^m. **The seed factor Sym^T is the FIRST tensor factor, the output factor Sym^m the SECOND** (R1-01). All matrices are n×n in this order.

**Operator.** K := (1/1080) Σ_S |S^{⊗T}⟩⟨S^{⊗T}| ⊗ |S^{⊗m}⟩⟨S^{⊗m}| on Sym^T ⊗ Sym^m. No complex conjugation is applied to either factor in K.

**Scaling.** C = diag(c_p), c_p² = mult(c_a)·mult(c_b); K = C K̃ C with

  K̃[p, p′] = (1/1080) Σ_S 2^{−k_S(T+m)} · Re( μ_p(S) · conj(μ_{p′}(S)) ),  μ_{(a,b)}(S) = Π_x amp_x^{(c_a)_x + (c_b)_x}  (0^0 = 1).

The imaginary parts cancel exactly (the state set is closed under complex conjugation); K̃ is real rational. Note μ_{(a,b)} depends only on the union occupation c_a + c_b (size s = T + m), which a checker may use to compute K̃ quickly.

Every matrix in the JSON is in the scaled form X̃ = C^{−1} X C^{−1}. `Cinv2_diag[p]` = 1/(mult(c_a)·mult(c_b)).

**Seed operator.** B_{T,k} := ⟨0^T|K|0^T⟩, a = 0 is the occupation (T,0,…,0), i.e. |000⟩^{⊗T}.

## 3. Primal, PPT relaxation, dual

**Partial transpose.** Γ transposes the **Sym^T (seed, first, outer index a) factor** in this real basis:

  (X^Γ)[(a,b),(a′,b′)] := X[(a′,b),(a,b′)].

**Primal.** max tr(Kρ) s.t. ρ ⪰ 0, tr ρ = 1, ρ^Γ ⪰ 0.

**Dual (weak duality).** y real, W real symmetric, (D1) W ⪰ 0, (D2) S := y·I − K − W^Γ ⪰ 0 ⇒ y − tr(Kρ) = tr(Sρ) + tr(Wρ^Γ) ≥ 0, so P_PPT ≤ y. Scaled: W̃ ⪰ 0, S̃ := y·C^{−2} − K̃ − Γ(W̃) ⪰ 0. The certificates take y = λ.

**Primal witness.** ψ̃ is supported on the a = 0 block (seed |000⟩^{⊗T}); ψ = C^{−1}ψ̃/‖·‖ = |000⟩^{⊗T} ⊗ χ*, value (ψ̃ᵀK̃ψ̃)/(ψ̃ᵀC^{−2}ψ̃). A product state, hence PPT.

**Block reduction.** `S_blocks` and `W_blocks` are partitions of {0..n−1}; S̃ (resp. W̃) must vanish between different parts; then PSD ⇔ each principal block PSD.

**Where the blocks come from** (for the reader; the check does not depend on it):
- Label of index p = (a, b): a character of the diagonal Clifford group D_3 = ⟨S_1, S_2, S_3, CZ_12, CZ_13, CZ_23⟩, of order 2^9 = 512 mod phases.
- For an occupation c: χ(c) = (w_1, w_2, w_3 mod 4; n_12, n_13, n_23 mod 2), with w_j = Σ_{x: x_j = 1} c_x and n_ij = Σ_{x: x_i = x_j = 1} c_x.
- S-block label: χ(c_a) + χ(c_b). W-block label: χ(c_b) − χ(c_a), componentwise mod (4,4,4,2,2,2). All 512 labels occur in every case.
- Validity (same proof as n = 2): for a Clifford U, V = U^{⊗T} ⊗ U^{⊗m}, Ṽ = Ū^{⊗T} ⊗ U^{⊗m}: VKV† = K and (ṼXṼ†)^Γ = V X^Γ V†; so averaging a feasible (y, W) over a finite group under the twisted action keeps it feasible with the same y. D_3 acts on |c⟩ by the character above; the seed character is conjugated under Ū, giving the minus sign for W.
- The search also imposed AGL(3,2) invariance (x ↦ Ax ⊕ b, 1344 real permutation matrices, Ū = U). Group used: G_1 = D_3 ⋊ AGL(3,2), the monomial Clifford group, order 512·1344 = 688128 mod phases. It contains G_0 = Stab_Cl(|000⟩) = D_3 ⋊ GL(3,2), order 86016 = 92897280/1080.
- The checker needs none of this.

## 4. JSON fields (`cert_n3_<case>.json`)

Encoding as at n = 2: a rational is "p/q" or "p"; a Q(√d) element is {"a","b","d"} (a + b√d) or, in the sparse lists, the pair of strings a, b; d = 0 means rational. d squarefree: 29, 37 (primes).

| field | content |
|---|---|
| case, T, k, m, n_qubits (= 3), D (= 8), d | scalars |
| lam | λ as {"a", "b", "d"} |
| dims | seed_factor_SymT = d1, output_factor_Symm = d2, total = n = d1·d2 |
| seed_basis_occupations, output_basis_occupations | lists of occupation vectors (length 8) in index order |
| index_rule | p = a·d2 + b |
| Cinv2_diag | n rationals |
| K_tilde_upper | [p, q, rational], p ≤ q, nonzero only. Convenience copy: **recompute** and compare (absent = 0) |
| W_tilde_upper | [p, q, a, b], p ≤ q, nonzero only; W̃ symmetric |
| S_tilde_upper | [p, q, a, b]: convenience copy of S̃ = λC^{−2} − K̃ − Γ(W̃); verify |
| primal_witness_psi_tilde | [p, a, b], nonzero entries of ψ̃ (all p < d2) |
| S_blocks, W_blocks | lists of {character, indices} |
| source | provenance |

## 5. Checklist (all exact; no floating point)

0. **States.** 1080 entries, Σ|amp_x|² = 2^k, pairwise non-proportional; each has exactly 8 Pauli operators P (mod phase) with |⟨S|P|S⟩| = 1, so it is a stabilizer state. |Stab(3)| = 1080, so this is the whole set.
1. **Shapes.** Basis lists are all occupation vectors of the right t, no repetition; d1 = C(T+7,7), d2 = C(m+7,7); block lists are partitions.
2. **K̃.** Recompute from §2 and compare entrywise with K_tilde_upper (absent = 0); imaginary parts vanish.
3. **C^{−2}.** Check Cinv2_diag.
4. **Slack identity.** S̃ = λ·diag(Cinv2_diag) − K̃ − Γ(W̃) entrywise; equals S_tilde_upper.
5. **Block vanishing** for W̃ (W_blocks) and S̃ (S_blocks).
6. **W̃ ⪰ 0** per block, exactly over Q(√d).
7. **S̃ ⪰ 0** per block, exactly.
8. **Primal witness.** ψ̃ ≠ 0, supported on p < d2; ψ̃ᵀK̃ψ̃ = λ·ψ̃ᵀ diag(Cinv2_diag) ψ̃ exactly.
9. **Conclusion.** If 0–8 pass: P_PPT = Λ = λmax(B_{T,k}) = λ. Optional: minimal polynomial; S̃ψ̃ = 0 and W̃ψ̃ = 0.

**Arithmetic in Q(√d).** Sign of a + b√d: a, b ≥ 0 (not both 0) positive; a, b ≤ 0 negative; a > 0 > b: sign(a² − b²d); a < 0 < b: sign(b²d − a²). Inverse (a − b√d)/(a² − b²d).

**PSD test.** Diagonal-pivot LDLᵀ with zero handling (negative diagonal ⇒ not PSD; zero diagonal needs a zero row, dropped; else pivot on a positive diagonal, Schur complement).

**Negative controls a checker should reject:** λ → λ − 10^{−6} (step 4/7 fail); Γ omitted (step 4 or 7 fail); one ψ̃ entry added (step 8 fails); one K_tilde_upper entry changed (step 2 fails).
