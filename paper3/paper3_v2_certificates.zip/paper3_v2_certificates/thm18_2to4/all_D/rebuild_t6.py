# Claude: independent rebuild of the t = 6 (2->4) relation algebras A and B and their structure constants,
# to compare with Grok Bot's exported table (closing GPT's R13f qualification). Uses only Grok Bot's orbit
# member lists as INPUT DATA (the relations), re-validated here; every algebraic quantity is recomputed.
import json, itertools, math
from collections import defaultdict
J=json.load(open('gateE1_data.json'))
t=6; M=(1<<t)-1
def unpack(v): return v>>t, v&M
def wt(x): return bin(x).count('1')
def checkrel(U):
    U=frozenset(U)
    if len(U)!=64: return False
    if not all((a^b) in U for a in U for b in list(U)[:7]): pass
    # closure under XOR (check against a basis-free full test on a sample is not enough: do full closure)
    if any((a^b) not in U for a in U for b in U): return False
    if (M<<t|M) not in U: return False
    return all((wt(x)-wt(y))%4==0 for x,y in map(unpack,U))
res={}
for name in ('A','B'):
    orbs=[[frozenset(r) for r in O] for O in J[name]['orbits']]
    rels=[r for O in orbs for r in O]
    res[name]=orbs
    ok_rel=all(checkrel(r) for r in rels) if name=='A' else None
    print(name,": orbits",len(orbs),"| relations",len(rels),"| distinct",len(set(rels)), "| all valid Lagrangian relations:",ok_rel)
print("GNW count prod_{i=0}^{4}(2^i+1) =", math.prod(2**i+1 for i in range(5)))
# Gamma: transpose of the seed factor = swap seed coordinates (0,1 -> bits 5,4) between x and y
SEED=(1<<5)|(1<<4)
def gamma(U): return frozenset((( (x&~SEED)|(y&SEED) )<<t)|((y&~SEED)|(x&SEED)) for x,y in map(unpack,U))
A,B=res['A'],res['B']
gB={gamma(r) for O in A for r in O}; print("Gamma(A relations) == B relations:", gB=={r for O in B for r in O})
# orbit recomputation under (S2 x S4) x (S2 x S4): coord i <-> bit (5-i); seed coords {0,1}, outputs {2..5}
def perm_vec(x,p):   # p maps coord i -> p[i]
    out=0
    for i in range(6):
        if (x>>(5-i))&1: out|=1<<(5-p[i])
    return out
G1=[tuple(list(s)+[2+o for o in q]) for s in itertools.permutations((0,1)) for q in itertools.permutations(range(4))]
def act(U,p,r): return frozenset((perm_vec(x,p)<<t)|perm_vec(y,r) for x,y in map(unpack,U))
for name,orbs in (('A',A),('B',B)):
    good=all({act(O[0],p,r) for p in G1 for r in G1}==set(O) for O in orbs)
    print(name,": every exported orbit is exactly one group orbit:",good)
# structure constants: coeff of b_k in b_i b_j = |O_i|/|O_k| * sum_{U2 in O_j} [U1∘U2 in O_k] D^{dim(N_R(U1)∩N_L(U2))}, U1 = any fixed element of O_i
def NL(U): return frozenset(x for x,y in map(unpack,U) if y==0)
def NR(U): return frozenset(y for x,y in map(unpack,U) if x==0)
def dim(S): return len(S).bit_length()-1
def compose(U1,U2):
    by=defaultdict(list)
    for x,y in map(unpack,U2): by[x].append(y)
    return frozenset((x<<t)|z for x,y in map(unpack,U1) for z in by.get(y,()))
def table(orbs):
    where={r:k for k,O in enumerate(orbs) for r in O}
    F=[[defaultdict(lambda: defaultdict(int)) for _ in orbs] for _ in orbs]
    for i,Oi in enumerate(orbs):
        U1=Oi[0]; nr=NR(U1)
        for j,Oj in enumerate(orbs):
            acc=defaultdict(lambda: defaultdict(int))
            for U2 in Oj:
                W=compose(U1,U2); k=where[W]; acc[k][dim(nr & NL(U2))]+=1
            for k,poly in acc.items():
                for p,c in poly.items():
                    val=c*len(Oi)
                    assert val % len(orbs[k])==0
                    F[i][j][k][p]+=val//len(orbs[k])
    return F
def theirs(name):
    f=J[name]['f']; return [[{int(k):{int(p):c for p,c in poly.items()} for k,poly in f[i][j].items()} for j in range(21)] for i in range(21)]
for name,orbs in (('A',A),('B',B)):
    mine=table(orbs); th=theirs(name)
    mism=0
    for i in range(21):
        for j in range(21):
            a={k:{p:c for p,c in v.items() if c} for k,v in mine[i][j].items()}
            a={k:v for k,v in a.items() if v}
            if a!=th[i][j]: mism+=1
    print(name,": structure constants (21x21, polynomials in D) — mismatches vs exported table:",mism)
    # traces: tr R(U) = D^{dim{x:(x,x) in U}}
    trm=[defaultdict(int) for _ in orbs]
    for k,O in enumerate(orbs):
        for U in O: trm[k][dim(frozenset(x for x,y in map(unpack,U) if x==y))]+=1
    print(name,": traces match:", all({p:c for p,c in trm[k].items()}=={int(p):c for p,c in J[name]['tr'][k].items()} for k in range(21)))
