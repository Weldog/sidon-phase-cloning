"""R13f Gate F3 standalone exact checker (Grok Bot, own code). Run: python3 check_gateF3.py (needs sympy). Data files in this directory.
All checks are exact (rational arithmetic / exact polynomial identities / Sturm or shifted-coefficient positivity)."""

import json, random, sys
from fractions import Fraction as Fr
import sympy as sp
from sympy.polys.matrices import DomainMatrix
from sympy import QQ
def pev(p, D): return sum(int(c)*D**int(e) for e, c in p.items())
class FA:
    def __init__(s, alg, D, unit_idx, unit_size):
        s.D = D; s.r = r = len(alg['star']); s.star = alg['star']
        s.nz = [[[] for _ in range(r)] for _ in range(r)]
        for i in range(r):
            for k in range(r):
                for l, p in alg['f'][i][k].items():
                    v = pev(p, D)
                    if v: s.nz[i][k].append((int(l), Fr(v)))
        s.tr = [Fr(pev(p, D)) for p in alg['tr']]
        s.unit = [Fr(0)]*r; s.unit[unit_idx] = Fr(1, unit_size)
    def basis(s, k): v = [Fr(0)]*s.r; v[k] = Fr(1); return v
    def mul(s, a, b):
        out = [Fr(0)]*s.r
        ia = [i for i in range(s.r) if a[i]]; kb = [k for k in range(s.r) if b[k]]
        for i in ia:
            for k in kb:
                c = a[i]*b[k]
                for l, v in s.nz[i][k]: out[l] += c*v
        return out
    def adj(s, a):
        out = [Fr(0)]*s.r
        for k in range(s.r): out[s.star[k]] += a[k]
        return out
    def tau(s, a): return sum(a[i]*s.tr[i] for i in range(s.r) if a[i])
def nullspace(rows, n):
    M = DomainMatrix([[QQ(x.numerator, x.denominator) for x in row] for row in rows], (len(rows), n), QQ)
    N = M.nullspace()
    return [[Fr(int(x.numerator), int(x.denominator)) for x in row] for row in N.to_Matrix().tolist()]
def rank(vecs, n):
    if not vecs: return 0
    return DomainMatrix([[QQ(x.numerator, x.denominator) for x in v] for v in vecs], (len(vecs), n), QQ).rank()
def blocks(s, seed=5, log=print):
    r = s.r
    rows = []
    for k in range(r):
        L = [s.mul(s.basis(i), s.basis(k)) for i in range(r)]; R = [s.mul(s.basis(k), s.basis(i)) for i in range(r)]
        for l in range(r):
            row = [L[i][l] - R[i][l] for i in range(r)]
            if any(row): rows.append(row)
    Z = nullspace(rows, r); m = len(Z); log(f'centre dim {m}')
    rng = random.Random(seed); t = sp.symbols('t')
    for attempt in range(200):
        coef = [rng.randint(-3, 3) for _ in range(m)]
        z = [sum(coef[a]*Z[a][i] for a in range(m)) for i in range(r)]
        # matrix of multiplication by z on the centre (coordinates via least squares on pivot rows)
        prods = [s.mul(z, Z[a]) for a in range(m)]
        ZT = sp.Matrix([[sp.Rational(Z[a][i].numerator, Z[a][i].denominator) for a in range(m)] for i in range(r)])
        P = sp.Matrix([[sp.Rational(prods[a][i].numerator, prods[a][i].denominator) for a in range(m)] for i in range(r)])
        piv = ZT.T.rref()[1]; Zs = ZT.extract(list(piv), list(range(m))); Mz = Zs.inv()*P.extract(list(piv), list(range(m)))
        cp_ = Mz.charpoly(t); rts = sp.roots(cp_.as_expr(), t)
        if len(rts) == m and all(x.is_Rational for x in rts): break
    else: raise RuntimeError('no rational separating central element')
    one = Zs.inv()*sp.Matrix([sp.Rational(s.unit[i].numerator, s.unit[i].denominator) for i in piv])
    es = []
    for mu in rts:
        v = one
        for nu in rts:
            if nu != mu: v = (Mz - nu*sp.eye(m))*v/(mu - nu)
        e = [Fr(0)]*r
        for a in range(m):
            c = Fr(int(sp.Rational(v[a]).p), int(sp.Rational(v[a]).q))
            if c: e = [x + c*y for x, y in zip(e, Z[a])]
        es.append(e)
    out = []; tot = [Fr(0)]*r
    for e in es:
        assert s.mul(e, e) == e and s.adj(e) == e
        tot = [a + b for a, b in zip(tot, e)]
        dim = rank([s.mul(e, s.basis(k)) for k in range(r)], r); d = int(round(dim**0.5)); assert d*d == dim
        out.append(dict(e=e, d=d))
    assert tot == s.unit; assert sum(b['d']**2 for b in out) == r
    for b in out: setup(s, b)
    log('blocks d = ' + str(sorted(b['d'] for b in out)))
    return out
def setup(s, b):
    e, d, r = b['e'], b['d'], s.r; t = sp.symbols('t')
    if d == 1: p = e
    else:
        p = None
        cands = [None] + list(range(r))
        for k in cands:
            if k is None: h = [Fr(1)]*r
            else: bk = s.basis(k); h = [x + y for x, y in zip(bk, s.adj(bk))]
            y = s.mul(s.mul(e, h), e)
            pw = [e, y]
            for _ in range(d - 1): pw.append(s.mul(pw[-1], y))
            ns = nullspace([[pw[i][c] for i in range(len(pw))] for c in range(r)], len(pw))
            if len(ns) != 1: continue
            c = ns[0]; mp = sp.Poly(sum(sp.Rational(c[i].numerator, c[i].denominator)*t**i for i in range(len(c))), t)
            if mp.degree() != d: continue
            rts = sp.roots(mp); simple = [x for x, mlt in rts.items() if mlt == 1 and x.is_Rational]
            if not simple: continue
            mu = simple[0]; q = sp.quo(mp, sp.Poly(t - mu, t)); qc = q.all_coeffs()[::-1]; qmu = q.eval(mu)
            pj = [Fr(0)]*r
            for i_, c_ in enumerate(qc):
                cf = sp.Rational(c_/qmu); cf = Fr(int(cf.p), int(cf.q))
                pj = [a + cf*bq for a, bq in zip(pj, pw[i_])]
            # minimal (rank one in block) iff p b_k p in Q p for all k
            ok = s.mul(pj, pj) == pj
            if ok:
                i0 = next(i for i in range(r) if pj[i])
                for kk in range(r):
                    qq = s.mul(pj, s.mul(s.basis(kk), pj)); mu2 = qq[i0]/pj[i0]
                    if any(qq[i] != mu2*pj[i] for i in range(r)): ok = False; break
            if ok: p = pj; break
        assert p is not None
    tp = s.tau(p); xs, vecs = [], []
    for k in range(r):
        v = s.mul(s.basis(k), p)
        if rank(vecs + [v], r) > len(vecs): xs.append(k); vecs.append(v)
        if len(xs) == d: break
    q = [[None]*d for _ in range(d)]
    for i in range(d):
        xi = s.adj(vecs[i])
        for l in range(d):
            Q = s.mul(vecs[l], xi)    # x_l p x_i^*
            # tau(Q b_k) for all k
            q[i][l] = [sum(Q[a]*v*s.tr[c] for a in range(r) if Q[a] for c, v in s.nz[a][k])/tp for k in range(r)]
    b.update(p=p, taup=tp, xs=xs, q=q)
def H(b, X):
    d = b['d']; return [[sum(b['q'][i][l][k]*X[k] for k in range(len(X)) if X[k]) for l in range(d)] for i in range(d)]


import sympy as sp
D, x = sp.symbols('D x')
def pos_on(r, lo=16):
    r = sp.factor(sp.together(sp.sympify(r)))
    if r == 0: return False, 'zero'
    n, d = sp.fraction(r)
    def coeff_ok(p):
        P = sp.Poly(sp.expand(p.subs(D, lo + x)), x); cs = P.all_coeffs()
        return all(c >= 0 for c in cs) and cs[-1] > 0
    if coeff_ok(n) and coeff_ok(d): return True, 'shifted-coefficients'
    def noroot(p):
        P = sp.Poly(sp.expand(p), D)
        if P.degree() <= 0: return P.as_expr() != 0
        return P.count_roots(lo, None) == 0 if hasattr(P, 'count_roots') else False
    try:
        nr = noroot(n) and noroot(d)
    except Exception:
        # fallback: count roots on [lo, big] plus leading-coefficient sign for the tail via Cauchy bound
        nr = True
        for p in (n, d):
            P = sp.Poly(sp.expand(p), D)
            if P.degree() <= 0: continue
            cs = P.all_coeffs(); B = 1 + max(abs(c/cs[0]) for c in cs[1:]) if len(cs) > 1 else 1
            if P.count_roots(lo, max(lo, sp.ceiling(B)) + 1) != 0: nr = False
    if nr and r.subs(D, lo) > 0: return True, 'sturm'
    return False, 'fail'

# ======================= Gate F3 checks =======================
import os, hashlib, time
HERE = os.path.dirname(os.path.abspath(__file__))
from sympy import QQ as _QQ
Dsym = sp.symbols('D'); KF = _QQ.frac_field(Dsym)
RESULTS = []
def ok(name, cond, info=''):
    RESULTS.append((name, bool(cond))); print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + str(info)) if info != '' else ''), flush=True)
def J(name): return json.load(open(os.path.join(HERE, name)))
def kpoly(p): return KF.from_sympy(sum(int(c)*Dsym**int(e) for e, c in p.items()))
class SA:
    """E1 orbit-sum algebra over Q(D): b_i b_k = sum_l f_ikl(D) b_l, tau(b_k) = tr_k(D), b_k^* = b_{star(k)}."""
    def __init__(s, alg, u, us):
        s.r = r = len(alg['star']); s.st = alg['star']; s.u, s.us = u, us; s.f = {}
        for i in range(r):
            for k in range(r):
                for l, p in alg['f'][i][k].items(): s.f.setdefault((i, k), []).append((int(l), kpoly(p)))
        s.tr = [kpoly(p) for p in alg['tr']]
    def zero(s): return [KF.zero]*s.r
    def basis(s, k): v = s.zero(); v[k] = KF.one; return v
    def unit(s): v = s.zero(); v[s.u] = KF.from_sympy(sp.Rational(1, s.us)); return v
    def mul(s, a, b):
        out = s.zero()
        for i in range(s.r):
            if not a[i]: continue
            for k in range(s.r):
                if not b[k]: continue
                c = a[i]*b[k]
                for l, v in s.f.get((i, k), []): out[l] += c*v
        return out
    def star(s, a):
        out = s.zero()
        for k in range(s.r): out[s.st[k]] = a[k]
        return out
    def tau(s, a): return sum((a[i]*s.tr[i] for i in range(s.r)), KF.zero)
    def scale(s, a, c): return [x*c for x in a]
TS = lambda x: KF.to_sympy(x)
def sym_blocks(s, idem, name):
    """build + verify the exact block decomposition of s over Q(D) from the central idempotents idem."""
    es = [[KF.from_sympy(sp.sympify(x)) for x in e] for e in idem]; r = s.r; one = s.unit(); Ks = [KF.one]*r
    eq = lambda a, b: all(x == y for x, y in zip(a, b))
    tot = s.zero(); blocks = []; allok = True
    for j, e in enumerate(es):
        M = sp.Matrix([[TS(x).subs(Dsym, 37) for x in s.mul(e, s.basis(k))] for k in range(r)])
        dim = M.rank(); d = int(round(dim**0.5)); assert d*d == dim
        if d == 1: p = e
        else:
            y = s.mul(e, Ks); y2 = s.mul(y, y); i0 = next(i for i in range(r) if y[i]); p = s.scale(y, KF.one/(y2[i0]/y[i0]))
        xs = [s.unit()] if d == 1 else []
        if d > 1:
            vecs = []
            for k in range(r):
                v = s.mul(s.basis(k), p); cand = vecs + [[TS(t).subs(Dsym, 37) for t in v]]
                if sp.Matrix(cand).rank() == len(cand): vecs = cand; xs.append(s.basis(k))
                if len(xs) == d: break
        xp = [s.mul(x, p) for x in xs]; tp = s.tau(p)
        c1 = eq(s.mul(e, e), e) and eq(s.star(e), e) and all(eq(s.mul(e, s.basis(k)), s.mul(s.basis(k), e)) for k in range(r))
        c2 = eq(s.mul(p, p), p) and eq(s.star(p), p) and eq(s.mul(e, p), p)
        i0 = next(i for i in range(r) if p[i]); c3 = True
        for k in range(r):
            q = s.mul(p, s.mul(s.basis(k), p))
            if not eq(q, s.scale(p, q[i0]/p[i0])): c3 = False
        Gram = sp.Matrix(d, d, lambda i, l: TS(s.tau(s.mul(s.star(xp[i]), xp[l]))/tp))
        gd = sp.factor(Gram.det()); c4 = pos_on(gd)[0] and pos_on(TS(tp))[0]
        H = [[[s.tau(s.mul(s.star(xp[i]), s.mul(s.basis(k), xp[l])))/tp for l in range(d)] for i in range(d)] for k in range(r)]
        blocks.append(dict(j=j, d=d, e=e, p=p, xs=xs, H=H, Gram=Gram))
        tot = [a + b for a, b in zip(tot, e)]
        allok &= c1 and c2 and c3 and c4
        ok(f'{name} block {j} (d={d}): e central Hermitian idempotent; p minimal projection in it; Gram det {gd} > 0 and tau(p) > 0 on [16,oo)', c1 and c2 and c3 and c4)
    orth = all(not any(s.mul(a['e'], b['e'])) for a in blocks for b in blocks if a['j'] < b['j'])
    ok(f'{name}: sum e_j = unit, e_j e_l = 0 (j != l), sum d_j^2 = {sum(b["d"]**2 for b in blocks)} = dim {r}', eq(tot, one) and orth and sum(b['d']**2 for b in blocks) == r)
    return blocks
def Hval(blk, X, r):
    d = blk['d']; return sp.Matrix(d, d, lambda i, l: TS(sum((X[k]*blk['H'][k][i][l] for k in range(r) if X[k]), KF.zero)))
def minors_pos(M):
    return all(pos_on(sp.factor(sp.together(M[:k, :k].det())))[0] for k in range(1, M.shape[0] + 1))
def ldl_psd(M):
    """exact: symmetric rational M is PSD (LDL^T with zero pivots allowed only on zero rows)."""
    n = len(M); A = [[Fr(x) for x in row] for row in M]
    if any(A[i][l] != A[l][i] for i in range(n) for l in range(n)): return False
    for k in range(n):
        if A[k][k] < 0: return False
        if A[k][k] == 0:
            if any(A[k][l] != 0 for l in range(k, n)): return False
            continue
        for i in range(k+1, n):
            f = A[i][k]/A[k][k]
            for l in range(k+1, n): A[i][l] -= f*A[k][l]
    return True
def ldl_pd(M):
    n = len(M); A = [[Fr(x) for x in row] for row in M]
    if any(A[i][l] != A[l][i] for i in range(n) for l in range(n)): return False
    for k in range(n):
        if A[k][k] <= 0: return False
        for i in range(k+1, n):
            f = A[i][k]/A[k][k]
            for l in range(k+1, n): A[i][l] -= f*A[k][l]
    return True
def part_2to4():
    D = Dsym; E1 = J('gateE1_data.json'); idem = J('idem_E1.json'); FP = J('dual_params_F3.json')
    A = SA(E1['A'], 15, 48); B = SA(E1['B'], 15, 48); r = 21
    ok('E1 data: unit orbit 15 (P = b_15/48), gamma_orbit_map = identity, star involution', E1['unit_orbit'] == 15 and E1['gamma_orbit_map'] == list(range(21)) and all(E1['A']['star'][E1['A']['star'][k]] == k for k in range(21)))
    BA = sym_blocks(A, idem['A'], 'A'); BB = sym_blocks(B, idem['B'], 'B')
    # ---- generators of Z6*W in B
    P = lambda x: KF.from_sympy(sp.sympify(x))
    names = []; gens = {}
    for j in [0, 1, 3, 4, 5, 6, 7, 8]: names.append(f'beta{j}'); gens[names[-1]] = BB[j]['e']; assert BB[j]['d'] == 1
    b0 = B.basis(0); q0 = B.scale(b0, KF.from_sympy(1/(6*D*(D+2))))
    okq = B.mul(b0, b0) == B.scale(b0, KF.from_sympy(6*D*(D+2))) and B.star(b0) == b0 and B.mul(BB[9]['e'], b0) == b0
    ok("B: b'_0^2 = 6D(D+2) b'_0, b'_0 Hermitian, e'_9 b'_0 = b'_0  (so Q9 = e'_9 - b'_0/(6D(D+2)) is a projection, Q9 b'_0 = 0)", okq)
    q9 = [a - b for a, b in zip(BB[9]['e'], q0)]; names.append('gamma'); gens['gamma'] = q9
    m3 = BB[2]; assert m3['d'] == 3
    xp = [B.mul(x, m3['p']) for x in m3['xs']]
    for i in range(3):
        for l in range(i, 3):
            w = B.mul(xp[i], B.star(m3['xs'][l]))
            if i != l: w = [a + b for a, b in zip(w, B.mul(xp[l], B.star(m3['xs'][i])))]
            names.append(f'c{i}{l}'); gens[names[-1]] = w
    # ---- parameters (closed form)
    yt = 6*(D+4)*(D+8)*(D+16)/D; x = sp.Rational(16)/D; cs = yt*5/((D+4)*(D+8))/300; par = {}
    for n, cl in FP['P'].items():
        poly = sum(sp.Rational(c)*x**k for k, c in enumerate(cl)); par[n] = (yt if (n.startswith('beta') or n == 'gamma') else cs)*poly
    par['c12'] = -(4*D**2*(D+4)*par['c02'] + 32*D*(D+4)*par['c01'] + 128*D*par['c11'] + 5*D**2 + 90*D + 160)/(16*D**2)
    par = {k: sp.factor(sp.together(v)) for k, v in par.items()}
    Z6 = D*(D+1)*(D+2)*(D+4)*(D+8)*(D+16); g = 6/(D**2*(D+1)*(D+2))
    ok('value: yt = Z6*g(D) and D2*g = 3/(D(D+2)) with D2 = D(D+1)/2 (identities in Q(D))', sp.simplify(yt - Z6*g) == 0 and sp.simplify(D*(D+1)/2*g - 3/(D*(D+2))) == 0)
    # ---- W >= 0
    okb = all(pos_on(par[n])[0] for n in names[:9])
    ok('W: the 8 central weights beta_j and gamma are > 0 for all real D >= 16', okb)
    C = sp.Matrix(3, 3, lambda i, l: par[f'c{min(i,l)}{max(i,l)}'])
    ok("W: M3-block coefficient matrix C is positive definite for all real D >= 16 (leading minors)", minors_pos(C))
    w = s0 = None
    w = A.zero()
    for n in names: w = [a + KF.from_sympy(par[n])*b for a, b in zip(w, gens[n])]
    # ---- S in A (Gamma(b'_k) = b_k)
    S = [KF.from_sympy(-sp.Integer(1)) - wk for wk in w]; S[15] += KF.from_sympy(yt/48)
    allS = True
    for b in BA:
        M = Hval(b, S, r).applyfunc(lambda e: sp.factor(sp.together(e)))
        if b['j'] == 9:
            G = b['Gram']; a0 = sp.simplify(G.inv()*sp.Matrix([D, 4])); a1 = sp.Matrix([-(G*a0)[1], (G*a0)[0]])
            z = all(sp.simplify(t) == 0 for t in M*a0); q = sp.factor(sp.together((a1.T*M*a1)[0]))
            okb9 = z and pos_on(q)[0]; allS &= okb9
            ok('S: A block 9 (M2): H(S) a0 = 0 identically (a0 = G^-1 (D,4)^T) and a1^T H(S) a1 > 0 on [16,oo)  => block PSD of rank 1', okb9)
        elif b['d'] == 1:
            o = pos_on(M[0, 0])[0]; allS &= o; ok(f'S: A block {b["j"]} (1-dim) value > 0 on [16,oo)', o)
        else:
            o = minors_pos(M); allS &= o; ok(f'S: A block {b["j"]} (M{b["d"]}) positive definite on [16,oo) (leading minors)', o)
    ok('2->4 EXACT DUAL: W >= 0, S = gP - K - Gamma(W) >= 0 for every real D >= 16  =>  PPT(2->4) <= g(D) at every n >= 4', okb and allS)
    return par, gens, names
def part_2to4_fixedD(par, gens, names):
    E1 = J('gateE1_data.json'); D = Dsym
    for Dv in (16, 64, 1024):
        A = FA(E1['A'], Dv, 15, 48); B = FA(E1['B'], Dv, 15, 48)
        BA = blocks(A, log=lambda m: None); BB = blocks(B, log=lambda m: None)
        def ev(x): v = sp.Rational(sp.sympify(x).subs(D, Dv)); return Fr(int(v.p), int(v.q))
        w = [Fr(0)]*21
        for n in names:
            pn = ev(par[n]); w = [a + pn*ev(TS(gk)) for a, gk in zip(w, gens[n])]
        yt = Fr(6*(Dv+4)*(Dv+8)*(Dv+16), Dv)
        S = [Fr(-1) - wk for wk in w]; S[15] += yt/48
        okW = all(ldl_psd(H(b, w)) for b in BB); okS = all(ldl_psd(H(b, S)) for b in BA)
        ok(f'2->4 independent fixed-D re-check at D = {Dv} (fresh centre/idempotents/minimal projections, exact LDL): W >= 0 and S >= 0', okW and okS)
def lam3_vs(Dv, val):
    """sign of Z7*lambda_3(D) - val, lambda_3 = 135(D+576+sqrt(D^2+64D+296960))/Z7 (ledger v7 Thm A), exact."""
    X = Fr(val) - 135*(Dv + 576); R = 135**2*(Dv**2 + 64*Dv + 296960)
    if X < 0: return 1
    return 1 if X*X < R else (-1 if X*X > R else 0)
def part_3to4():
    E2 = J('gateE2_data.json'); r = 81; g = E2['gamma_orbit_map']; uA, uB = E2['A_unit_orbit'], E2['B_unit_orbit']
    Z7 = lambda D: D*(D+1)*(D+2)*(D+4)*(D+8)*(D+16)*(D+32)
    z7g56 = lambda D: Fr(18*(D+4)*(D+8)*(D+16)*(D+32), D*(D+2))
    D = Dsym
    ok('3->4: D3*g56 = 3/(D(D+2)) (D3 = D(D+1)(D+2)/6) and Z7*g56 = 18(D+4)(D+8)(D+16)(D+32)/(D(D+2))', sp.simplify(D*(D+1)*(D+2)/6*18/(D**2*(D+1)*(D+2)**2) - 3/(D*(D+2))) == 0)
    # n = 6 witness value (E2)
    A64 = FA(E2['A'], 64, uA, 144)
    c = [Fr(sp.Rational(x).p, sp.Rational(x).q) for x in E2['witness_n6']['c']]
    kvec = [sum(A64.tau(A64.mul(A64.basis(l), A64.basis(k))) for l in range(r)) for k in range(r)]
    val = sum(c[k]*kvec[k] for k in range(r)); trr = A64.tau(c)
    ok('n = 6 E2 witness: tr rho = 1 and Z7*tr(K rho) = 310463458075907668302651648/1720270933899732290219 (recomputed)', trr == 1 and val == Fr(310463458075907668302651648, 1720270933899732290219), float(val))
    ok('n = 6: witness value > Z7*g56(64) = 1762560/11  => PPT(3->4, n=6) > g56, so NO dual with value g56 exists at n = 6 (failing step = the relaxation)', val > z7g56(64) and z7g56(64) == Fr(1762560, 11), float(z7g56(64)))
    # certified upper bounds
    rows = []
    for Dv in (16, 32, 64, 128, 256, 512, 1024):
        dat = J(f'e2dual_D{Dv}.json'); yt = Fr(sp.Rational(dat['y_cert']).p, sp.Rational(dat['y_cert']).q)
        wv = [Fr(sp.Rational(x).p, sp.Rational(x).q) for x in dat['w']]
        A = FA(E2['A'], Dv, uA, 144); B = FA(E2['B'], Dv, uB, 144)
        BA = blocks(A, log=lambda m: None); BB = blocks(B, log=lambda m: None)
        herm = all(wv[m] == wv[E2['B']['star'][m]] for m in range(r))
        S = [Fr(-1) - wv[g[k]] for k in range(r)]; S[uA] += yt/144
        okW = all(ldl_pd(H(b, wv)) for b in BB); okS = all(ldl_pd(H(b, S)) for b in BA)
        ok(f'3->4 certified dual at D = {Dv}: W Hermitian, W > 0 and S > 0 in every block (exact LDL)  =>  Z7*PPT <= {float(yt):.4f}; Z7*g56 = {float(z7g56(Dv)):.4f}', herm and okW and okS)
        rows.append((Dv, yt))
    yt64 = dict(rows)[64]
    ok('n = 6 bracket: 180473.58... <= Z7*PPT(3->4) <= certified dual value (182293.63)', val <= yt64)
    # third copy: lambda_3 vs g56
    s = [lam3_vs(Dv, z7g56(Dv)) for Dv in (16, 32, 64, 128)]
    ok('third copy: Z7*lambda_3 > Z7*g56 at D = 16, 32, 64 and < at D = 128 (exact): the 3-copy PGM seed beats every 2-copy strategy at n = 4, 5, 6 (given EB*(2->4) = 3/(D(D+2)))', s == [1, 1, 1, -1], s)
    ok('n = 6: witness value > Z7*lambda_3(64) (exact)', lam3_vs(64, val) == -1)
    return rows
if __name__ == '__main__':
    t0 = time.time()
    for fn in sorted(os.listdir(HERE)):
        if fn.endswith('.json'): print('sha256', hashlib.sha256(open(os.path.join(HERE, fn), 'rb').read()).hexdigest(), fn)
    par, gens, names = part_2to4()
    part_2to4_fixedD(par, gens, names)
    part_3to4()
    np_ = sum(1 for _, c in RESULTS if c); nf = len(RESULTS) - np_
    print(f'SUMMARY: {np_} PASS / {nf} FAIL  ({time.time()-t0:.0f} s)')
