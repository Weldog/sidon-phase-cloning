# run_full_checks.ps1 — the three runs that need more than ~1 GB per process (n = 3, 2->4 certificate; full Bell checks n = 4, 5).
# Usage: put this script and paper3_v2_certificates.zip in Downloads, then run (one line):
#   powershell -ExecutionPolicy Bypass -File "$HOME\Downloads\run_full_checks.ps1"
# Each check is PASS only if it exits 0 AND its log contains the expected marker; the script exits 1 if any check fails.
$ErrorActionPreference = "Continue"
$env:PYTHONUTF8 = "1"; $env:PYTHONIOENCODING = "utf-8"
$dl  = Join-Path $HOME "Downloads"
$zip = Get-ChildItem -Path $dl -Filter "paper3_v2_certificates*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $zip) { Write-Host "STOP: paper3_v2_certificates.zip not found in $dl." -ForegroundColor Red; exit 1 }
Write-Host "Using bundle: $($zip.FullName)"
Expand-Archive -Path $zip.FullName -DestinationPath $dl -Force
$B = Join-Path $dl "paper3_v2_certificates"
if (-not (Test-Path (Join-Path $B "thm18_2to4\n3\fresh_checker_n3.py"))) { Write-Host "STOP: extraction problem under $B" -ForegroundColor Red; exit 1 }
$L = Join-Path $B "logs_expected"; $failed = 0
function Run-Check([string]$name, [string]$dir, [string]$cmd, [string]$marker, [string]$badMarker) {
    $log = Join-Path $L "$name.log"; $t0 = Get-Date
    Write-Host "`n[$($t0.ToString('HH:mm:ss'))] START $name" -ForegroundColor Cyan
    Push-Location $dir; cmd /c "$cmd > `"$log`" 2>&1"; $rc = $LASTEXITCODE; Pop-Location
    $text = Get-Content $log -Raw
    $ok = ($rc -eq 0) -and ($text -match $marker) -and (-not ($badMarker -and ($text -match $badMarker)))
    $mins = [math]::Round(((Get-Date) - $t0).TotalMinutes, 1)
    if ($ok) { Write-Host "PASS  $name  (exit $rc, $mins min)" -ForegroundColor Green } else { Write-Host "FAIL  $name  (exit $rc, $mins min)" -ForegroundColor Red; $script:failed = 1 }
    Get-Content $log -Tail 2
}
Run-Check "thm18_n3_2to4_FULL" (Join-Path $B "thm18_2to4\n3") "py fresh_checker_n3.py certificates/cert_n3_2to4.json" '"case": "2to4".*"PASS": true' '"PASS": false'
Run-Check "prop17_F1_FULL"     (Join-Path $B "prop17_bell")   "py check_gateF1.py --n4-range" 'FAILS: 0' ''
Run-Check "prop17_F2_FULL"     (Join-Path $B "prop17_bell")   "py check_gateF2.py" 'FAILS: 0' ''
if ($failed -eq 0) { Write-Host "`nALL THREE CHECKS PASSED. Logs: $L" -ForegroundColor Green } else { Write-Host "`nSOME CHECK FAILED. Logs: $L" -ForegroundColor Red }
exit $failed
