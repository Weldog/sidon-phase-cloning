"""Independent exact checks for cyclic qubit H-SEP instances (private)."""
from sympy import Matrix, sqrt, simplify, binomial, Rational

# Matrix 2^(m+2) B for flat qubit measurement seed on q uniform equator phases.
# B = average_phi |<psi_0|psi_phi>|^2 |psi_phi>^⊗m<psi_phi|^⊗m,
# in normalized m-copy Dicke basis.
def scaled_B(q,m):
    result=Matrix.zeros(m+1)
    for a in range(m+1):
        for b in range(m+1):
            dif=a-b
            coeff = 2*int((dif==0) if q is None else (dif%q==0))
            coeff += int(abs(dif)==1) if q is None else int((dif-1)%q==0)+int((dif+1)%q==0)
            result[a,b]=sqrt(binomial(m,a)*binomial(m,b))*coeff
    return result
# Actual B is scaled_B/2^(m+2) and P_EB=2lambda_max(B).

A3=scaled_B(3,2); Ainf2=scaled_B(None,2)
A4=scaled_B(4,3); Ainf3=scaled_B(None,3)
print('A_trine =',A3)
print('A_torus_1to2 =',Ainf2)
print('A_four_phases =',A4)
print('A_torus_1to3 =',Ainf3)
assert A3 == Matrix([[2,sqrt(2),1],[sqrt(2),4,sqrt(2)],[1,sqrt(2),2]])
assert Ainf2 == Matrix([[2,sqrt(2),0],[sqrt(2),4,sqrt(2)],[0,sqrt(2),2]])
assert A4 == Matrix([[2,sqrt(3),0,1],[sqrt(3),6,3,0],[0,3,6,sqrt(3)],[1,0,sqrt(3),2]])

def largest_exact(A):
    vals=list(A.eigenvals())
    return max(vals,key=lambda x:float(x))
for (label,A,m,expected) in [
 ('trine',A3,2,(7+sqrt(17))/16),
 ('torus 1to2',Ainf2,2,(3+sqrt(5))/8),
 ('four phases 1to3',A4,3,(3+sqrt(3))/8),
 ('torus 1to3',Ainf3,3,(11+sqrt(61))/32),
]:
    answer=simplify(2*largest_exact(A)/2**(m+2))
    assert simplify(answer-expected)==0,(label,answer,expected)
    print(label,'P_EB=',answer,'approximately',answer.evalf(14))
assert float((7+sqrt(17))/16-(3+sqrt(5))/8)>0
assert float((3+sqrt(3))/8-(11+sqrt(61))/32)>0
# Check exact moment alias threshold in the 1to(m) mixed moment via exponents:
for m in range(2,9):
    for q in range(2,m+5):
        difference=scaled_B(q,m)-scaled_B(None,m)
        matches=(difference==Matrix.zeros(m+1))
        assert matches == (q>=m+2), (m,q)
print('For 2<=m<=8, q>=2: B_q=B_torus iff q>=m+2 -- PASS')
print('ALL_PASS=True')
