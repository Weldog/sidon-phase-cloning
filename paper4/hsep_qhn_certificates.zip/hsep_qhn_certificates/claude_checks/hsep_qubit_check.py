# Claude: independent check of GPT's cyclic-qubit H-SEP theorem instances (own SDPs; GPT's script not used).
import numpy as np, cvxpy as cp, math, itertools
exec(open('sep_check.py').read().split('t0=time.time()')[0])
def fam_X(phase_list,m,T,d):
    Om,OT=occ(m,d),occ(T,d); Cm=np.array([coef(a) for a in Om]); CT=np.array([coef(a) for a in OT])
    X=0
    for ph in phase_list:
        v=np.kron(sym_vec(np.array(ph),m,Om,Cm), np.conj(sym_vec(np.array(ph),T,OT,CT))); X=X+np.outer(v,v.conj())
    return X/len(phase_list), len(Om), len(OT)
def fam_K(phase_list,T,m,d):     # E rho^{⊗T} ⊗ rho^{⊗m} (no conjugation), input ⊗ output
    OT,Om=occ(T,d),occ(m,d); CT=np.array([coef(a) for a in OT]); Cm=np.array([coef(a) for a in Om]); K=0
    for ph in phase_list:
        v=np.kron(sym_vec(np.array(ph),T,OT,CT), sym_vec(np.array(ph),m,Om,Cm)); K=K+np.outer(v,v.conj())
    return K/len(phase_list), len(OT), len(Om)
def eb_ppt(K,a,b,DT):
    rho=cp.Variable((a*b,a*b),hermitian=True)
    pr=cp.Problem(cp.Maximize(cp.real(cp.trace(K@rho))),[rho>>0, cp.real(cp.trace(rho))==1, cp.partial_transpose(rho,[a,b],axis=0)>>0])
    pr.solve(solver=cp.SCS,eps=1e-10,max_iters=200000); return DT*pr.value
d=2; dense=[ [0,2*np.pi*j/400] for j in range(400)]     # dense circle approximates the torus (moments exact up to order < 400)
for q,T,m,eb_exact,label in [(3,1,2,(7+math.sqrt(17))/16,"trine 1->2"),(4,1,3,(3+math.sqrt(3))/8,"four phases 1->3")]:
    fam=[[0,2*np.pi*j/q] for j in range(q)]
    Xf,dm,dT=fam_X(fam,m,T,d); Xt,_,_=fam_X(dense,m,T,d)
    cf=clone_opt(Xf,dm,dT); ct=clone_opt(Xt,dm,dT)
    Kf,a,b=fam_K(fam,T,m,d); Kt,_,_=fam_K(dense,T,m,d); DT=math.comb(d+T-1,T)
    ef=eb_ppt(Kf,a,b,DT); et=eb_ppt(Kt,a,b,DT)
    print(f"{label}: coherent family {cf:.9f} vs torus {ct:.9f} (diff {cf-ct:+.1e})")
    print(f"   EB (PPT bound; qubit 1->m: PPT = separable for 2x(m+1)? only for m=1) family {ef:.9f} [GPT exact {eb_exact:.9f}] vs torus {et:.9f}")
print("GPT exact torus EB: 1->2 (3+sqrt5)/8 =",(3+math.sqrt(5))/8,"  1->3 (11+sqrt61)/32 =",(11+math.sqrt(61))/32)
