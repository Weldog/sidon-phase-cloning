# QH-N independent numeric checks (Claude). State |psi_f> = p^{-1/2} sum_t w^{f(t)} |t>, f in F_p[t], deg f <= r, f(0) = 0.
import itertools, numpy as np, math, sys
def poly_vals(c,p):            # c = (c1..cr) coefficients of t..t^r ; returns f(t) for t in F_p
    t=np.arange(p); return sum(ci*pow_mod(t,i+1,p) for i,ci in enumerate(c))%p
def pow_mod(t,e,p): return np.array([pow(int(x),e,p) for x in t])
def occ(l,p): return [a for a in itertools.product(range(l+1),repeat=p) if sum(a)==l]
def mixed_moment_dev(p,r,a,b):
    """max |E_f X^{(a,b)} - E_torus X^{(a,b)}| over entries, X^{(a,b)} = psi^{⊗a} ⊗ conj(psi)^{⊗b} (symmetric-occupation basis)"""
    A=np.array(occ(a,p)); Bo=np.array(occ(b,p))
    ca=np.array([math.sqrt(math.factorial(a)/np.prod([math.factorial(x) for x in o])) for o in A])
    cb=np.array([math.sqrt(math.factorial(b)/np.prod([math.factorial(x) for x in o])) for o in Bo])
    dim=len(A)*len(Bo); M=np.zeros((dim,dim),dtype=complex); n=0
    for c in itertools.product(range(p),repeat=r):
        f=poly_vals(c,p); ph=np.exp(2j*np.pi*f/p)
        va=ca*np.prod(ph[None,:]**A,axis=1); vb=cb*np.prod(np.conj(ph)[None,:]**Bo,axis=1)
        v=np.kron(va,vb)/p**((a+b)/2); M+=np.outer(v,v.conj()); n+=1
    M/=n
    # torus: entry nonzero iff (alpha - alpha') - (beta - beta') == 0 as vectors
    T=np.zeros_like(M)
    idx=[(i,j) for i in range(len(A)) for j in range(len(Bo))]
    for x,(i,j) in enumerate(idx):
        for y,(k,l) in enumerate(idx):
            if np.array_equal(A[i]-A[k]-(Bo[j]-Bo[l]),0*A[i]):
                T[x,y]=ca[i]*cb[j]*ca[k]*cb[l]/p**(a+b)
    return np.abs(M-T).max()
print("Moment identity checks (mixed moments psi^a ⊗ conj(psi)^b, a+b = order):")
for (p,r,a,b) in [(5,3,2,1),(5,2,2,1),(7,3,2,1),(7,3,3,0),(7,2,3,0),(7,4,3,1),(7,3,3,1)]:
    dev=mixed_moment_dev(p,r,a,b)
    print(f"  p={p} deg<={r}  (a,b)=({a},{b}) order {a+b}: max deviation {dev:.1e}  -> {'EXACT' if dev<1e-12 else 'differs'}"
          f"   [prediction: exact iff deg >= order]")
print("Collision (max |<psi_f|psi_g>| over f != g, i.e. over nonzero difference polynomials) vs Weil bound (r-1)/sqrt(p):")
for r in (3,5):
    for p in (11,13,17,19,23,29,31):
        if p<=r: continue
        best=0.0; t=np.arange(p); pw=[pow_mod(t,i+1,p) for i in range(r)]
        for c in itertools.product(range(p),repeat=r):
            if not any(c): continue
            f=sum(ci*pw[i] for i,ci in enumerate(c))%p
            best=max(best,abs(np.exp(2j*np.pi*f/p).sum())/p)
            if r==5 and p>13: break_flag=False
        welch=math.sqrt((p**r-p)/(p*(p**r-1)))
        print(f"  r={r} p={p}: max overlap {best:.4f}  Weil bound {(r-1)/math.sqrt(p):.4f}  Welch {welch:.4f}  ratio-to-Welch {best/welch:.2f}")
        if r==5 and p>=13: break
