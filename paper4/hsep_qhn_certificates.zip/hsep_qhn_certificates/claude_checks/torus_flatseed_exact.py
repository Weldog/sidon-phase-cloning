# Claude: exact (algebraic) value of the torus flat-seed measure-first strategy (Lemma 'every collision helps'),
# P_flat = D_T * lambda_max(N_tor), for d=2, T=2, k=1. A valid strategy, so this is a certified LOWER bound on the
# torus measure-first optimum; combined with Grok Bot's certified upper bound U (sym_check.py) it pins the value.
import itertools, sympy as sp
from math import factorial, prod, comb
d,T,k=2,2,1; m=T+k; n=2*T+k; DT=comb(d+T-1,T)
occ=lambda t:[a for a in itertools.product(range(t+1),repeat=d) if sum(a)==t]
mm=lambda a: factorial(sum(a))//prod(factorial(x) for x in a)
A,Bo=occ(T),occ(m)
N=sp.zeros(len(Bo),len(Bo))
for i,b in enumerate(Bo):
    for j,b2 in enumerate(Bo):
        s=0
        for a in A:
            for a2 in A:
                if tuple(x+y for x,y in zip(a,b))==tuple(x+y for x,y in zip(a2,b2)):
                    s+=sp.sqrt(mm(a)*mm(a2))
        N[i,j]=sp.sqrt(mm(b)*mm(b2))*s/(DT*d**n)
lam=max(N.eigenvals(), key=lambda z: float(sp.re(z)))
P=sp.nsimplify(sp.simplify(DT*lam))
print("P_flat(torus, d=2, 2->3) =", sp.simplify(DT*lam), "~", sp.N(DT*lam,20))
U=sp.Rational(274462405768278053417195398811,384847948803266500000000000000)
print("Grok certified upper bound U ~", sp.N(U,20), "; U - P_flat =", sp.N(U-DT*lam,5))
