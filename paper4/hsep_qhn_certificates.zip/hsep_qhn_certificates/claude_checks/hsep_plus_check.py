import os; os.chdir(os.path.dirname(os.path.abspath(__file__)))  # run from this folder (paths relative to the bundle)
# Claude: independent NUMERICAL check of the six-state H-SEP+ counterexample V1 (own SDP code; Grok Bot's checkers not used).
# Coherent optima: SDP over all channels. Measure-first: the standard Choi-matrix PPT relaxation (J >= 0, J^Gamma >= 0,
# Tr_out J = I), an UPPER bound on entanglement-breaking channels. This is a numerical comparison, not a certificate.
# (An earlier draft also printed a looser product-state PPT relaxation; it was removed as uninformative at T = 2.)
import json, math, numpy as np, cvxpy as cp, warnings; warnings.filterwarnings('ignore')
exec(open('hsep_qubit_check.py').read().split("d=2; dense=")[0])
J=json.load(open('../hsep_plus_counterexamples/certs/ratio/V1_136min_summary.json'))
d,T,k=2,J['T'],J['k']; m=T+k
fam=[[0,t] for t in J['theta']]; dense=[[0,2*np.pi*j/400] for j in range(400)]
Xf,dm,dT=fam_X(fam,m,T,d); Xt,_,_=fam_X(dense,m,T,d)
cf=clone_opt(Xf,dm,dT); ct=clone_opt(Xt,dm,dT)
def eb_choi_ppt(X,dm,dT):
    Jv=cp.Variable((dm*dT,dm*dT),hermitian=True)
    cons=[Jv>>0, cp.partial_transpose(Jv,[dm,dT],axis=1)>>0, cp.partial_trace(Jv,[dm,dT],axis=0)==np.eye(dT)]
    pr=cp.Problem(cp.Maximize(cp.real(cp.trace(Jv@X))),cons); pr.solve(solver=cp.SCS,eps=1e-10,max_iters=300000); return pr.value
ef=eb_choi_ppt(Xf,dm,dT); et=eb_choi_ppt(Xt,dm,dT)
print(f"coherent: family {cf:.9f} (Grok {J['L_coh_F']:.9f})   torus {ct:.9f} (Grok {J['U_coh_tor']:.9f})   gap {cf-ct:.7f}")
print(f"measure-first, Choi-PPT upper bounds: family {ef:.9f} (Grok {J['U_PPT_F']:.9f})   torus {et:.9f} (Grok {J['U_EB_tor']:.9f})")
print(f"numerical comparison: (PPT_F - PPT_tor)/(coh gap) = {(ef-et)/(cf-ct):.6f}   (Grok certified bracket {J['ratio_bracket']})")
