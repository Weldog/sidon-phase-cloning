import os; os.chdir(os.path.dirname(os.path.abspath(__file__)))  # run from this folder (paths relative to the bundle)
# Claude: independent numeric reproduction (own SDP code) of the producer-only numbers in Paper 4 v5:
# fourteen-state (d=2) and eight-state (V2, d=2) and d=3 six-state ratio certificates (2->3), and the torus coherent
# value (667+36*sqrt(38))/2401 at d=7, 2->3 (via the reduced coherent dual, validated first at d=5).
import json, math, itertools, numpy as np, cvxpy as cp, warnings; warnings.filterwarnings('ignore')
exec(open('sep_check.py').read().split('t0=time.time()')[0])
def fam_X(phl,m,T,d):
    Om,OT=occ(m,d),occ(T,d); Cm=np.array([coef(a) for a in Om]); CT=np.array([coef(a) for a in OT]); X=0
    for ph in phl:
        v=np.kron(sym_vec(np.array(ph),m,Om,Cm), np.conj(sym_vec(np.array(ph),T,OT,CT))); X=X+np.outer(v,v.conj())
    return X/len(phl), len(Om), len(OT)
def eb_choi_ppt(X,dm,dT):
    J=cp.Variable((dm*dT,dm*dT),hermitian=True)
    pr=cp.Problem(cp.Maximize(cp.real(cp.trace(J@X))),[J>>0, cp.partial_transpose(J,[dm,dT],axis=1)>>0, cp.partial_trace(J,[dm,dT],axis=0)==np.eye(dT)])
    pr.solve(solver=cp.SCS,eps=1e-10,max_iters=300000); return pr.value
for f in ['../hsep_plus_counterexamples/grok_G9_additional/d2_n14_s12_3best_summary.json','../hsep_plus_counterexamples/certs/ratio/V2_024min_summary.json','../hsep_plus_counterexamples/grok_G9_additional/d3_014best_summary.json']:
    J=json.load(open(f)); d,T,k=J['d'],J['T'],J['k']; m=T+k
    th=J['theta'] if isinstance(J['theta'],list) else json.loads(J['theta'])
    fam=[[0.0]+([t] if not isinstance(t,list) else list(t)) for t in th] if d==2 else [[0.0]+list(t) for t in th]
    fam=[ph[:d] if len(ph)>=d else ph for ph in fam]
    Xf,dm,dT=fam_X(fam,m,T,d); Xt,_,_=torus_X(m,T,d)
    cf,ct=clone_opt(Xf,dm,dT),clone_opt(Xt.astype(complex),dm,dT); ef,et=eb_choi_ppt(Xf,dm,dT),eb_choi_ppt(Xt.astype(complex),dm,dT)
    print(f"{J['name']}: coh F {cf:.7f} (Grok {J['L_coh_F']:.7f}) tor {ct:.7f} | EB-PPT F {ef:.7f} (Grok {J['U_PPT_F']:.7f}) tor {et:.7f} | ratio {(ef-et)/(cf-ct):.5f} (Grok {J['ratio_bracket'][0]:.5f}-{J['ratio_bracket'][1]:.5f})",flush=True)
def torus_coh_reduced(d,T,k):
    OT=occ(T,d); Om=occ(T+k,d); mult=lambda a: math.factorial(sum(a))/np.prod([math.factorial(x) for x in a])
    z=cp.Variable(len(OT),pos=True); idx={a:i for i,a in enumerate(OT)}; Mset=set(Om); cons=[]
    diffs=set(tuple(np.subtract(b,a)) for a in OT for b in Om)
    for s in diffs:
        terms=[mult(tuple(np.add(s,a)))*z[idx[a]] for a in OT if tuple(np.add(s,a)) in Mset]
        if terms: cons.append(sum(terms)/d**(2*T+k)<=1)
    obj=sum(mult(a)*cp.inv_pos(z[idx[a]]) for a in OT)
    pr=cp.Problem(cp.Minimize(obj),cons); pr.solve(solver=cp.CLARABEL); return pr.value
print("reduced dual torus d=5 2->3:",torus_coh_reduced(5,2,1),"  exact (205+16sqrt39)/625 =",(205+16*math.sqrt(39))/625)
print("reduced dual torus d=7 2->3:",torus_coh_reduced(7,2,1),"  claimed (667+36sqrt38)/2401 =",(667+36*math.sqrt(38))/2401)
