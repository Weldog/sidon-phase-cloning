import os
#!/usr/bin/env python3
"""Independent exact verifier of r40/logs/t1_exact_dual.json.

Only the JSON artifact is read. No imports of producer code, checkers, or helpers.
Runs all 255 difference-charge and 126 sum-charge blocks, no symmetry reduction.
Arithmetic: Q(sqrt(2))[L] / cubic. Signs: certified rational intervals.
"""
import ast
import itertools
import json
import math
import sys
from collections import defaultdict
from fractions import Fraction as Q

# default path made relative by Claude (logic unchanged)
cert_path = (sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','R0_d5_2to3','t1_exact_dual.json'))
C = json.load(open(cert_path, encoding='utf8'))
assert (C['d'], C['T'], C['k']) == (5, 2, 1)
D, T, K = 5, 2, 1

# Quadratic field coefficients represented as ordered rational pairs.
def aplus(a,b):return (a[0]+b[0],a[1]+b[1])
def aneg(a):return (-a[0],-a[1])
def aminus(a,b):return aplus(a,aneg(b))
def atimes(a,b):return (a[0]*b[0]+2*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def adiv(a,b):
    den=b[0]*b[0]-2*b[1]*b[1]
    if not den:raise ZeroDivisionError('quadratic field denominator zero')
    return atimes(a,(b[0]/den,-b[1]/den))
A0=(Q(0),Q(0)); A1=(Q(1),Q(0))
g=[tuple(Q(t) for t in c) for c in C['g_cubic_over_Qsqrt2_low_to_high']]

# Degree < 3 polynomials in algebraic L, coefficients Q(sqrt2).
def const(x=0,rt2=0):return ((Q(x),Q(rt2)),A0,A0)
ONE=const(1); ZERO=const(0); L=(A0,A1,A0)
def plus(a,b):return tuple(aplus(x,y) for x,y in zip(a,b))
def minus(a,b):return tuple(aminus(x,y) for x,y in zip(a,b))
def mul(a,b):
    c=[A0 for _ in range(5)]
    for i in range(3):
        for j in range(3):c[i+j]=aplus(c[i+j],atimes(a[i],b[j]))
    for n in (4,3):
        leading=c[n]
        for j in range(3):c[n-3+j]=aminus(c[n-3+j],atimes(leading,g[j]))
    return tuple(c[:3])
def div(a,b):return mul(a, inverse(b))
def zero(a):return all(u==0 and v==0 for u,v in a)
def inverse(x):
    if zero(x):raise ZeroDivisionError('zero K element')
    basis=[ONE,L,mul(L,L)]
    rows=[]
    cols=[mul(x,v) for v in basis]
    for i in range(3):rows.append([cols[j][i] for j in range(3)]+[A1 if i==0 else A0])
    for i in range(3):
        piv=next((j for j in range(i,3) if rows[j][i]!=A0),None)
        if piv is None:raise ZeroDivisionError('singular inverse')
        rows[piv],rows[i]=rows[i],rows[piv]
        v=rows[i][i]
        rows[i]=[adiv(y,v) for y in rows[i]]
        for j in range(3):
            if j==i:continue
            v=rows[j][i]
            if v!=A0:rows[j]=[aminus(t,atimes(v,s)) for t,s in zip(rows[j],rows[i])]
    return tuple(row[-1] for row in rows)
def parse(x):return tuple((Q(p),Q(q)) for p,q in x)

# Independent real algebraic embedding verification: rational sqrt2 interval,
# signed sextic at interval endpoints, root of the cubic and not conjugate.
scale=10**46
floor2=math.isqrt(2*scale*scale)
sqrt2=(Q(floor2,scale),Q(floor2+1,scale))
assert sqrt2[0]**2<2<sqrt2[1]**2
ll=Q(C['lambda_lo']); hh=Q(C['lambda_hi']);assert ll<hh
sextic=[Q(x) for x in C['sextic_high_to_low']]
def evalpol(coeffs, x):
    acc=Q(0)
    for c in coeffs:acc=acc*x+c
    return acc
assert evalpol(sextic,ll)*evalpol(sextic,hh)<0
s0=1 if evalpol(sextic,ll)>0 else -1

def interval_product(x,y):
    p=[a*b for a in x for b in y]
    return min(p),max(p)
def interval_add(x,y):return x[0]+y[0],x[1]+y[1]
def inc(x):return x,x
def interval_embed(x):
    power=inc(Q(1)); ans=inc(Q(0))
    for p,q in x:
        scalar=interval_add(inc(p),interval_product(inc(q),sqrt2))
        ans=interval_add(ans,interval_product(scalar,power))
        power=interval_product(power,(ll,hh))
    return ans
def refine():
    global ll,hh
    mid=(ll+hh)/2
    if evalpol(sextic,mid)*s0>0:ll=mid
    else:hh=mid
def algsign(x):
    if zero(x):return 0
    for attempt in range(500):
        v=interval_embed(x)
        if v[0]>0:return 1
        if v[1]<0:return -1
        refine()
    raise ArithmeticError('failed to rigorously determine algebraic sign')

# Conjugate polynomial (replace sqrt2 by -sqrt2) has no root in isolating interval.
for _ in range(25):refine()
Gc=[(a,-b) for a,b in g]
poly_conj=plus(plus(mul(mul(L,L),L), mul(const(*Gc[2]),mul(L,L))),plus(mul(const(*Gc[1]),L),const(*Gc[0])))
# evaluate conjugate cubic using plain interval arithmetic
cv=inc(Q(1)); conjugate_v=inc(Q(0))
for c in Gc:
    conjugate_v=interval_add(conjugate_v,interval_product(interval_add(inc(c[0]),interval_product(inc(c[1]),sqrt2)),cv))
    cv=interval_product(cv,(ll,hh))
conjugate_v=interval_add(conjugate_v,cv)
assert conjugate_v[0]>0 or conjugate_v[1]<0
# g divides integer sextic exactly in the constructed quotient.
res=ZERO
for c in sextic:res=plus(mul(res,L),const(c))
assert zero(res)
# Verify the factorisation of the provided integer sextic DIRECTLY,
# rather than assuming that g and its conjugate account for the sextic.
# The two monic cubic coefficient lists multiply to the monic sextic.
full_g = g + [A1]
full_gc = Gc + [A1]
norm = [A0 for _ in range(7)]
for i,a in enumerate(full_g):
    for j,b in enumerate(full_gc):
        norm[i+j]=aplus(norm[i+j],atimes(a,b))
lead=sextic[0]
assert all(val==(c/lead,Q(0)) for val,c in zip(norm,reversed(sextic)))
# Cubic g has one root in bracket: check its derivative has a strict sign on tiny interval;
# its product with conjugate cubic equals sextic up to a nonzero scalar.
g_derivative=plus(mul(const(3),mul(L,L)),plus(mul(const(*g[2]),mul(const(2),L)),const(*g[1])))
deriv_bounds=interval_embed(g_derivative)
assert deriv_bounds[0]>0 or deriv_bounds[1]<0, 'cubic derivative not fixed-sign throughout isolator'
def interval_cubic_at(x):
    ans=(x**3,x**3)
    for j,c in enumerate(g):
        coef=interval_add(inc(c[0]),interval_product(inc(c[1]),sqrt2))
        ans=interval_add(ans,interval_product(coef,inc(x**j)))
    return ans
vleft,vright=interval_cubic_at(ll),interval_cubic_at(hh)
assert (vleft[1]<0 and vright[0]>0) or (vright[1]<0 and vleft[0]>0), 'cubic endpoints not certified opposite-sign'
print('PASS: exact sextic norm factorisation, unique cubic root, separated conjugate')

# Construct symmetry-UNREDUCED tensor occupation charge blocks.
def states(t):
    for combination in itertools.combinations_with_replacement(range(D),t):
        count=[0]*D
        for i in combination:count[i]+=1
        yield tuple(count)
def mm(v):return math.factorial(sum(v))//math.prod(math.factorial(i) for i in v)
def addvec(x,y):return tuple(a+b for a,b in zip(x,y))
def subvec(x,y):return tuple(a-b for a,b in zip(x,y))
def typ(v):return tuple(sorted(v,reverse=True))
def orbitkey(x,y):
    def representation(p,q):return tuple(sorted(zip(p[0],p[1],q[0],q[1])))
    return repr(min(representation(x,y),representation(y,x)))
base=list(states(T)); outs=list(states(T+K))
y={tuple(k):parse(v) for k,v in zip(C['ytypes'],C['y'])}
w={k:parse(v) for k,v in C['w'].items()}
chi={ast.literal_eval(k):parse(v) for k,v in C['chi_by_type'].items()}
assert len(base)==15 and len(outs)==35
assert len(y)==2 and len(w)==38 and len(chi)==3

# Prove matrix PSD without any exact algebraic divisions:
# (i) verify a specified NONZERO kernel vector v exactly over K,
# (ii) certify positive definiteness of M + v v^T with fully rigorous
# interval LDL. Then M is PSD and its kernel is span(v).
# All interval operations below round OUTWARDS to integer multiples of 10^-120.
PREC=120
S=10**PREC
def ceildiv(a,b): return -((-a)//b)
def intrat(x):
    return ((x.numerator*S)//x.denominator, ceildiv(x.numerator*S,x.denominator))
def isum(a,b):return (a[0]+b[0],a[1]+b[1])
def ineg(a):return (-a[1],-a[0])
def isub(a,b):return isum(a,ineg(b))
def imul(a,b):
    a0,a1=a;b0,b1=b
    products=(a0*b0,a0*b1,a1*b0,a1*b1)
    return min(products)//S,ceildiv(max(products),S)
def iinv(a):
    x,y=a
    assert x>0 or y<0, 'interval contains zero in division'
    return (S*S)//y,ceildiv(S*S,x)
def idiv(a,b):return imul(a,iinv(b))
def ieval_K(x):
    p=(S,S); result=(0,0)
    for a,b in x:
        coeff=isum(intrat(a),imul(intrat(b),ivsqrt2))
        result=isum(result,imul(coeff,p))
        p=imul(p,ivlambda)
    return result
# Isolate lambda and sqrt2 significantly sharper than interval calculation precision.
for _ in range(550):refine()
ivlambda=(intrat(ll)[0],intrat(hh)[1])
floor_s2=math.isqrt(2*(10**(PREC+15))**2)
ss=10**(PREC+15)
ivsqrt2=(intrat(Q(floor_s2,ss))[0],intrat(Q(floor_s2+1,ss))[1])

def exact_kernel(mat,v):
    if not any(not zero(t) for t in v): return False
    for row in mat:
        acc=ZERO
        for x,xi in zip(row,v):acc=plus(acc,mul(x,xi))
        if not zero(acc):return False
    return True
def matrix_positive_with_kernel(mat,v):
    n=len(mat)
    if any(mat[i][j]!=mat[j][i] for i in range(n) for j in range(i)): return False,'asymmetric'
    if not exact_kernel(mat,v):return False,'kernel is not exactly zero'
    vm=[ieval_K(t) for t in v]
    H=[[isum(ieval_K(mat[i][j]),imul(vm[i],vm[j])) for j in range(n)] for i in range(n)]
    # Interval LDL with exact integers representing multiples 10^-120.
    for pivot in range(n):
        v0=H[pivot][pivot]
        if v0[0]<=0: return False,'unable to certify strict pivot >0: '+str(pivot)
        for r in range(pivot+1,n):
            for c in range(r,n):
                correction=idiv(imul(H[r][pivot],H[c][pivot]),v0)
                H[c][r]=isub(H[c][r],correction)
                H[r][c]=H[c][r]
    return True,'PSD and rank exactly '+str(n-1)

def sqrtn(n):
    s=math.isqrt(n)
    if s*s==n:return const(s)
    s=math.isqrt(n//2)
    assert 2*s*s==n
    return const(0,s)
def nullvector(rows):
    return [mul(sqrtn(mm(a)),mul(const(mm(b)),chi[typ(b)])) for a,b in rows]

sig=defaultdict(list);tau=defaultdict(list)
for aa in base:
    for bb in outs:
        sig[subvec(bb,aa)].append((aa,bb))
        tau[addvec(aa,bb)].append((aa,bb))
assert len(sig)==255 and len(tau)==126
used_w=set()
passed=0
for t, rows in tau.items():
    matrix=[]
    for u in rows:
        vals=[]
        for v in rows:
            key=orbitkey(u,v);used_w.add(key);vals.append(w[key])
        matrix.append(vals)
    ok,msg=matrix_positive_with_kernel(matrix,nullvector(rows))
    if not ok:raise ValueError('W tau block '+str(t)+': '+msg)
    passed+=1
print('PASS: all',passed,'sum-charge W PSD blocks (without symmetry reduction)')
passed=0
scale_factor=const(Q(1,D**(2*T+K)))
for s, rows in sig.items():
    mat=[]
    for i,(ap,b) in enumerate(rows):
        vals=[]
        for j,(a,bp) in enumerate(rows):
            key=orbitkey((a,b),(ap,bp));used_w.add(key)
            term=mul(y[typ(ap)], const(Q(1,mm(b)))) if i==j else ZERO
            vals.append(minus(minus(term,scale_factor),w[key]))
        mat.append(vals)
    ok,msg=matrix_positive_with_kernel(mat,nullvector(rows))
    if not ok:raise ValueError('Z sigma block '+str(s)+': '+msg)
    passed+=1
print('PASS: all',passed,'difference-charge Z PSD blocks (without symmetry reduction)')
assert used_w==set(w), ('w labels unused',len(set(w)-used_w))

# Independent lower bound verification: PGM flat-covariant seed with exact positive eigenvector.
classbytotal=defaultdict(list)
for a in base:
    for b in outs:classbytotal[addvec(a,b)].append((a,b))
for b in outs:
    lhs=ZERO
    for a in base:
        for ap,bp in classbytotal[addvec(a,b)]:
            coef=mul(sqrtn(mm(a)*mm(ap)),const(Q(mm(bp),D**(2*T+K))))
            lhs=plus(lhs,mul(coef,chi[typ(bp)]))
    if not zero(minus(lhs,mul(L,chi[typ(b)]))):
        raise ValueError('failed eigenvector row '+str(b))
assert all(algsign(x)>0 for x in chi.values())
trace=ZERO
for a in base:trace=plus(trace,mul(const(mm(a)),y[typ(a)]))
assert zero(minus(trace,L))
print('PASS: Nprime*chi = lambda*chi on all 35 outputs, strictly positive chi')
print('PASS: dual objective sum(m_a*y_a) = lambda exactly')
print('CERTIFIED ZERO GAP, exactly: d=5,T=2,k=1 P_EB(torus)=flat-seed lambda')
print('lambda initial enclosure (from input):',C['lambda_lo'],C['lambda_hi'])
print('lambda rigorous narrowed enclosure:',float(ll),float(hh))
