from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import sys,json
r=Path(__file__).resolve().parent.parent/'hsep_plus_counterexamples'  # path made relative by Claude for the bundle; logic unchanged
sys.path.insert(0,str(r/'src'))
import coh_cert
p=r/'certs'
def J(s):return json.loads((p/s).read_text())
Q=10**24
s2=isqrt(2*Q*Q)
s3=isqrt((61*Q+36*s2)*Q)
L=F(1,4)+F(3*s2,32*Q)+F(s3,32*Q)
print('Certified exact rational lower Pflat >=',float(L))
assert L > F('0.7131710240737')
m=J('hsep_plus_manifest.json')
for e in m['entries']:
 if e['type']!='violation':continue
 vals=[coh_cert.check(J(e[x])) for x in ('coh_primal','torus_coh_dual','ppt_dual')]
 assert all(ok for ok,v in vals)
 (Lc,Uc,Up)=[v for ok,v in vals]
 mg=(Lc-Uc)-(Up-L)
 print(e['tag'],'positive via EXACT lower bound?',mg>0,'margin > 0.009?',mg>F(9,1000),'margin=',float(mg))
