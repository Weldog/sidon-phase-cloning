#!/usr/bin/env python3
"""Independent rational audit of the H-SEP torus d=5,T=2,k=1 PPT dual.

No dependency on code in r39/src; the positivity checks are exact rational.
Reconstructs tensor blocks from occupation combinatorics, explicitly rebuilds
W^Gamma, validates coverage, symmetries, and verifies every PSD inequality.
"""
from fractions import Fraction as Q
from itertools import combinations_with_replacement
from collections import defaultdict
from math import factorial, prod
import json, sys

file=sys.argv[1] if len(sys.argv)>1 else 'r39/logs/t1_cert.json'
C=json.load(open(file))
d,t,k=C['d'],C['T'],C['k']
assert (d,t,k)==(5,2,1), 'Unexpected task'
n=2*t+k

def occ(m):
    out=set()
    for inds in combinations_with_replacement(range(d),m):
        a=[0]*d
        for i in inds: a[i]+=1
        out.add(tuple(a))
    return sorted(out)

def parse(s):
    a=tuple(map(int,s.split(',')))
    assert len(a)==d and all(x>=0 for x in a)
    return a

def add(x,y): return tuple(a+b for a,b in zip(x,y))
def sub(x,y): return tuple(a-b for a,b in zip(x,y))
def mul(a): return factorial(sum(a))//prod(factorial(i) for i in a)

def check_pd(A):
    """Exact symmetric positive definiteness by fraction-free Schur complements.
    Fraction arithmetic throughout; diagonal pivots strictly positive."""
    N=len(A)
    assert all(len(row)==N for row in A)
    assert all(A[i][j]==A[j][i] for i in range(N) for j in range(i))
    M=[r[:] for r in A]
    for p in range(N):
        pivot=M[p][p]
        if pivot<=0:
            return False,p,pivot
        for i in range(p+1,N):
            for j in range(i,N):
                # lower-triangle-to-upper update (row and col symmetric).
                M[i][j] -= M[i][p]*M[j][p]/pivot
        for i in range(p+1,N):
            for j in range(i+1,N): M[j][i]=M[i][j]
    return True,None,None

A,B=occ(t),occ(t+k)
P=[(a,b) for a in A for b in B]
assert len(A)==15 and len(B)==35 and len(P)==525
Y={parse(s):Q(v) for s,v in C['y_tilde'].items()}
assert set(Y)==set(A), 'Missing/additional Y diagonal positions'
assert all(y>0 for y in Y.values())

# All 525 tensor-basis pairs must occur in exactly one tau=a+b block.
tau=defaultdict(list)
sigma=defaultdict(list)
for p in P:
    tau[add(*p)].append(p)
    sigma[sub(p[1],p[0])].append(p)
assert len(tau)==126 and len(sigma)==255
W={}
observed=set()
assert len(C['W_tilde_blocks'])==len(tau)
for ib,block in enumerate(C['W_tilde_blocks']):
    ix=[(parse(a),parse(b)) for a,b in block['pairs']]
    assert len(set(ix))==len(ix), f'Duplicate pair in block {ib}'
    assert all(p in P for p in ix), f'Invalid pair in block {ib}'
    ch={add(*p) for p in ix}
    assert len(ch)==1, f'Block {ib} crosses tau sectors'
    charge=next(iter(ch))
    assert charge not in observed, f'Duplicate tau block {charge}'
    observed.add(charge)
    assert set(ix)==set(tau[charge]), f'Incomplete tau block {charge}'
    M=[[Q(s) for s in row] for row in block['matrix']]
    assert len(M)==len(ix)
    ok,j,v=check_pd(M)
    assert ok, f'W block {charge} not positive definite, pivot={j}, val={v}'
    for i,p in enumerate(ix):
        for j,q in enumerate(ix): W[p,q]=M[i][j]
assert observed==set(tau), 'Omitted tau blocks'
assert len(W)==sum(len(p)**2 for p in tau.values())

# Partial transpose maps any W nonzero to the sigma=beta-alpha sector:
# W[(a,b),(a2,b2)] -> W^Gamma[(a2,b),(a,b2)].
# Its sigma labels agree because a+b=a2+b2.
assert all(sub(b,a2)==sub(b2,a) for (a,b),(a2,b2) in W)

for charge,positions in sigma.items():
    M=[]
    for a1,b1 in positions:
        row=[]
        for a2,b2 in positions:
            x=Y[a1]/mul(b1) if (a1,b1)==(a2,b2) else Q(0)
            # X tilde is a rank-one all-ones/d^n matrix on each sigma sector.
            x-=Q(1,d**n)
            x-=W.get(((a2,b1),(a1,b2)),Q(0))
            row.append(x)
        M.append(row)
    ok,j,v=check_pd(M)
    assert ok, f'Dual slack sigma={charge} failed pivot {j} value {v}'

U=sum(mul(a)*Y[a] for a in A)
assert U==Q(C['U']),f'False objective claim {U} != {C["U"]}'
threshold=Q('0.19980446370205')
print('INDEPENDENT AUDIT: PASS')
print('dimensions: |A|=%d |B|=%d N=%d'%(len(A),len(B),len(P)))
print('cover exactly: %d tau(W) blocks, %d sigma(Z) blocks'%(len(tau),len(sigma)))
print('all W and Z blocks: exact rational positive definite')
print('Gamma support: no off-sector terms; X reconstructed from integer charge equalities')
print('trace Y:', U)
print('upper bound decimal:', format(float(U),'.17g'))
print('claimed decimal ceiling holds:', U<=threshold)
print('difference ceiling minus U:',threshold-U)
