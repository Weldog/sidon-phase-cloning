#!/usr/bin/env python3
"""Independent all-rational H-SEP certificate for QH-N(p=5,r=3),2->3.
Uses finite integer combinatorics and a coarse certified EB strategy lower bound;
no producer code, SDP solver, numpy or floating point required.
"""
from collections import Counter, defaultdict
from itertools import combinations_with_replacement
from math import factorial,isqrt,prod
from fractions import Fraction as F

p=5;d=5;T=2;k=1;m=T+k;n=T+m

def comps(s):
    arr=[]
    for v in combinations_with_replacement(range(d),s):
        a=[0]*d
        for i in v:a[i]+=1
        arr.append(tuple(a))
    return arr

def mm(a): return factorial(sum(a))//prod(factorial(x) for x in a)
def key(a): return tuple(sum(a[j]*pow(j,s,5) for j in range(5))%5 for s in (1,2,3))
def sub(a,b): return tuple((x-y)%5 for x,y in zip(a,b))
def add(a,b): return tuple(x+y for x,y in zip(a,b))
A,B=comps(T),comps(m)
assert len(A)==15 and len(B)==35
assert len(set(map(key,A)))==15 and len(set(map(key,B)))==35

# Finite coherent reduced-dual constraints at the known torus-optimal ray:
# x_a = 1/sqrt(13) if a has one double occupation,
# x_a = 1/sqrt(12) if a has two single occupations.
# Each charge s has constraint sum_{a,b:key(b)-key(a)=s} mm(b)*x_a <= sqrt(13)+8sqrt(3).
rows=defaultdict(lambda:[0,0])
for a in A:
    typ=0 if max(a)==2 else 1
    for b in B:
        rows[sub(key(b),key(a))][typ]+=mm(b)
counts=Counter(map(tuple,rows.values()))
expected=Counter({(3,3):60,(6,19):30,(9,10):20,(2,6):10,(13,48):5})
assert len(rows)==125 and counts==expected
# 5 rows with (13,48) are tight: 13/sqrt(13)+48/sqrt(12)=sqrt(13)+8sqrt(3).
# Every other row has coefficients (c0,c1) with c0+c1 <=25,
# so its LHS < 25/3 < sqrt(13)+8sqrt(3).
assert all(c[0]+c[1] <=25 for c in counts if c!=(13,48))
print('EXACT coherent dual: 125/125 inequalities; 5 tight; 120 strictly slack')
print('Non-tight (coefficient pair: multiplicity):',dict(counts))
print('Torus objective exactly: (205 + 16*sqrt(39))/625')
print('Since this torus dual ray is also feasible for the finite group, coherent equality holds.')

# Genuine finite-group covariant POVM: key injective on 2-multisets,
# effects are orbit of |flat><flat|, and the output seed has the integer
# components v_b shown below, constant on the three occupation types.
# A normalized output v defines a valid measure-and-prepare (EB) channel.
# Its exact score is sum_charge( sum_{a,b,key(a+b)=charge} v_b*sqrt(mm(a)*mm(b)) )^2 / (d^n*sum_b v_b^2).
# Lower-bound all square roots from below by integer arithmetic.
SCALE=10**12
VTYPE={3:7245441,2:11435050,1:26687657}
sumG=defaultdict(int)
for b in B:
    for a in A:
        sqrt_lower=isqrt(mm(a)*mm(b)*SCALE*SCALE)
        sumG[key(add(a,b))]+=VTYPE[max(b)]*sqrt_lower
L=F(sum(v*v for v in sumG.values()),SCALE*SCALE*d**n*sum(VTYPE[max(b)]**2 for b in B))
U=F(125823662481760412531676609,629733991675930000000000000)
assert L>F(2156168,10000000)>U
print('Exact rational lower bound L:',str(L))
print('L decimal (informational only):',float(L))
print('Rigorous margin L - U > 0.2156168 - U =',F(2156168,10000000)-U)
print('EXACT CERTIFICATE RESULT: PASS')
