"""Own code (Grok Bot), r42 brief task 2: exact test harness for R0 at T = 1 (torus EB value = flat-seed value = PPT value).
STANDALONE CHECKER (python3 standard library only):  python3 t1r0_check.py cert.json [...]

Setting (r39/r40 notation, DERIVED there): torus, T = 1 -> 1 + k, n = 2 + k, a: 1-multisets (unit vectors e_i, m_a = 1), b: (1+k)-multisets
(occupation vectors), m_b = multinomial.  Flat-seed matrix N'[b,b'] = sum_{a,a': a+b = a'+b'} m_{b'} / d^n  (RATIONAL at T = 1).
S_d-symmetrised PPT dual (sym_ppt.py, r40): min sum_a m_a y_a s.t.  Z_sigma = diag(y_a / m_b) - 1/d^n - W^{T_A}_sigma >= 0 (sigma = b - a),
W_tau >= 0 (tau = a + b), y per S_d type of a, W entries per S_d-orbit label; one representative block per sorted sigma / tau.
Certificate over K = Q[x]/(p), p in Q[x] monic, lambda = the unique root of p in [lo, hi] (checked: sign change, and Sturm count = 1):
   (1) N' chi = lambda chi exactly, chi > 0 (every entry, rigorous sign)  =>  lambda = spectral radius of the nonnegative N' (Perron-Frobenius)
       = flat-seed value (r39: achieved by a measure-and-prepare strategy, so lambda <= P_EB(tor));
   (2) every representative Z and W block is PSD: M v = 0 exactly and M + v v^T positive definite (exact LDL in K, rigorous signs),
       v(a,b) = m_b chi_b (complementary slackness vector);
   (3) tr Y = sum_types m_A(type) y_type = lambda exactly.
   Then P_PPT(tor) <= lambda <= P_EB(tor) <= P_PPT(tor): ZERO GAP, i.e. R0 holds for this (d, 1, k)."""
import json, sys, itertools, math
from fractions import Fraction as F
sys.set_int_max_str_digits(0)

# ---------------- number field Q[x]/(p) ----------------
class NF:
    p = None   # monic, low -> high coefficients (Fractions), degree D
    def __init__(self, c):
        D = len(NF.p) - 1; c = list(c) + [F(0)] * (D - len(c)); self.c = c[:D]
    @staticmethod
    def const(q): return NF([F(q)])
    @staticmethod
    def X(): return NF([F(0), F(1)]) if len(NF.p) > 2 else NF([-NF.p[0]])
    @staticmethod
    def _red(a):
        p = NF.p; D = len(p) - 1; a = a[:]
        for e in range(len(a) - 1, D - 1, -1):
            t = a[e]
            if t:
                for i in range(D + 1): a[e - D + i] -= t * p[i]
        return a[:D] if len(a) >= D else a + [F(0)] * (D - len(a))
    def __add__(s, o): o = o if isinstance(o, NF) else NF.const(o); return NF([x + y for x, y in zip(s.c, o.c)])
    __radd__ = __add__
    def __neg__(s): return NF([-x for x in s.c])
    def __sub__(s, o): return s + (-(o if isinstance(o, NF) else NF.const(o)))
    def __rsub__(s, o): return (-s) + o
    def __mul__(s, o):
        if not isinstance(o, NF): o = F(o); return NF([x * o for x in s.c])
        r = [F(0)] * (2 * len(s.c) - 1)
        for i, x in enumerate(s.c):
            if x:
                for j, y in enumerate(o.c):
                    if y: r[i + j] += x * y
        return NF(NF._red(r))
    __rmul__ = __mul__
    def iszero(s): return all(x == 0 for x in s.c)
    def inv(s):   # extended Euclid in Q[x]: s*u + p*v = g; need g constant (true when p irreducible, or gcd(s,p) = 1)
        def trim(a):
            a = a[:]
            while a and a[-1] == 0: a.pop()
            return a
        def pdivmod(a, b):
            a = a[:]; q = [F(0)] * max(1, len(a) - len(b) + 1)
            while len(trim(a)) >= len(b):
                a = trim(a); f = a[-1] / b[-1]; sh = len(a) - len(b); q[sh] = f
                for i, y in enumerate(b): a[sh + i] -= f * y
            return q, trim(a)
        def pmul(a, b):
            if not a or not b: return []
            r = [F(0)] * (len(a) + len(b) - 1)
            for i, x in enumerate(a):
                for j, y in enumerate(b): r[i + j] += x * y
            return r
        def psub(a, b):
            n = max(len(a), len(b)); return trim([(a[i] if i < len(a) else 0) - (b[i] if i < len(b) else 0) for i in range(n)])
        r0, r1 = trim(list(NF.p)), trim(s.c); u0, u1 = [], [F(1)]
        if not r1: raise ZeroDivisionError
        while len(r1) > 1:
            q, r = pdivmod(r0, r1); r0, r1 = r1, r; u0, u1 = u1, psub(u0, pmul(q, u1))
            if not r1: raise ZeroDivisionError('not invertible (p reducible?)')
        c = r1[0]
        return NF([x / c for x in u1]) if len(u1) <= len(NF.p) - 1 else NF(NF._red([x / c for x in u1]))

class Embed:
    def __init__(self, lo, hi):
        self.lo, self.hi = F(lo), F(hi)
        assert (self.lo == self.hi and self.pv(self.lo) == 0) or self.pv(self.lo) * self.pv(self.hi) < 0, 'no root of p certified on [lo, hi]'
    def pv(self, x):
        v = F(0)
        for c in reversed(NF.p): v = v * x + c
        return v
    def refine(self):
        m = (self.lo + self.hi) / 2; vm = self.pv(m)
        if vm == 0: self.lo = self.hi = m
        elif (vm > 0) == (self.pv(self.lo) > 0): self.lo = m
        else: self.hi = m
    def interval(self, e):     # interval Horner, x in [lo, hi]
        lo, hi = F(0), F(0)
        for c in reversed(e.c):
            ps = [lo * self.lo, lo * self.hi, hi * self.lo, hi * self.hi]
            lo, hi = min(ps) + c, max(ps) + c
        return lo, hi
    def sign(self, e):
        if e.iszero(): return 0
        for _ in range(2000):
            a, b = self.interval(e)
            if a > 0: return 1
            if b < 0: return -1
            self.refine()
        raise RuntimeError('sign undecided')

def sturm_count(p, lo, hi):
    """number of distinct real roots of p in (lo, hi] (Sturm sequence, exact)."""
    def trim(a):
        a = a[:]
        while a and a[-1] == 0: a.pop()
        return a
    def prem(a, b):
        a = a[:]
        while len(trim(a)) >= len(b):
            a = trim(a); f = a[-1] / b[-1]; sh = len(a) - len(b)
            for i, y in enumerate(b): a[sh + i] -= f * y
        return trim(a)
    dp = [i * c for i, c in enumerate(p)][1:]
    seq = [trim(list(p)), trim(dp)]
    while len(seq[-1]) > 1:
        r = prem(seq[-2], seq[-1])
        if not r: break
        seq.append([-x for x in r])
    def ev(a, x):
        v = F(0)
        for c in reversed(a): v = v * x + c
        return v
    def var(x):
        s = [v for v in (ev(a, x) for a in seq) if v != 0]
        return sum(1 for i in range(len(s) - 1) if (s[i] > 0) != (s[i + 1] > 0))
    return var(lo) - var(hi)

def ldl_psd_with_kernel(M, v, E):
    m = len(M)
    for i in range(m):
        acc = NF.const(0)
        for j in range(m): acc = acc + M[i][j] * v[j]
        if not acc.iszero(): return False, 'M v != 0'
    A = [[M[i][j] + v[i] * v[j] for j in range(m)] for i in range(m)]
    for i in range(m):
        piv = A[i][i]
        if E.sign(piv) <= 0: return False, f'pivot {i} not positive'
        ip = piv.inv()
        for r in range(i + 1, m):
            if not A[r][i].iszero():
                f = A[r][i] * ip
                for c in range(i, m): A[r][c] = A[r][c] - f * A[i][c]
    return True, 'ok'

# ---------------- structure (verbatim logic of r40 sym_ppt.structure/build, no numpy) ----------------
def comps(n, d):
    if d == 1: return [(n,)]
    return [(i,) + c for i in range(n, -1, -1) for c in comps(n - i, d - 1)]
def mult(g): return math.factorial(sum(g)) // math.prod(math.factorial(x) for x in g)
def add(a, b): return tuple(x + y for x, y in zip(a, b))
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def canon_pair(p, q):
    def c(p, q): return tuple(sorted(zip(p[0], p[1], q[0], q[1])))
    return min(c(p, q), c(q, p))
def build(d, T, k):
    A, B = comps(T, d), comps(T + k, d)
    sig_rep, tau_rep = {}, {}
    for a in A:
        for b in B:
            s = sub(b, a); t = add(a, b)
            if s == tuple(sorted(s, reverse=True)): sig_rep.setdefault(s, []).append((a, b))
            if t == tuple(sorted(t, reverse=True)): tau_rep.setdefault(t, []).append((a, b))
    ytypes = sorted({tuple(sorted(a, reverse=True)) for a in A}, reverse=True)
    yidx = {t: i for i, t in enumerate(ytypes)}; wlab = {}
    def wv(p, q):
        lab = canon_pair(p, q)
        if lab not in wlab: wlab[lab] = len(wlab)
        return wlab[lab]
    Wblocks = {t: [[wv(p, q) for q in l] for p in l] for t, l in tau_rep.items()}
    Zblocks = {}
    for s, l in sig_rep.items():
        ent = [[(((yidx[tuple(sorted(a2, reverse=True))], mult(b)) if r_ == c_ else None), wv((a, b), (a2, b2))) for c_, (a, b2) in enumerate(l)]
               for r_, (a2, b) in enumerate(l)]
        Zblocks[s] = (l, ent)
    mA_type = [sum(mult(a) for a in A if tuple(sorted(a, reverse=True)) == t) for t in ytypes]
    return dict(A=A, B=B, ytypes=ytypes, mA_type=mA_type, nw=len(wlab), wlab=wlab, Wblocks=Wblocks, Zblocks=Zblocks, tau_rep=tau_rep,
                n=2 * T + k, d=d, T=T, k=k)

def Nprime_types(d, k):
    T = 1; n = 2 + k; dn = d ** n
    A, B = comps(T, d), comps(T + k, d)
    typB = sorted({tuple(sorted(b, reverse=True)) for b in B}); ti = {t: i for i, t in enumerate(typB)}
    rep = {t: next(b for b in B if tuple(sorted(b, reverse=True)) == t) for t in typB}
    byg = {}
    for a in A:
        for b in B: byg.setdefault(add(a, b), []).append((a, b))
    M = []
    for t in typB:
        row = [F(0)] * len(typB); b = rep[t]
        for a in A:
            for (a2, b2) in byg[add(a, b)]: row[ti[tuple(sorted(b2, reverse=True))]] += F(mult(b2), dn)
        M.append(row)
    return typB, ti, M

def check(cert):
    d, T, k = cert['d'], cert['T'], cert['k']; assert T == 1
    NF.p = [F(c) for c in cert['p_low_to_high']]; assert NF.p[-1] == 1
    lo, hi = F(cert['lambda_lo']), F(cert['lambda_hi']); E = Embed(lo, hi)
    assert lo == hi or sturm_count(NF.p, lo, hi) == 1, 'interval does not isolate one root'
    lam = NF.X(); rd = lambda e: NF([F(x) for x in e])
    typB, ti, Np = Nprime_types(d, k)
    chi_t = [rd(cert['chi_by_type'][repr(t)]) for t in typB]
    eig = all((sum((chi_t[j] * Np[i][j] for j in range(len(typB))), NF.const(0)) - lam * chi_t[i]).iszero() for i in range(len(typB)))
    pos = all(E.sign(c) > 0 for c in chi_t)
    S = build(d, T, k); ny = len(S['ytypes'])
    assert [list(t) for t in S['ytypes']] == cert['ytypes']
    yK = [rd(e) for e in cert['y']]; wK = [None] * S['nw']
    for lab, i in S['wlab'].items(): wK[i] = rd(cert['w'][repr(lab)])
    chi = {b: chi_t[ti[tuple(sorted(b, reverse=True))]] for b in S['B']}
    vec = lambda a, b: chi[b] * mult(b)
    dn = d ** S['n']; okall = True; msgs = []
    for s, (l, ent) in S['Zblocks'].items():
        Mz = [[(yK[e[0][0]] * F(1, e[0][1]) if e[0] is not None else NF.const(0)) - F(1, dn) - wK[e[1]] for e in row] for row in ent]
        ok, msg = ldl_psd_with_kernel(Mz, [vec(a2, b) for (a2, b) in l], E); okall &= ok; msgs.append(f'Z{s}:{msg}')
    for t, Mw in S['Wblocks'].items():
        l = S['tau_rep'][t]; Mk = [[wK[Mw[i][j]] for j in range(len(l))] for i in range(len(l))]
        ok, msg = ldl_psd_with_kernel(Mk, [vec(a, b) for (a, b) in l], E); okall &= ok; msgs.append(f'W{t}:{msg}')
    trY = sum((yK[i] * S['mA_type'][i] for i in range(ny)), NF.const(0))
    tr_ok = (trY - lam).iszero()
    return dict(eigvec=eig, chi_positive=pos, blocks_psd=okall, trY_eq_lambda=tr_ok, zero_gap=eig and pos and okall and tr_ok,
                lam_interval=(float(E.lo), float(E.hi)), degree=len(NF.p) - 1, nblocks=len(msgs), bad=[m for m in msgs if not m.endswith('ok')])

if __name__ == '__main__':
    allok = True
    for f in sys.argv[1:]:
        r = check(json.load(open(f))); allok &= r['zero_gap']; print(f, r)
    print('CHECK PASS' if allok else 'CHECK FAIL')
