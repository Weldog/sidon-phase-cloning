import itertools, math, numpy as np
from collections import defaultdict

def collisions_exact(p,r,ell):
    classes=defaultdict(list)
    for X in itertools.combinations_with_replacement(range(p), ell):
        key=tuple(sum(pow(int(x),j,p) for x in X)%p for j in range(1,r+1))
        classes[key].append(X)
    nontriv=[xs for xs in classes.values() if len(xs)>1]
    return len(classes), sum(len(x) for x in nontriv), nontriv[0][:2] if nontriv else None

def max_overlap(p,r,batch=20000):
    V=np.stack([np.array([pow(t,j,p) for t in range(p)],dtype=np.int16) for j in range(1,r+1)],axis=0)
    root=np.exp(2j*np.pi*np.arange(p)/p)
    total=p**r; best=0.; best_id=None
    for start in range(1,total,batch):
        ids=np.arange(start,min(total,start+batch),dtype=np.int64)
        cc=[];v=ids.copy()
        for _ in range(r):
            cc.append((v%p).astype(np.int16));v//=p
        vals=np.zeros((len(ids),p),dtype=np.int16)
        for j in range(r): vals=(vals+cc[j][:,None]*V[j])%p
        sums=np.abs(root[vals].sum(axis=1))/p
        arg=int(sums.argmax())
        if sums[arg]>best:best=float(sums[arg]); best_id=int(ids[arg])
    w=math.sqrt((p**r-p)/(p*(p**r-1)))
    return best,best_id,best/w,(r-1)/math.sqrt(p)

print('EXACT finite-field power-sum class checks:',flush=True)
for p,r,ell in [(5,3,3),(5,2,3),(7,3,3),(7,2,3),(7,4,4),(7,3,4),(11,5,5),(11,4,5)]:
    n,n_coll,ex=collisions_exact(p,r,ell)
    print(f'p={p} r={r} ell={ell} signatures={n} collided_multisets={n_coll} example={ex}',flush=True)
print('INDEPENDENT VECTORIZED COLLISIONS:',flush=True)
for p,r in [(11,3),(13,3),(17,3),(19,3),(23,3),(29,3),(31,3),(11,5),(13,5)]:
    ans=max_overlap(p,r)
    print(f'r={r},p={p}: max={ans[0]:.10f} polynomial_index={ans[1]} ratio_Welch={ans[2]:.5f} Weil={ans[3]:.5f}',flush=True)
