"""Own code (Grok Bot), r41.  Exact certified lower bound for P_EB(F; T -> T+k) of a finite phase family F (uniform prior),
d >= 2, F need NOT be a group orbit.  STANDALONE CHECKER (python3 standard library only):  python3 eb_cert.py cert.json [...]

Family: psi_x = d^{-1/2} (1, z_x1, ..., z_x(d-1)),  z_xj in Q(i), |z_xj| = 1 exactly (rational points of the circle).
Basis: unnormalised symmetric vectors f_a = sum_{s of type a} |s>, a a multiset (occupation vector) of size t; <f_a|f_b> = mult(a) delta_ab.
Strategy (measure-and-prepare = entanglement-breaking):
   outcome i: effect E_i = |v_i><v_i| / c,   v_i = sum_a y_ia f_a (y in Q(i)),   preparation sigma_i = |w_i><w_i| / <w_i|w_i>,  w_i = sum_a yh_ia f_a;
   plus one completing effect E_0 = P_sym - sum_i E_i (prepare anything; its contribution >= 0 is dropped).
   Validity: E_0 >= 0 on Sym^T  <=>  M := c G - sum_i (G y_i)(G y_i)^H  is PSD,  G = diag(mult(a))   [checked exactly: LDL^T of the
   real-symmetric embedding [[Re M, -Im M], [Im M, Re M]], all pivots > 0].
Value (exact rational):  L = (1/(n c)) sum_x sum_i |<v_i|psi_x^T>|^2 |<psi_x^m|w_i>|^2 / <w_i|w_i>,
   <v_i|psi_x^T> = d^{-T/2} sum_a mult(a) conj(y_ia) z_x^a,   <psi_x^m|w_i> = d^{-m/2} sum_a mult(a) conj(z_x^a) yh_ia,   z_x^a = prod_j z_xj^{a_j}.
Then P_EB(F) >= L.  The checker also re-reads the torus certificate U (rational PPT dual, own r40, checked by sym_check.py) and reports
L - U (> 0 certifies Delta_EB = P_EB(F) - P_EB(torus) > 0)."""
import json, sys, itertools, math
sys.set_int_max_str_digits(0)
from fractions import Fraction as Fr

def occ(t, d): return [a for a in itertools.product(range(t + 1), repeat=d) if sum(a) == t]
def mult(a): return math.factorial(sum(a)) // math.prod(math.factorial(x) for x in a)
def cm(x, y): return (x[0]*y[0] - x[1]*y[1], x[0]*y[1] + x[1]*y[0])
def cconj(x): return (x[0], -x[1])
def cadd(x, y): return (x[0] + y[0], x[1] + y[1])
def cabs2(x): return x[0]*x[0] + x[1]*x[1]
def cpow(z, e):
    r = (Fr(1), Fr(0))
    for _ in range(e): r = cm(r, z)
    return r
def parse_c(s): return (Fr(s[0]), Fr(s[1]))

def ldl_pd(A):
    n = len(A); M = [row[:] for row in A]
    for p in range(n):
        if M[p][p] <= 0: return False
        for i in range(p + 1, n):
            f = M[i][p] / M[p][p]
            if f:
                for j in range(p + 1, n): M[i][j] -= f * M[p][j]
    return True

def check(cert):
    d, T, k = cert['d'], cert['T'], cert['k']; m = T + k
    Z = [[parse_c(z) for z in row] for row in cert['z']]          # n x (d-1)
    assert all(cabs2(z) == 1 for row in Z for z in row), 'a family entry is not on the unit circle'
    n = len(Z); AT, AM = occ(T, d), occ(m, d)
    Y = [[parse_c(v) for v in vi] for vi in cert['y']]; YH = [[parse_c(v) for v in wi] for wi in cert['yh']]
    assert len(Y) == len(YH) and all(len(v) == len(AT) for v in Y) and all(len(w) == len(AM) for w in YH)
    c = Fr(cert['c']); assert c > 0
    # validity: M = c G - sum_i (G y_i)(G y_i)^H PSD (PD checked)
    D = len(AT); G = [mult(a) for a in AT]
    MR = [[c * G[a] if a == b else Fr(0) for b in range(D)] for a in range(D)]; MI = [[Fr(0)] * D for _ in range(D)]
    for vi in Y:
        g = [(G[a] * vi[a][0], G[a] * vi[a][1]) for a in range(D)]
        for a in range(D):
            for b in range(D):
                t = cm(g[a], cconj(g[b])); MR[a][b] -= t[0]; MI[a][b] -= t[1]
    emb = [[MR[a][b] for b in range(D)] + [-MI[a][b] for b in range(D)] for a in range(D)] + \
          [[MI[a][b] for b in range(D)] + [MR[a][b] for b in range(D)] for a in range(D)]
    valid = ldl_pd(emb)
    # value
    def zpow(zrow, a):
        r = cpow((Fr(1), Fr(0)), 0)
        for j in range(1, d): r = cm(r, cpow(zrow[j - 1], a[j]))
        return r
    ZT = [[zpow(zr, a) for a in AT] for zr in Z]; ZM = [[zpow(zr, a) for a in AM] for zr in Z]
    MT = [mult(a) for a in AT]; MM = [mult(a) for a in AM]
    tot = Fr(0)
    for vi, wi in zip(Y, YH):
        nw = sum(MM[b] * cabs2(wi[b]) for b in range(len(AM)))
        if nw == 0: continue
        for x in range(n):
            s1 = (Fr(0), Fr(0)); s2 = (Fr(0), Fr(0))
            for a in range(D):
                t = cm(cconj(vi[a]), ZT[x][a]); s1 = cadd(s1, (MT[a] * t[0], MT[a] * t[1]))
            for b in range(len(AM)):
                t = cm(cconj(ZM[x][b]), wi[b]); s2 = cadd(s2, (MM[b] * t[0], MM[b] * t[1]))
            tot += cabs2(s1) * cabs2(s2) / nw
    L = tot / (n * c * Fr(d) ** (T + m))
    U = Fr(json.load(open(cert['torus_cert']))['U'])
    return valid, L, U

if __name__ == '__main__':
    allok = True
    for f in sys.argv[1:]:
        cert = json.load(open(f)); valid, L, U = check(cert)
        claimed = Fr(cert['L'])
        ok = valid and L == claimed
        allok &= ok
        print(f"{f}: POVM valid (exact PD) {valid}; L = {float(L):.15f} (matches file: {L == claimed}); torus U = {float(U):.15f}; "
              f"L - U = {float(L - U):.3e} -> {'Delta_EB > 0 CERTIFIED' if valid and L > U else 'not certified'}")
    print('CHECK PASS' if allok else 'CHECK FAIL')
