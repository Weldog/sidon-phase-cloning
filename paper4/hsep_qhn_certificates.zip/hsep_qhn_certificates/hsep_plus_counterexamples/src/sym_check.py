#!/usr/bin/env python3
"""STANDALONE checker (standard library only) for S_d-symmetric rational PPT-dual certificates of the TORUS relay
(entanglement-breaking) cloning value, any (d, T, k): logs/symcert_d{d}_T{T}_k{k}.json.
Claim: P_EB(torus; d, T -> T+k) <= U = sum_a m_a y_a (exact rational), by weak duality for the PPT relaxation:
  Z~_sigma = diag(y_a / m_b) - J / d^n - (W~^{T_A})_sigma  > 0 for every sigma = b - a,   W~_tau > 0 for every tau = a + b,
with y_a depending on the sorted type of a and W~[(a,b),(a',b')] on the S_d-orbit label of the column multiset
{(a_c, b_c, a'_c, b'_c)} (symmetrised in the two pairs). Positive definiteness by exact Fraction LDL. By default only one
representative (sorted) block per S_d-orbit is checked (the others are permutation-congruent); --full checks every block."""
import json, sys, itertools, math
from fractions import Fraction as F
args = [x for x in sys.argv[1:] if not x.startswith('--')]; FULL = '--full' in sys.argv
J = json.load(open(args[0])); d, T, k = J['d'], J['T'], J['k']; n = 2*T + k; dn = d**n
def comps(m):
    out = []
    for c in itertools.combinations_with_replacement(range(d), m):
        v = [0]*d
        for x in c: v[x] += 1
        out.append(tuple(v))
    return out
def mult(g): return math.factorial(sum(g)) // math.prod(math.factorial(x) for x in g)
def srt(v): return tuple(sorted(v, reverse=True))
def lab(p, q):
    def c(p, q): return tuple(sorted(zip(p[0], p[1], q[0], q[1])))
    return repr(min(c(p, q), c(q, p)))
y = {tuple(t): F(v) for t, v in zip(J['ytypes'], J['y'])}; w = {kk: F(v) for kk, v in J['w'].items()}
def pd(M):
    M = [r[:] for r in M]; m = len(M)
    for i in range(m):
        if M[i][i] <= 0: return False
        for r in range(i+1, m):
            if M[r][i] != 0:
                f = M[r][i] / M[i][i]
                for c in range(i, m): M[r][c] -= f * M[i][c]
    return True
A, B = comps(T), comps(T+k)
sig, tau = {}, {}
for a in A:
    for b in B:
        s = tuple(x - z for x, z in zip(b, a)); t = tuple(x + z for x, z in zip(a, b))
        if FULL or s == srt(s): sig.setdefault(s, []).append((a, b))
        if FULL or t == srt(t): tau.setdefault(t, []).append((a, b))
okW = all(pd([[w[lab(p, q)] for q in l] for p in l]) for l in tau.values())
okZ = all(pd([[(y[srt(a2)] / mult(b) if r == c else 0) - F(1, dn) - w[lab((a, b), (a2, b2))] for c, (a, b2) in enumerate(l)]
                for r, (a2, b) in enumerate(l)]) for l in sig.values())
U = sum(mult(a) * y[srt(a)] for a in A)
print(f"d={d} T={T} k={k}: {len(tau)} {'(all)' if FULL else 'representative'} W~ blocks PD: {okW}; {len(sig)} {'(all)' if FULL else 'representative'} Z~ blocks PD: {okZ}")
print(f"U = tr Y = {U} ~ {float(U):.15f}; matches the file's U: {U == F(J['U'])}")
print("CHECK", "PASS" if okW and okZ and U == F(J['U']) else "FAIL")
