"""Common definitions for r39 (own code, written for this round; reuses the definitions of my r38 qhn_eb.py, re-verified).
Occupation bases: comps(n, d) = all alpha in Z_{>=0}^d with |alpha| = n (= n-multisets of [d]); mult(alpha) = n!/prod alpha_i!.
A family is given by a LINEAR key (homomorphism Z^d -> abelian group): psi_x has amplitude d^{-1/2} chi_x(t), and the
order-n moment entries are nonzero iff key(alpha) = key(alpha') (r38 task 1 criterion; AAGW 2608.00265 Lemma 2.9).
  torus:            key(alpha) = alpha (identity)
  QH-N(p, r):       key(alpha) = (sum_t alpha_t t^m mod p)_{m=1..r}          (points t in F_p, d = p)
  Paper-1 set K<Z_q: key(alpha) = sum_j alpha_j k_j mod q                      (Paper 1 §2, psi_x = d^{-1/2} sum_j w_q^{x k_j}|j>)"""
import itertools, math
def comps(n, d):
    out = []
    for c in itertools.combinations_with_replacement(range(d), n):
        v = [0]*d
        for x in c: v[x] += 1
        out.append(tuple(v))
    return out
def mult(g): return math.factorial(sum(g)) // math.prod(math.factorial(x) for x in g)
def add(a, b): return tuple(x+y for x, y in zip(a, b))
def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def key_torus(v): return tuple(v)
def key_qhn(p, r):
    return lambda v: tuple(sum(c * pow(t, m, p) for t, c in enumerate(v)) % p for m in range(1, r+1))
def key_set(K, q):
    return lambda v: (sum(c * k for c, k in zip(v, K)) % q,)
