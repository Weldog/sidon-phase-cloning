"""Own code (Grok Bot), r42.  STANDALONE re-check (python3 standard library only) of every H-SEP+ verdict in a manifest:
   python3 hsep_plus_check.py ../certs/hsep_plus_manifest.json
All paths in the manifest are RELATIVE to the manifest's directory (task 3: no absolute paths).  Per entry:
   'support' (H-SEP+ certified):   [L_EB(F) - U_EB(tor)] - [U_coh(F) - L_coh(tor)] >= 0
       L_EB(F): eb_cert.check(eb)  (exact strategy value, POVM validity exact);   U_EB(tor): torus PPT dual U (r40 symcert, its 'U' field);
       U_coh(F): coh_cert dual;   L_coh(tor): coh_cert primal (torus).
   'violation' (H-SEP+ violated):  [L_coh(F) - U_coh(tor)] - [U_PPT(F) - L_EB(tor)] > 0
       L_coh(F): coh_cert primal;  U_coh(tor): coh_cert dual (torus);  U_PPT(F): coh_cert ppt_dual;
       L_EB(tor): the r40 symcert field seed_L_interval_rayleigh (interval-certified flat-seed Rayleigh quotient; the flat seed is an EB strategy, r39).
NOTE: the torus symcerts' own validity (U is a feasible rational PPT dual) is checked by sym_check.py (r40, bundled); seed_L is a float
recorded by r40's interval computation and is taken as given here (stated, not re-derived)."""
import json, sys, os
from fractions import Fraction as Fr
sys.set_int_max_str_digits(0)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eb_cert, coh_cert
man = sys.argv[1]; base = os.path.dirname(os.path.abspath(man)); M = json.load(open(man))
P = lambda p: os.path.join(base, p); J = lambda p: json.load(open(P(p)))
cache = {}
def coh(p):
    if p not in cache:
        ok, v = coh_cert.check(J(p)); cache[p] = (ok, v)
    return cache[p]
allok = True; ns = nv = 0
for e in M['entries']:
    if e['type'] == 'support':
        c = J(e['eb']); ok1, L, U = eb_cert.check(c, os.path.dirname(P(e['eb'])))
        ok1 = ok1 and L == Fr(c['L'])
        ok2, UcF = coh(e['coh_dual']); ok3, Lct = coh(e['torus_coh_primal'])
        mg = (L - U) - (UcF - Lct); good = ok1 and ok2 and ok3 and mg >= 0
        ns += good
        print(f"{e['tag']}: support  valid={ok1 and ok2 and ok3}  dEB>={float(L-U):.6e}  dcoh<={float(UcF-Lct):.6e}  margin={float(mg):.3e}  -> {'H-SEP+ CERTIFIED' if good else 'FAIL'}")
    else:
        ok1, LcF = coh(e['coh_primal']); ok2, Uct = coh(e['torus_coh_dual']); ok3, Uppt = coh(e['ppt_dual'])
        seedL = Fr(J(e['torus_symcert'])['seed_L_interval_rayleigh'])
        mg = (LcF - Uct) - (Uppt - seedL); good = ok1 and ok2 and ok3 and mg > 0
        nv += good
        print(f"{e['tag']}: violation valid={ok1 and ok2 and ok3}  dcoh>={float(LcF-Uct):.6e}  dEB<={float(Uppt-seedL):.6e}  margin={float(mg):.3e}  -> {'H-SEP+ VIOLATION CERTIFIED' if good else 'FAIL'}")
    allok &= good
print(f"supports certified: {ns}; violations certified: {nv}; entries: {len(M['entries'])}")
print('CHECK PASS' if allok else 'CHECK FAIL')
