"""Own code (Grok Bot), r42.  STANDALONE exact checker (python3 standard library only) for COHERENT-value bounds of the
(T -> T+k) phase-cloning task.  Usage:  python3 coh_cert.py cert.json [...]

Family: either a finite family F given by rational unit-circle points z (n x (d-1)), psi_x = d^{-1/2}(1, z_x1, ..., z_x(d-1)),
uniform prior; or the TORUS (Haar-uniform phases).  m = T + k.  Symmetric subspace, Dicke basis |a> (a an occupation vector).
Coherent value  P_coh = max { tr(O J) : J >= 0 on Sym^T (x) Sym^m,  tr_out J = I }   (Choi form; same program as r41 coh_ppt),
   O = avg_x |u_x><u_x|,  u_x = conj(psi_x^{(x)T}) (x) psi_x^{(x)m}.
Rescaling by D = diag(sqrt(mult a) sqrt(mult b)):  O = D Ot D,  Ot[(a,b),(a',b')] = d^{-(T+m)} avg_x conj(z^a) z^b z^{a'} conj(z^{b'})   (exact rational;
   for the torus the Haar average gives d^{-(T+m)} [a + b' = a' + b]).
 * kind 'dual' (UPPER bound):  Yt rational Hermitian (D_T x D_T).  Y = D_T Yt D_T is dual-feasible iff
       M := Yt (x) diag(1/mult b) - Ot  >= 0.   Then P_coh <= tr Y = sum_a mult(a) Yt[a][a] =: U.
   PSD proof: R = Rint / 2^K (complex, any matrix) is supplied; the checker forms E = M - R^H R exactly and verifies that E is
   diagonally dominant with |E_ij| <= |Re E_ij| + |Im E_ij|  (Gershgorin => E >= 0; R^H R >= 0 => M >= 0).
 * kind 'ppt_dual' (UPPER bound on the PPT relaxation, hence on P_EB, since EB channels have separable, hence PPT, Choi operators):
   as 'dual' plus rational vectors qt_i, Qt = sum_i qt_i qt_i^H >= 0 (by construction), and
       M := Yt (x) diag(1/mult b) - Ot - Qt^{T_A} >= 0,  Qt^{T_A}[(a,b),(a',b')] = Qt[(a',b),(a,b')].
   (Dual of max tr(OJ) s.t. J >= 0, J^{T_A} >= 0, tr_out J = I is: Y (x) I - O = P + Q^{T_A}, P, Q >= 0; the diagonal congruence D
   commutes with T_A because D[(a',b)] D[(a,b')] = D[(a,b)] D[(a',b')].)  Then P_EB <= P_PPT <= U = sum_a mult(a) Yt[a][a].
 * kind 'primal' (LOWER bound):  rational vectors vt_i;  Jt = sum_i vt_i vt_i^H (PSD by construction), J = D^{-1} Jt D^{-1}.
   Feasibility up to completion: K := diag(mult a) - sum_b Jt[(.,b),(.,b)] / mult(b) >= 0  (exact LDL of the real embedding,
   pivots >= 0 handled by requiring > 0) <=> tr_out J <= I; any such J completes to a channel J + (I - tr_out J)^T (x) sigma, which
   cannot decrease tr(O J) because O >= 0.  L = tr(Ot Jt) = sum_i vt_i^H Ot vt_i.  Then P_coh >= L."""
import json, sys, itertools, math, os
sys.set_int_max_str_digits(0)
from fractions import Fraction as Fr

def occ(t, d): return [a for a in itertools.product(range(t + 1), repeat=d) if sum(a) == t]
def mult(a): return math.factorial(sum(a)) // math.prod(math.factorial(x) for x in a)
def cm(x, y): return (x[0]*y[0] - x[1]*y[1], x[0]*y[1] + x[1]*y[0])
def cconj(x): return (x[0], -x[1])
def pc(s): return (Fr(s[0]), Fr(s[1]))
def cpow(z, e):
    r = (Fr(1), Fr(0))
    for _ in range(e): r = cm(r, z)
    return r

def ldl_pd(A):
    n = len(A); M = [row[:] for row in A]
    for p in range(n):
        if M[p][p] <= 0: return False
        for i in range(p + 1, n):
            f = M[i][p] / M[p][p]
            if f:
                for j in range(p + 1, n): M[i][j] -= f * M[p][j]
    return True

def index(cert):
    d, T, k = cert['d'], cert['T'], cert['k']; m = T + k
    AT, AM = occ(T, d), occ(m, d)
    return d, T, m, AT, AM, [(a, b) for a in AT for b in AM]

def otilde(cert):
    """Ot as a function returning the exact complex entry; vectors u_x for families."""
    d, T, m, AT, AM, IX = index(cert); s = Fr(1, d ** (T + m))
    if cert.get('torus'):
        def ent(i, j):
            (a, b), (a2, b2) = IX[i], IX[j]
            return (s, Fr(0)) if tuple(x + y for x, y in zip(a, b2)) == tuple(x + y for x, y in zip(a2, b)) else (Fr(0), Fr(0))
        return ent, None
    Z = [[pc(z) for z in row] for row in cert['z']]
    assert all(z[0]*z[0] + z[1]*z[1] == 1 for row in Z for z in row), 'family entry not on the unit circle'
    def zp(zr, a):
        r = (Fr(1), Fr(0))
        for j in range(1, d): r = cm(r, cpow(zr[j - 1], a[j]))
        return r
    U = []
    for zr in Z:
        PT = {a: zp(zr, a) for a in AT}; PM = {b: zp(zr, b) for b in AM}
        U.append([cm(cconj(PT[a]), PM[b]) for a, b in IX])
    n = len(Z)
    def ent(i, j):
        re = Fr(0); im = Fr(0)
        for u in U:
            t = cm(u[i], cconj(u[j])); re += t[0]; im += t[1]
        return (re * s / n, im * s / n)
    return ent, U

def check_dual(cert):
    d, T, m, AT, AM, IX = index(cert); N = len(IX)
    Yt = [[pc(v) for v in row] for row in cert['Yt']]
    pos = {a: i for i, a in enumerate(AT)}
    for i in range(len(AT)):                               # Hermitian
        for j in range(len(AT)): assert Yt[i][j] == cconj(Yt[j][i]), 'Yt not Hermitian'
    ent, _ = otilde(cert)
    QT = [[pc(v) for v in qv] for qv in cert['qt']] if cert['kind'] == 'ppt_dual' else None
    IXp = {ab: i for i, ab in enumerate(IX)}
    K = int(cert['K']); den = Fr(1, 2 ** (2 * K))
    R = [[(int(x[0]), int(x[1])) for x in row] for row in cert['Rint']]   # N x N complex integers
    ok = True
    E = [[None] * N for _ in range(N)]
    for i in range(N):
        for j in range(i, N):
            (a, b), (a2, b2) = IX[i], IX[j]
            o = ent(i, j)
            if QT is not None:
                ia, jb = IXp[(a2, b)], IXp[(a, b2)]
                for qv in QT:
                    t = cm(qv[ia], cconj(qv[jb])); o = (o[0] + t[0], o[1] + t[1])
            y = Yt[pos[a]][pos[a2]] if b == b2 else (Fr(0), Fr(0))
            mb = mult(b)
            re = y[0] / mb - o[0]; im = y[1] / mb - o[1]
            sr = 0; si = 0                                     # (R^H R)_ij = sum_l conj(R_li) R_lj
            for l in range(N):
                x, w = R[l][i], R[l][j]
                sr += x[0]*w[0] + x[1]*w[1]; si += x[0]*w[1] - x[1]*w[0]
            E[i][j] = (re - sr * den, im - si * den); E[j][i] = cconj(E[i][j])
    for i in range(N):
        if E[i][i][1] != 0: ok = False
        off = sum(abs(E[i][j][0]) + abs(E[i][j][1]) for j in range(N) if j != i)
        if E[i][i][0] < off: ok = False
    U = sum(mult(a) * Yt[pos[a]][pos[a]][0] for a in AT)
    return ok, U

def check_primal(cert):
    d, T, m, AT, AM, IX = index(cert); N = len(IX)
    V = [[pc(v) for v in vi] for vi in cert['vt']]
    ent, U = otilde(cert)
    DT = len(AT); pos = {a: i for i, a in enumerate(AT)}
    KR = [[Fr(mult(AT[i])) if i == j else Fr(0) for j in range(DT)] for i in range(DT)]; KI = [[Fr(0)] * DT for _ in range(DT)]
    for v in V:
        for i, (a, b) in enumerate(IX):
            for j, (a2, b2) in enumerate(IX):
                if b == b2:
                    t = cm(v[i], cconj(v[j])); mb = mult(b)
                    KR[pos[a]][pos[a2]] -= t[0] / mb; KI[pos[a]][pos[a2]] -= t[1] / mb
    emb = [[KR[a][b] for b in range(DT)] + [-KI[a][b] for b in range(DT)] for a in range(DT)] + \
          [[KI[a][b] for b in range(DT)] + [KR[a][b] for b in range(DT)] for a in range(DT)]
    ok = ldl_pd(emb)
    s = Fr(1, d ** (T + m)); L = Fr(0)
    if U is not None:
        for v in V:
            for u in U:
                re = Fr(0); im = Fr(0)
                for i in range(N):
                    t = cm(cconj(u[i]), v[i]); re += t[0]; im += t[1]
                L += re * re + im * im
        L = L * s / len(U)
    else:
        nz = [(i, j) for i in range(N) for j in range(N) if ent(i, j)[0] != 0]
        for v in V:
            for i, j in nz:
                L += (cm(cconj(v[i]), v[j])[0]) * s
    return ok, L

def check(cert):
    return check_dual(cert) if cert['kind'] in ('dual', 'ppt_dual') else check_primal(cert)

if __name__ == '__main__':
    for p in sys.argv[1:]:
        c = json.load(open(p)); ok, v = check(c)
        print(f"{os.path.basename(p)}: kind={c['kind']} {'torus' if c.get('torus') else 'family n=%d' % len(c['z'])} d={c['d']} T={c['T']} k={c['k']} "
              f"{'VALID' if ok else 'INVALID'} {'L' if c['kind'] == 'primal' else 'U'}={float(v):.15f}")
