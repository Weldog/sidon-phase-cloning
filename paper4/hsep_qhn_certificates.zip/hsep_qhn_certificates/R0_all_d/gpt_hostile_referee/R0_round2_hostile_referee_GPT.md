# Independent hostile referee: R0 round-2 analytic certificates

**Input:** `r0_round2_referee.zip` (25 October 2026). **Scope:** claims in `R0_ROUND2_GPT_PROOF.md`, especially whether the actual physical dual matrices agree with the orbit reductions, for each integer `d >= 3`. This audit rebuilds and tests the dual independently; no assertion relies solely on the supplied symbolic checkers.

## Access / integrity

All 11 top-level archive files, all 37 entries in the enclosed proof-package ZIP, and all 20 files (plus a directory entry) in the further enclosed original-input ZIP were successfully opened. Total **68 readable file entries**, counting duplicate files within nested archives; zero failed. The 10 root files listed in `MANIFEST_md5.txt` passed MD5; every ZIP passed `ZipFile.testzip()`.

## Decision table

| Proof claim | Verdict | Grounding |
|---|---|---|
| A: output symmetric restriction | VERIFIED | CPTP map `rho -> Pi_sym rho Pi_sym + Tr[(I-Pi_sym)rho] tau_sym` preserves measure-and-prepare and cannot lower pure symmetric-target overlap. |
| A: PPT upper-bound dual and sign | VERIFIED | `R = Y\otimes I - Z - W^Gamma`; for `J >=0`, `J^Gamma >=0`, `Tr_B J=I`, trace gives `Tr(RJ) <= Tr(Y)`. |
| A: flat-seed lower bound | VERIFIED | Covariant rank-one POVM `d |psi_theta><psi_theta| dtheta` resolves identity, and preparing a posterior top eigenvector achieves the flat-seed moment eigenvalue. |
| A: charge twirling and occupation congruence | VERIFIED | Rebuilt the full physical matrices without referring to the source assembled blocks. |
| B: `N_2`, quadratic, all six orbit entries | VERIFIED | Direct occupation counts and independent quadratic-remainder checks. |
| B: W/Z blocks, `d=3`, every PSD inequality | VERIFIED | Direct physical block construction for `d=3,4,5`; 11 symbolic identities; all-d positivity as below. |
| B: uniqueness of six orbit values within stated ansatz | VERIFIED | Fixed `y`, the `W_[3]` kernel fixes `w0`, singleton Z blocks fix `w3,w4`, `W_[111]` fixes `w5`, and two `W_[21]` equations fix `w2,w1` because `q>0`. |
| C: `N_3`, cubic, 12 orbit entries | VERIFIED | Direct occupation counts, characteristic polynomial, and 12 independent algebraic kernel checks. |
| C: W/Z block families including `d=3` omissions | VERIFIED | Full physical matrices show the stated block sizes; `[1111]` and `[111,-1]` absent in `d=3`. Nonexistent transverse modes correctly have multiplicity zero. |
| C: positivity inequalities for all `d>=3` | VERIFIED | Checked logically step by step, including the `d=3` and `d=4` root bounds. |

## First-principles dual reconstruction

For the normalized occupation basis indexed by `beta`, `|beta|=m`, set `h_beta=m!/prod_i beta_i!`. The integral defining the fidelity operator gives **exactly**

`R_(i,beta),(j,beta') = sqrt(h_beta h_beta')/d^(m+1) * 1{ beta-e_i = beta'-e_j }`.

A sum-charge-invariant dual orbit matrix takes the physical form

`W_(i,beta),(j,beta') = sqrt(h_beta h_beta') * w(orbit(i,beta;j,beta')) * 1{beta+e_i = beta'+e_j}`.

Reversing the input indices in `W` gives the partial transpose; consequently the full dual slack is

`Z_(i,beta),(j,beta') = y delta_ij delta_beta,beta' - R_(i,beta),(j,beta') - W_(j,beta),(i,beta')`.

This is a reconstruction directly from the phase integrals, the symmetric output basis and the definition of partial transpose, not an appeal to the proof's orbit-checker implementation. Conjugating by the diagonal with entries `h_beta^(-1/2)` produces the proof's constant `C=d^(-m-1)` and diagonal `y/h_beta`.

For `m=2`, the sum-charge W blocks are `[3]` (size 1), `[21]` (2), `[111]` (3), and the difference-charge Z blocks are `[2,-1]`, `[11,-1]` (singletons), `[1]` (size d). Rebuilding W_[21] gives `[[w3,w2],[w2,w1]]`, W_[111] gives diagonal `w4`, off-diagonal `w5`; Z_[1] has one distinguished mode with diagonal `y-C-w0`, `d-1` other modes with diagonal `y/2-C-w1`, mutual off-diagonal `-C-w5`, and distinguished-to-other `-C-w2`. These are precisely the claimed entries, including factors of `h_beta`.

For `m=3`, the W block types `[4],[31],[22],[211],[1111]` and difference blocks `[3,-1],[21,-1],[111,-1],[2],[11]` are exhaustive. The nontrivial W blocks are `[[w5,w2],[w2,w1]]` for `[31]`, `[[0,0],[0,0]]` for `[22]`, `[[w8,w9,w7],[w9,w8,w7],[w7,w7,w6]]` for `[211]`, and diagonal `w10` / off-diagonal `w11` for `[1111]`. In Z_[2], the distinguished diagonal is `y-C-w0`, the `d-1` others' diagonal is `y/3-C-w3`, their mutual off-diagonal is `-C-w9`, and the cross entry is `-C-w2`. In Z_[11], the two distinguished diagonals are `y/3-C-w1`, mutual off-diagonal `-C-w4`, other-mode diagonals are `y/6-C-w6`, other-mode mutual off-diagonal `-C-w11`, and cross entries are `-C-w7`. This directly yields every transverse eigenvalue and reduced 2x2 matrix claimed in the manuscript.

## All-d proof: 1 -> 2

The two-type flat moment is `(1/d^3)*[[6d-8,2],[2(d-1),d]]`. The larger eigenvalue `X` solves `(X-d)(X-6d+8)=4(d-1)` and lies strictly between `2d` and `6d` for all integers `d>=3`. The six supplied closed-form `w_j` make: the W_[3] singleton zero; W_[21] PSD with determinant zero and positive diagonal; W_[111] have eigenvalues `0, 3(X-2d)/(4d^4)` (twice); the Z singletons zero; Z_[1] have transverse eigenvalue `((d-2)(6d-X)+8)/(4d^4)>0`; and the last 2x2 is positive-semidefinite with determinant zero and positive diagonals. The objective `dy=X/d^3` equals an achievable value. All 11 independently formulated polynomial kernel/determinant relations reduce to zero modulo the characteristic quadratic.

**Status B: VERIFIED.**

## All-d proof: 1 -> 3

The three-type flat moment is `A_d/d^4`, where

`A_d=[[24d-54,18,0],[6(d-2),6d-3,1],[0,3(d-1),d]]`.

Its characteristic cubic matches the proof exactly. With `Y=rho(A_d)`, `r=(Y-d)/(3(d-1))` and `s=((Y-6d+3)r-1)/(6(d-2))`, the zero-parameter entries `(C2)` satisfy the physical W and Z kernel equations. We independently reduced 12 such equations to zero modulo the cubic, rather than relying on the provided checker.

**Uniform signs:** At `d=3`, the leading 2x2 principal block of `A_3` has Perron root 27; irreducibility yields `Y>27=9d`. For `d>=4`, `Y>24d-54>=9d`. Therefore `w8>2C`, `w1<C/8`, and `0<L<C/[8(d-1)]`. Also `r>0` and `s>0`. At `d=3`, `r>4` implies `s/r>47/24>sqrt(3)`; at `d=4`, the leading 2x2 block exceeds 48, yielding `s/r>2`; for `d>=5`, `Y>24d-54` and `r>8/3` yield `s/r>2`. These inequalities imply `w8+w9>0`, `w8-w9>0`, `y/3+w9>0`, and `0<w6<w8/3`.

The W_[31] block is PSD of rank one, W_[211] has positive antisymmetric eigenvalue and a PSD zero-determinant 2x2 sector, W_[1111] has eigenvalues `0` and `4w10/3>0` (three times), and W_[4]/W_[22] are zero. The Z singleton blocks vanish. Z_[2] has transverse value `y/3+w9>0` and a zero-determinant PSD 2x2. Z_[11] has eigenvalues `y/3-w1>0`, `(Y+3d)/(9d^5)-w6>0` (transverse), plus a PSD zero-determinant 2x2 with a positive diagonal `w8-w1-C`. At `d=3`, the `[1111]` block and `[111,-1]` singleton are absent, and the `[11]` transverse multiplicity is zero: no undefined physical entry is needed.

The objective `dy=Y/d^4` equals the achievable flat-seed value for all `d>=3`.

**Status C: VERIFIED.**

## Independent numerical direct-matrix experiment

The companion script `independent_referee_build.py` directly assembles the full **physical Choi matrices** (not the symbolic reduced matrices) and confirms PSD and equality with the independently constructed posterior-moment top eigenvalue:

| d | m | Choi dimension | min eigenvalue W | min eigenvalue Z | flat / dual objective |
|---:|---:|---:|---:|---:|---:|
| 3 | 2 | 18 | -6.9e-18 | -1.4e-17 | 0.407407407407 |
| 4 | 2 | 40 | -3.6e-17 | -1.6e-17 | 0.264503175473 |
| 5 | 2 | 75 | -1.9e-17 | -1.2e-17 | 0.183153176912 |
| 3 | 3 | 30 | -1.3e-17 | -1.6e-17 | 0.334659125443 |
| 4 | 3 | 80 | -2.4e-17 | -4.5e-17 | 0.193765174354 |
| 5 | 3 | 175 | -1.2e-17 | -2.1e-17 | 0.116897848350 |

Tiny negative floating eigenvalues above are within roundoff; the **analytic PSD proof** does not rely on them. The independent symbolic script, `check_symbolic_referee.py`, passes 11 quadratic and 12 cubic checks.

## Corrections/qualifications before publication

1. The proof establishes all **nontrivial dimensions `d>=3`**. The cases `d=2` (and trivial `d=1`) should be referred to separately if using the unqualified phrase “all dimensions.”
2. The `[1111]` W block, `[111,-1]` Z block and the `[11]` `d-3`-dimensional transverse eigenspace must be explicitly treated as absent/zero-dimensional at `d=3`; the proof does so, but the positivity discussion should retain that qualification.
3. The results bound **measure-and-prepare channels only**, not arbitrary coherent cloners. The proof does not treat `m>=4`.
4. Additional independent journal refereeing remains appropriate for a new all-dimension theorem, but is not an identified mathematical proof gap.

**No disqualifying mathematical gap or false orbit entry was found in the scope examined.**

R0(1→2, all d) VERIFIED
R0(1→3, all d) VERIFIED
