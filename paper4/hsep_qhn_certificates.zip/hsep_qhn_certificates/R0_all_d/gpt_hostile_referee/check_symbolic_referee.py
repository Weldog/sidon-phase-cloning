import sympy as s
D,X,Y=s.symbols('d X Y')

poly2=X**2-(7*D-8)*X + 6*D**2-12*D+4
C2=D**(-3); yy2=X/D**4;q=(X-D)/(2*(D-1))
w0=0;w1=(D-1)*(X-6*D+8)/(4*D**4);w2=-(D-1)/D**4;w3=(X-D)/D**4;w4=(X-2*D)/(2*D**4);w5=(2*D-X)/(4*D**4)
# Directly reconstructed 1->2 Z block for charge e_0:
diag_other=yy2/2-C2-w1;off_other=-C2-w5;cross=-C2-w2;diag_special=yy2-C2-w0
checks2={
'W21det':w3*w1-w2*w2,
'W21row0':w3+2*q*w2,
'W21row1':w2+2*q*w1,
'W111row':w4+2*w5,
'Zsingleton_2-1':yy2-C2-w3,
'Zsingleton_11-1':yy2/2-C2-w4,
'Ztrans':diag_other-off_other -((D-2)*(6*D-X)+8)/(4*D**4),
'Z2x2diag':diag_other+(D-2)*off_other-(X-6*D+8)/(4*D**4),
'Z2x2row':2*q*(diag_other+(D-2)*off_other)+cross,
'Z2x2row2':(D-1)*2*q*cross+diag_special,
'Z2x2det':(diag_other+(D-2)*off_other)*diag_special-(D-1)*cross**2,
}

def chk(expr,var,poly):
 n,den=s.fraction(s.cancel(expr));rem=s.rem(s.Poly(n,var),s.Poly(poly,var)).as_expr()
 return s.factor(rem)==0
for tag,v in checks2.items():
 assert chk(v,X,poly2),tag
print('1->2 independent symbolic checks:',len(checks2),'PASS')

P=s.Matrix([[24*D-54,18,0],[6*(D-2),6*D-3,1],[0,3*(D-1),D]]).charpoly(Y).as_expr()
r=(Y-D)/(3*(D-1));t=((Y-6*D+3)*r-1)/(6*(D-2))
C=D**(-4);y=Y/D**5
L=(D-1)/(D**5*(Y-D))
a=[s.Integer(0)]*12
a[0]=0;a[1]=(D-1)**2/(D**5*(Y-D));a[2]=-(D-1)/D**5
a[3]=a[4]=0;a[5]=(Y-D)/D**5
# [2] diagonal and off-diagonal, [11] both grouped sectors
(a[8],a[10],a[11])=((Y-3*D)/(3*D**5),(Y-6*D)/(6*D**5),-(Y-6*D)/(18*D**5))
a[9]=(a[8]-L)/(D-2)-C
a[6]=r**2/(2*t**2)*(a[8]+a[9]);a[7]=-(t/r)*a[6]
# The equations arise from directly enumerated charge blocks.  We take (3r, 3r,6t), (1,3r), ... as reduced kernel values.
checks3={
'W[31] first':a[5]+3*r*a[2],
'W[31] second':a[2]+3*r*a[1],
'W[211] first':a[8]+a[9]+2*t/r*a[7],
'W[211] second':r*a[7]+t*a[6],
'W[1111]':a[10]+3*a[11],
'Z[2] special':(y-C-a[0])+3*r*(D-1)*(-C-a[2]),
'Z[2] common':(-C-a[2])+3*r*((y/3-C-a[3])+(D-2)*(-C-a[9])),
'Z[11] other':6*t*((y/6-C-a[6])+(D-3)*(-C-a[11]))+6*r*(-C-a[7]),
'Z[11] main':(D-2)*6*t*(-C-a[7])+3*r*((y/3-C-a[1])+(-C-a[4])),
'Z[111,-1]':y/6-C-a[10],
'Z[21,-1]':y/3-C-a[8],
'Z[3,-1]':y-C-a[5],
}
for tag,v in checks3.items():
 assert chk(v,Y,P),tag
print('1->3 independent symbolic checks:',len(checks3),'PASS')
print('cubic agrees:',s.expand(P)==s.expand(Y**3-(31*D-57)*Y**2+(174*D**2-564*D+381)*Y-144*D**3+576*D**2-612*D+162))
