import numpy as np, math, itertools, collections

def occ(d,m):
  for inds in itertools.combinations_with_replacement(range(d),m):
    a=[0]*d
    for i in inds:a[i]+=1
    yield tuple(a)
def e(d,i):return tuple(int(j==i) for j in range(d))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def h(v):return math.factorial(sum(v))//math.prod(math.factorial(x) for x in v)
def signature(p,q):
  rows=tuple(sorted([tuple([p[0][k],p[1][k],q[0][k],q[1][k]]) for k in range(len(p[0]))]))
  rows2=tuple(sorted([tuple([q[0][k],q[1][k],p[0][k],p[1][k]]) for k in range(len(p[0]))]))
  return min(rows,rows2)

def make(d,m):
  I=[e(d,i) for i in range(d)];B=list(occ(d,m));pairs=[(a,b) for a in I for b in B];keyset=set();classes=collections.defaultdict(list)
  for i,p in enumerate(pairs):
    for j,q in enumerate(pairs):
      if add(*p)==add(*q):keyset.add(signature(p,q))
  keys=sorted(keyset);ws={k:ix for ix,k in enumerate(keys)}
  if m==2:
    X=(7*d-8+math.sqrt(25*d*d-64*d+48))/2
    w=[0,(d-1)*(X-6*d+8)/(4*d**4),-(d-1)/d**4,(X-d)/d**4,(X-2*d)/(2*d**4),(2*d-X)/(4*d**4)]
    y=X/d**4; goal=X/d**3
  else:
    A=np.array([[24*d-54,18,0],[6*(d-2),6*d-3,1],[0,3*(d-1),d]],float)
    Y=max(np.linalg.eigvals(A).real)
    r=(Y-d)/(3*(d-1));s=((Y-6*d+3)*r-1)/(6*(d-2));C=1/d**4;y=Y/d**5;L=(d-1)/(d**5*(Y-d))
    w=[0]*12
    w[1]=(d-1)**2/(d**5*(Y-d));w[2]=-(d-1)/d**5
    w[5]=(Y-d)/d**5;w[8]=(Y-3*d)/(3*d**5);w[10]=(Y-6*d)/(6*d**5);w[11]=-w[10]/3
    w[9]=(w[8]-L)/(d-2)-C
    w[6]=r*r/(2*s*s)*(w[8]+w[9]);w[7]=-s/r*w[6]
    goal=Y/d**4
  # Signature indices compared to dimension-5 reference by removing all-zero rows
  def strip(sig):return tuple(v for v in sig if any(v))
  ref_keys=sorted(set(tuple([(0,0,0,0)]*(5-len(strip(x)))+list(strip(x))) for x in keys))
  if d<5:
    Iref=[e(5,i) for i in range(5)]; Bref=list(occ(5,m));ref_keys=sorted(set(signature((aa,bb),(cc,dd)) for aa in Iref for bb in Bref for cc in Iref for dd in Bref if add(aa,bb)==add(cc,dd)))
  label={key:i for i,key in enumerate(ref_keys)}
  vals={k:w[label[tuple([(0,0,0,0)]*(5-len(strip(k)))+list(strip(k)))]] for k in keys}
  n=len(pairs);W=np.zeros((n,n));Z=np.zeros((n,n));R=np.zeros((n,n));WG=np.zeros((n,n));
  for i,(a,b) in enumerate(pairs):
    for j,(ap,bp) in enumerate(pairs):
      fac=math.sqrt(h(b)*h(bp))
      if add(a,b)==add(ap,bp):W[i,j]=fac*vals[signature((a,b),(ap,bp))]
      if sub(b,a)==sub(bp,ap):R[i,j]=fac/d**(m+1)
      if add(ap,b)==add(a,bp):WG[i,j]=fac*vals[signature((ap,b),(a,bp))]
  Z=y*np.eye(n)-R-WG
  assert np.linalg.norm(W-W.T)<1e-10 and np.linalg.norm(Z-Z.T)<1e-10
  mineig=lambda M:float(np.linalg.eigvalsh(M)[0])
  # Direct posterior matrix on output, independent of type model
  posterior=np.zeros((len(B),len(B)))
  for i,b in enumerate(B):
    for j,bp in enumerate(B):
      ct=sum(add(b,e(d,a))==add(bp,e(d,ap)) for a in range(d) for ap in range(d))
      posterior[i,j]=math.sqrt(h(b)*h(bp))*ct/d**(m+1)
  flat=float(np.linalg.eigvalsh(posterior)[-1])
  print(f'd={d} m={m} n={n} number_orbits={len(keys)} W_min={mineig(W):.5g} Z_min={mineig(Z):.5g} flat={flat:.12g} dual={d*y:.12g} difference={flat-d*y:.2g}')
  # In physical representation, distinct difference/sum charges produce invariant blocks, no group quotient assumed.
  wb=collections.defaultdict(list);zb=collections.defaultdict(list)
  for i,(a,b) in enumerate(pairs): wb[add(a,b)].append(i);zb[sub(b,a)].append(i)
  print(' W block-size multiplicities:', dict(sorted(collections.Counter(len(x) for x in wb.values()).items())))
  print(' Z block-size multiplicities:', dict(sorted(collections.Counter(len(x) for x in zb.values()).items())))
  
  for typ,blks,mat in [('W',wb,W),('Z',zb,Z)]:
    for charge,inds in blks.items():
      eig=np.linalg.eigvalsh(mat[np.ix_(inds,inds)])
      if eig[0]<-1e-7: print('NEG BLOCK:', typ,charge,'eigen=',eig,'matrix=',mat[np.ix_(inds,inds)])
  print('W symmetry=',np.linalg.norm(W-W.T))
  assert mineig(W)>-1e-9 and mineig(Z)>-1e-9 and abs(flat-d*y)<1e-11, 'physical matrix reconstruction failed'

if __name__=='__main__':
  for m in (2,3):
    for d in (3,4,5): make(d,m)
