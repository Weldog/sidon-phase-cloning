# Claude: independent check of the new R0 results with my own code (no ChatGPT or Grok code).
# (1) symbolic: the key identities of the 1->2 certificate;  (2) numeric: the Choi-matrix PPT relaxation (an UPPER bound on every
# measure-first channel) for the continuous phase family, solved directly, vs the claimed closed forms (which are achievable values).
import math, numpy as np, sympy as sp, cvxpy as cp, warnings; warnings.filterwarnings('ignore')
exec(open('sep_check.py').read().split('t0=time.time()')[0])
d=sp.symbols('d',positive=True); s=sp.sqrt(25*d**2-64*d+48); X=(7*d-8+s)/2
print("(X-d)(X-6d+8) - 4(d-1) =", sp.simplify(sp.expand((X-d)*(X-6*d+8)-4*(d-1))))
eta=((d-2)*(6*d-X)+8)/(4*d**4)
for dd in [3,4,5,10,100,10**4]:
    Xv=float(X.subs(d,dd)); print(f"  d={dd}: 2d<X<6d: {2*dd<Xv<6*dd}, eta>0: {float(eta.subs(d,dd))>0}")
def ppt_ub(dd,m):
    Xt,dm,dT=torus_X(m,1,dd); Xt=Xt.astype(complex)
    J=cp.Variable((dm*dT,dm*dT),hermitian=True)
    cons=[J>>0, cp.partial_transpose(J,[dm,dT],axis=1)>>0, cp.partial_trace(J,[dm,dT],axis=0)==np.eye(dT)]
    pr=cp.Problem(cp.Maximize(cp.real(cp.trace(J@Xt))),cons); pr.solve(solver=cp.SCS,eps=1e-9,max_iters=200000); return pr.value
for dd in range(3,8):
    cf=(7*dd-8+math.sqrt(25*dd**2-64*dd+48))/(2*dd**3); ub=ppt_ub(dd,2)
    print(f"1->2 d={dd}: PPT upper bound {ub:.9f}  closed form {cf:.9f}  diff {ub-cf:.1e}",flush=True)
for dd in range(3,6):
    A=np.array([[24*dd-54,18,0],[6*(dd-2),6*dd-3,1],[0,3*(dd-1),dd]],float); Y=max(np.linalg.eigvals(A).real)
    ub=ppt_ub(dd,3); print(f"1->3 d={dd}: PPT upper bound {ub:.9f}  rho(A_d)/d^4 {Y/dd**4:.9f}  diff {ub-Y/dd**4:.1e}",flush=True)
