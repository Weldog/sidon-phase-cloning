# Claude: independent check of Grok Bot's G4 values (torus coherent cloning; QH-N relay) with my own SDP code.
import itertools, math, numpy as np, cvxpy as cp, sys, time
def occ(t,d): return [a for a in itertools.product(range(t+1),repeat=d) if sum(a)==t]
def coef(a): t=sum(a); return math.sqrt(math.factorial(t)/np.prod([math.factorial(x) for x in a]))
def sym_vec(phases,t,O,C):  # psi^{⊗t} in normalized occupation basis, psi = d^{-1/2} sum e^{i phase_j}|j>
    d=len(phases); return C*np.exp(1j*(np.array(O)@phases))/d**(t/2)
def torus_X(m,T,d):         # E_theta rho^{⊗m} ⊗ conj(rho)^{⊗T} (output ⊗ input), exact
    Om,Ot=occ(m,d),occ(T,d); Cm=np.array([coef(a) for a in Om]); Ct=np.array([coef(a) for a in Ot])
    idx=[(i,j) for i in range(len(Om)) for j in range(len(Ot))]; n=len(idx); X=np.zeros((n,n))
    A=np.array(Om); B=np.array(Ot)
    for x,(i,j) in enumerate(idx):
        for y,(k,l) in enumerate(idx):
            if np.array_equal(A[i]-A[k], B[j]-B[l]): X[x,y]=Cm[i]*Ct[j]*Cm[k]*Ct[l]/d**(m+T)
    return X,len(Om),len(Ot)
def clone_opt(X,dm,dT):     # max tr(J X), J >= 0 on out⊗in, Tr_out J = I_in
    J=cp.Variable((dm*dT,dm*dT),hermitian=True)
    cons=[J>>0, cp.partial_trace(J,[dm,dT],axis=0)==np.eye(dT)]
    pr=cp.Problem(cp.Maximize(cp.real(cp.trace(J@X))),cons); pr.solve(solver=cp.SCS,eps=1e-9,max_iters=200000)
    return pr.value
def qhn_states(p,r):
    t=np.arange(p); P=[np.array([pow(int(x),j,p) for x in t]) for j in range(1,r+1)]
    for c in itertools.product(range(p),repeat=r):
        f=sum(ci*P[i] for i,ci in enumerate(c))%p; yield 2*np.pi*f/p
def relay_pgm(p,r,T,m):     # PGM on T copies + optimal re-preparation of m copies, QH-N ensemble (exact up to eigen solvers)
    OT,Om=occ(T,p),occ(m,p); CT=np.array([coef(a) for a in OT]); Cm=np.array([coef(a) for a in Om])
    V=[];W=[]
    for ph in qhn_states(p,r): V.append(sym_vec(ph,T,OT,CT)); W.append(sym_vec(ph,m,Om,Cm))
    V=np.array(V); W=np.array(W); M=len(V)
    S=V.T@V.conj()                                   # sum_f |v_f><v_f|
    w,U=np.linalg.eigh(S); Sinv=U@np.diag(1/np.sqrt(w))@U.conj().T
    pr=np.abs((V.conj()@Sinv@V[0]))**2              # p(outcome 0 | f) = |<v_f|S^-1/2|v_0>|^2
    R=(W.T*pr)@W.conj()/M                           # sum_f p(0|f) |w_f><w_f| / M
    return M*np.linalg.eigvalsh(R)[-1]
t0=time.time()
print("TORUS coherent optima (Grok Bot G4 values in brackets):")
for d,T,m,ref in [(5,1,2,9/25),(7,1,2,13/49),(5,1,3,24/125),(7,1,3,36/343)]:
    X,dm,dT=torus_X(m,T,d); v=clone_opt(X,dm,dT); print(f"  d={d} {T}->{m}: SDP {v:.8f}  [Grok {ref:.8f}]  diff {abs(v-ref):.1e}",flush=True)
print("QH-N relay = PGM + optimal re-preparation (Grok Bot: (27+sqrt353)/250 at d=5, (41+5sqrt33)/686 at d=7):")
for p,r,T,m in [(5,3,1,2),(7,3,1,2)]:
    v=relay_pgm(p,r,T,m); print(f"  p={p} r={r} {T}->{m}: {v:.10f}",flush=True)
print("  (27+sqrt353)/250 =",(27+math.sqrt(353))/250,"  (41+5sqrt33)/686 =",(41+5*math.sqrt(33))/686)
print("beyond budget: QH-N r=3, p=5, 2->3 relay (Grok: 0.2156):", relay_pgm(5,3,2,3), f"  time {time.time()-t0:.0f}s")
