# R0 round 2 — exact all-dimension PPT dual certificates

**Private mathematical research. Not for publication without independent expert review.**

**Outcome:** `R0(1→2, all d≥3) PROVED` and, as an additional result, `R0(1→3, all d≥3) PROVED`, subject to the stated continuous-torus, measure-and-prepare, average-global-fidelity model. Proof labels distinguish purely symbolic algebra, exact arithmetic checks, and the analytic PSD argument. Both statements are new proof derivations in this round, not claims of prior peer review.

## A. Common convex-optimization framework (DERIVED / PROVED)

Let \(|\psi_\theta\rangle=d^{-1/2}\sum_{j=1}^d e^{i\theta_j}|j\rangle\), \(\theta\in\mathbb T^d\) Haar-uniform. The input is one copy, the intended output is \(m\) copies (\(m=2,3\)). Let \(B=\operatorname{Sym}^m(\mathbb C^d)\), with normalized occupation basis \(|\beta\rangle\), \(|\beta|=m\), and multiplicity \(h_\beta=m!/\prod_j\beta_j!\). A general output channel can be restricted to \(B\) without reducing average global fidelity: retain the symmetric projection of each output and replace any orthogonal remainder with an arbitrary fixed symmetric state. This trace-preserving postprocessing preserves the measure-and-prepare property and cannot decrease overlap with the target symmetric pure state.

Define \(R=\int_{\mathbb T^d} |\overline{\psi_\theta}\rangle\langle\overline{\psi_\theta}|\otimes (|\psi_\theta\rangle\langle\psi_\theta|)^{\otimes m}\,d\theta\). If \(J\) is the unnormalized Choi matrix of any entanglement-breaking (measure-and-prepare) channel, \(J\ge0\), \(J^\Gamma\ge0\), and \(\operatorname{Tr}_B J=I_d\); its average global cloning fidelity is \(\operatorname{Tr}(RJ)\). This is an upper bound even when an output preparation includes ancillary randomness or arbitrary mixed states; all such channels have separable, hence PPT, Choi matrices.

For any \(W\succeq0\), \(Z=Y\otimes I_B-R-W^\Gamma\succeq0\), weak duality yields \(\operatorname{Tr}(RJ)\le\operatorname{Tr}Y\) for every PPT-feasible \(J\). We choose \(Y=y I_d\). The sign of the partial transpose is a convention: use \(Y\otimes I-R-W^\Gamma=Z\), with \(W\succeq0\); this is exactly the convention in the supplied independent checker.

Congruence by the positive diagonal \(D^{-1}=\operatorname{diag}(h_\beta^{-1/2})\) on the output factor reduces the \(R\) entries to a constant \(C=d^{-(m+1)}\) **inside each difference-charge block** \(\beta-e_i\). The transformed \(W\) entries group by sum charge \(\beta+e_i\), and their real-symmetric orbit entries are denoted \(w_j\). Since the transformation is invertible, PSD of the reduced blocks is equivalent to PSD of the physical dual operators. The transformed diagonal \(Y\) entry is \(y/h_\beta\).

**Achievable flat seed:** the covariant POVM density \(d|\psi_\theta\rangle\langle\psi_\theta|\,d\theta\) is normalized (\(\int d|\psi_\theta\rangle\langle\psi_\theta|\,d\theta=I\)). After observing \(\theta\), prepare the phase-rotated normalized top eigenvector of the posterior \(m\)-copy moment. By covariance its achieved fidelity equals the top eigenvalue of the flat-seed moment matrix. Hence a PPT dual with \(\operatorname{Tr}Y\) equal to that value proves global optimality over all measure-and-prepare channels, not merely a restricted covariant subclass.

The type-reduced moment matrices, obtained by direct occupation counting, are:

\[
N_2(d)=\frac1{d^3}\begin{pmatrix}6d-8&2\\2(d-1)&d\end{pmatrix},\quad
N_3(d)=\frac1{d^4}\begin{pmatrix}24d-54&18&0\\6(d-2)&6d-3&1\\0&3(d-1)&d\end{pmatrix}.
\]

Types are \((1,1),(2)\) for \(m=2\), and \((1,1,1),(2,1),(3)\) for \(m=3\). These nonnegative irreducible matrices have strictly positive Perron eigenvectors for \(d\ge3\).

## B. Complete analytic certificate: 1→2 (PROVED)

For integer \(d\ge3\), put
\[
X=\frac{7d-8+\sqrt{25d^2-64d+48}}2,\quad
 t_2=\frac X{d^3},\quad q=\frac{X-d}{2(d-1)},\quad
 C=\frac1{d^3}.
\]
Then \(X\) is the Perron eigenvalue of \(d^3N_2(d)\) and satisfies
\[
X^2-(7d-8)X+6d^2-12d+4=0,
\qquad (X-d)(X-6d+8)=4(d-1).
\tag{B1}
\]
The positive flat-seed output eigenvector has type values \(\chi_{11}=q,\chi_2=1\).

Choose \(y=X/d^4\) and the following six orbit values (indices agree with the supplied d=3..8 files, after sorting orbit keys):
\[
\begin{array}{c|l}
w_0&0\\
w_1&(d-1)(X-6d+8)/(4d^4)\\
w_2&-(d-1)/d^4\\
w_3&(X-d)/d^4\\
w_4&(X-2d)/(2d^4)\\
w_5&(2d-X)/(4d^4)
\end{array}
\tag{B2}
\]
They are **uniquely determined** in this symmetry-restricted ansatz by the exact kernel (complementary-slackness) equations and the trace equality \(dy=t_2\); there are zero remaining free parameters. In particular, the sum-charge blocks are
\[
W_{[3]}=[w_0],\quad
W_{[21]}=\begin{pmatrix}w_3&w_2\\w_2&w_1\end{pmatrix},\quad
W_{[111]}=\begin{pmatrix}w_4&w_5&w_5\\w_5&w_4&w_5\\w_5&w_5&w_4\end{pmatrix}.
\]
The \(W_{[21]}\) kernel is \((1,2q)\), its determinant is zero by (B1), and its (1,1) entry is strictly positive. The triple block has eigenvalues \(0,3(X-2d)/(4d^4),3(X-2d)/(4d^4)\). \(W_{[3]}=0\).

For difference charge \([2,-1]\), the singleton \(Z\) entry is \(y-C-w_3=0\). For charge \([1,1,-1]\), it is \(y/2-C-w_4=0\). For charge \([1]\), the remaining \(d\times d\) block has \(d-1\) symmetric "other-mode" coordinates and one distinguished coordinate. The \(d-2\) transverse directions have eigenvalue
\[
\eta_2=\frac{(d-2)(6d-X)+8}{4d^4}>0.
\]
The orthogonal two-dimensional sector is
\[
\frac1{d^4}\begin{pmatrix}
 (X-6d+8)/4&-\sqrt{d-1}\\
 -\sqrt{d-1}&X-d
\end{pmatrix}.
\tag{B3}
\]
This has determinant zero by (B1) and positive diagonal entries. Since \(2d<X<6d\) for every \(d\ge3\), all blocks are PSD. The inequalities follow immediately from the closed form for \(X\): \(7d-8>4d\) for \(d\ge3\), and \(\sqrt{25d^2-64d+48}<5d+8\).

The exact dual objective is \(dy=X/d^3=t_2\), attained by the flat-seed POVM. Therefore
\[
\boxed{P_{\mathrm{MF}}^{\rm torus}(d;1\to2)=\frac{7d-8+\sqrt{25d^2-64d+48}}{2d^3},\quad d\ge3.}
\]

## C. Complete analytic certificate: 1→3 (PROVED)

Put \(Y=\lambda_{\max}(d^4 N_3(d))\). Thus \(Y\) is the Perron root of the explicitly defined integer \(3\times3\) matrix
\[
A_d=\begin{pmatrix}24d-54&18&0\\6(d-2)&6d-3&1\\0&3(d-1)&d\end{pmatrix}
\]
and its characteristic polynomial is
\[
\begin{split}
Q_d(Y)={}&Y^3-(31d-57)Y^2+(174d^2-564d+381)Y\\
&-144d^3+576d^2-612d+162=0.
\end{split}
\tag{C1}
\]
Define \(t_3=Y/d^4\), \(r=(Y-d)/(3(d-1))\), and
\[
s=\frac{(Y-6d+3)r-1}{6(d-2)}.
\]
The flat-seed Perron type values are \(\chi_{111}=s,\chi_{21}=r,\chi_3=1\). Set \(C=1/d^4\), \(y=Y/d^5\) (so \(dy=t_3\)), \(L=(d-1)/(d^5(Y-d))\). Choose **the free orbit parameter to be zero**, \(w_3=w_4=0\), and set
\[
\begin{array}{c|l}
w_0&0\\
w_1&(d-1)^2/[d^5(Y-d)]\\
w_2&-(d-1)/d^5\\
w_3&0\\
w_4&0\\
w_5&(Y-d)/d^5\\
w_8&(Y-3d)/(3d^5)\\
w_{10}&(Y-6d)/(6d^5)\\
w_{11}&-w_{10}/3\\
w_9&(w_8-L)/(d-2)-C\\
w_6&[r^2/(2s^2)](w_8+w_9)\\
w_7&-(s/r)w_6.
\end{array}
\tag{C2}
\]
These are the 12 orbit values in the same sorted orbit-key order as the supplied \(d=4,\ldots,8\) certificates. For \(d=3\), the two four-distinct-mode orbits \(w_{10},w_{11}\) are absent, so only ten values are instantiated. All symbols in (C2) are explicit rational functions of the algebraic Perron root \(Y\); none is selected numerically.

**DERIVED — all kernel constraints:** substitution of (C2) into the six orbit-block families reduces the kernel equations to the Perron equations \(A_d(s,r,1)^\top=Y(s,r,1)^\top\), or, equivalently, to multiples of the cubic (C1). No additional symbolic identities are assumed. In particular, the three nonzero output-type kernel values \(s,r,1\) carry occupation factors \(6,3,1\). The transformed \(W\)-blocks by sum charges \([4],[31],[22],[211],[1111]\) have patterns
\[
[0],\quad \begin{pmatrix}w_5&w_2\\w_2&w_1\end{pmatrix},\quad
\begin{pmatrix}0&0\\0&0\end{pmatrix},\quad
\begin{pmatrix}w_8&w_9&w_7\\w_9&w_8&w_7\\w_7&w_7&w_6\end{pmatrix},
\quad (w_{10}-w_{11})I_4+w_{11}{\bf1}{\bf1}^{\top}.
\tag{C3}
\]
The last block is absent when \(d=3\). Its kernel is \(\bf1\); the \([211]\) kernel is \((3r,3r,6s)\); the \([31]\) kernel is \((1,3r)\).

The transformed \(Z\)-blocks by difference charges are \([111,-1]\), \([21,-1]\), \([3,-1]\), \([2]\), and \([11]\), with the first three identically zero (\([111,-1]\) is absent at \(d=3\)). The \([2]\) block has size \(d\), Perron kernel \((3r,\ldots,3r,1)\), transverse eigenvalue \(y/3+w_9\) with multiplicity \(d-2\), and a 2D zero-determinant block with strictly positive last diagonal \(w_5\). The \([11]\) block has size \(d\), Perron kernel \((6s,\ldots,6s,3r,3r)\), a \(d-3\) dimensional transverse eigenvalue \(y/6-w_6+w_{11}\), one antisymmetric eigenvalue \(y/3-w_1\), and a 2D zero-determinant block with positive second diagonal \(w_8-w_1-C\). The zero determinants and exact kernels are identities modulo (C1), verified symbolically and by the companion exact checker.

**PROVED — uniform positive-semidefiniteness:** We establish simple inequalities, not just finitely many sign checks.

1. The Perron root \(Y>9d\) for every \(d\ge3\). At \(d=3\), the leading 2x2 principal submatrix \(\begin{psmallmatrix}18&18\\6&15\end{psmallmatrix}\) has Perron eigenvalue 27, and the full irreducible nonnegative matrix has strictly larger Perron root. For \(d\ge4\), \(Y>24d-54\ge9d\) by the first diagonal entry.
2. Consequently \(r>0\), \(w_8>2C\), \(w_1<C/8\), and \(0<L<C/[8(d-1)]\). Also \(s>0\).
3. In fact \(s/r>\sqrt3\) for \(d=3\) and \(s/r>2\) for every \(d\ge4\). Indeed \(s/r=(Y-6d+3-1/r)/(6(d-2))\). At \(d=3\), \(Y>27,r>4\) imply \(s/r>47/24>\sqrt3\). At \(d=4\), the leading 2x2 principal submatrix has Perron root greater than 48, so \(s/r>(48-24+3-3/8)/12>2\). At \(d\ge5\), use \(Y>24d-54\), \(r>8/3\), and \(6d-27-3/8>0\).
4. From \(w_9=(w_8-L)/(d-2)-C\) we have \(w_8+w_9=(d-1)w_8/(d-2)-C-L/(d-2)>0\), \(w_8-w_9=(d-3)w_8/(d-2)+C+L/(d-2)>0\), and \(y/3+w_9=(d-1)w_8/(d-2)-L/(d-2)>0\).
5. Moreover \(0<w_6=[r^2/(2s^2)](w_8+w_9)<w_8/3\). For \(d=3\), use \(s/r>\sqrt3\) and \((d-1)/(d-2)=2\); for \(d\ge4\), use \(s/r>2\) and \((d-1)/(d-2)\le3/2\).
6. The \([211]\) block in (C3) is PSD: its antisymmetric eigenvalue is \(w_8-w_9>0\); its complementary 2x2 block has an exact kernel and strictly positive diagonal \(w_6\). The \([31]\) block is rank-one PSD because \(w_5>0\), \([22]\) and \([4]\) vanish, and \([1111]\) has eigenvalues \(0,4w_{10}/3,4w_{10}/3,4w_{10}/3\) with \(w_{10}>0\).
7. The \([2]\) difference block is PSD because its transverse eigenvalue \(y/3+w_9\) is positive and the remaining 2x2 block has an exact kernel and positive diagonal \(w_5\). For \([11]\), \(y/3-w_1>0\), \(w_8-w_1-C>0\), and \(y/6-w_6+w_{11}=(Y+3d)/(9d^5)-w_6>0\) because \((Y+3d)/(9d^5)>w_8/3>w_6\). Thus this block is PSD too. The remaining singleton blocks vanish.

Every physical dual PSD condition follows. The dual objective \(dy=Y/d^4=t_3\) matches the feasible flat-seed POVM. Therefore
\[
\boxed{P_{\mathrm{MF}}^{\rm torus}(d;1\to3)=\frac{\rho(A_d)}{d^4},\qquad d\ge3.}
\]
This gives an explicit algebraic answer as the largest real root of (C1), divided by \(d^4\); it does not require a radical expression for the cubic.

## D. Exact reproducibility / finite cross-checks (CA-PROVED)

- All 19 entries in `MANIFEST_md5.txt` matched their archive MD5 hashes.
- The user's supplied **independent** `independent_r0_GPT.py` accepted all six \(1\to2\) and all six \(1\to3\) original exact certificates, for \(d=3,4,5,6,7,8\).
- `R0_1to2_symbolic_verify.py`: reduces 13 essential algebraic kernel/determinant identities modulo the quadratic and invokes the independent exact checker on additional closed-form certificates at \(d=5,8,9,10,12,16,20\), all successful.
- `R0_1to3_symbolic_verify.py`: generates **new non-SDP, zero-free-parameter** certificates from (C2) over \(\mathbb Q[Y]/(Q_d)\). It verifies positive Perron vector, exact kernel constraints, exact objective, and every PSD block using algebraic root isolation and exact Schur complements allowing multiple-dimensional kernels. All checks passed for \(d=3,4,5,6,7,8,9,10,12,16\). The original independent checker requires a positive-definite minor transverse to only one kernel vector and cannot certify deliberate all-zero \([22]\) blocks; the new zero-aware checker fixes that **testing limitation**, not the mathematics.

No observed finite computation is relied on for the all-dimension positivity arguments in sections B and C. The finite checks provide separate reproducibility evidence.

## E. Limits, distinction of claims, and final statement

**PROVED (within the precise SDP model):** both analytic dimension-uniform PPT dual certificates; both equalities for measure-and-prepare 1→2 and 1→3 on the continuous phase torus.

**DERIVED:** the flat-seed type matrices and orbit-block decompositions, given explicitly and mechanically checked. They are elementary occupation combinatorics and can be rechecked without any SDP solver.

**CA-PROVED:** independent exact certificates and root-field block checks for the listed finite dimensions.

**OPEN:** extension to 1→m for \(m\ge4\); arbitrary finite phase codebooks without the requisite torus moment matching; implications for security under verifier-specific acceptance tests; independent journal-level refereeing of these newly derived proofs. Nothing here proves R0 for multiple input copies \(T>1\), nor does it turn a measure-first limitation into a bound on coherent cloners.

**Final line, as requested:** `R0(1→2, all d) PROVED` (nontrivial dimensions \(d\ge3\); \(d=2\) was already known). Additional result: `R0(1→3, all d≥3) PROVED`.
