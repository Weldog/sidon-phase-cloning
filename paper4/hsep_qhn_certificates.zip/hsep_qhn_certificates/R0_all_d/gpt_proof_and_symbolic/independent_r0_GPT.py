"""Independent R0 checker, built in GPT round 6. No import of supplied Grok code.
Certificate arithmetic is in Q[t]/p(t). PSD is checked using a kernel and
Sylvester's criterion on a (n-1)-dimensional principal submatrix, not the
M+vv^T LDL test used by the source package.
"""
import ast, collections, functools, itertools, json, math, os, sys, time
from fractions import Fraction as Q

class RealRootField:
 def __init__(self, polynomial, left, right):
  self.p = tuple(map(Q, polynomial)); self.deg = len(self.p)-1
  assert self.p[-1]==1 and self.deg>=1
  self.left=Q(left); self.right=Q(right)
  assert self.left<=self.right
  self.zero=(Q(0),)*self.deg
  self.one=(Q(1),)+(Q(0),)*(self.deg-1)
  self.x=self.expr([self.left]) if self.deg==1 else self.expr([0,1])
  # rational interval contains a real root: intermediate value theorem
  L=self.polyval(self.p,self.left); H=self.polyval(self.p,self.right)
  assert (self.left==self.right and L==0) or L*H<0, 'root not bracketed'
  if self.left!=self.right:
   # derivative's sign does not vary over this narrow interval
   der=tuple(self.p[i]*i for i in range(1,len(self.p)))
   a,b=self.interv_poly(der)
   assert a>0 or b<0, 'cannot establish unique root'
 def expr(self,coefs):
  z=list(map(Q,coefs))
  for i in range(len(z)-1,self.deg-1,-1):
   if z[i]:
    for j in range(self.deg):z[i-self.deg+j]-=z[i]*self.p[j]
  return tuple((z+[Q(0)]*self.deg)[:self.deg])
 def add(self,a,b):return tuple(x+y for x,y in zip(a,b))
 def neg(self,a):return tuple(-x for x in a)
 def sub(self,a,b):return tuple(x-y for x,y in zip(a,b))
 def mul(self,a,b):
  z=[Q(0)]*(self.deg*2-1)
  for i,x in enumerate(a):
   if x:
    for j,y in enumerate(b):
     if y:z[i+j]+=x*y
  return self.expr(z)
 def scale(self,a,q):return tuple(v*q for v in a)
 def div(self,a,b):return self.mul(a,self.inv(b))
 @staticmethod
 def _trim(a):
  a=list(a)
  while a and not a[-1]:a.pop()
  return a
 @staticmethod
 def _divmod(a,b):
  a=RealRootField._trim(a); b=RealRootField._trim(b)
  quot=[Q(0)]*max(1,len(a)-len(b)+1)
  while len(a)>=len(b):
   k=len(a)-len(b); fac=a[-1]/b[-1]; quot[k]=fac
   for j,c in enumerate(b):a[j+k]-=c*fac
   a=RealRootField._trim(a)
  return RealRootField._trim(quot),a
 def inv(self,a):
  if a==self.zero:raise ZeroDivisionError
  r0,r1=list(self.p),self._trim(a)
  c0,c1=[],[Q(1)]
  while len(r1)>1:
   quotient,r2=self._divmod(r0,r1)
   tmp=[Q(0)]*(len(quotient)+len(c1)-1)
   for i,x in enumerate(quotient):
    for j,y in enumerate(c1):tmp[i+j]+=x*y
   c2=[(c0[i] if i<len(c0) else 0)-(tmp[i] if i<len(tmp) else 0) for i in range(max(len(c0),len(tmp)))]
   r0,r1=r1,r2;c0,c1=c1,self._trim(c2)
   if not r1:raise ZeroDivisionError('not a field element')
  return self.expr([x/r1[0] for x in c1])
 @staticmethod
 def polyval(coeffs,t):
  v=Q(0)
  for c in reversed(coeffs):v=v*t+c
  return v
 def interv_poly(self,coeffs):
  low=high=Q(0)
  for c in reversed(coeffs):
   v=(low*self.left,low*self.right,high*self.left,high*self.right)
   low=min(v)+c;high=max(v)+c
  return low,high
 def sign(self,a):
  if a==self.zero:return 0
  for _ in range(1800):
   lo,hi=self.interv_poly(a)
   if lo>0:return 1
   if hi<0:return -1
   mid=(self.left+self.right)/2
   pm=self.polyval(self.p,mid)
   if pm==0:self.left=self.right=mid
   elif self.polyval(self.p,self.left)*pm<0:self.right=mid
   else:self.left=mid
  raise ArithmeticError('sign undecidable')

def occ(n,d):
 if d==1:return [(n,)]
 return [(j,)+tuple(rest) for j in range(n+1) for rest in occ(n-j,d-1)]
def factor_mult(v):return math.factorial(sum(v))//math.prod(math.factorial(x) for x in v)
def plus(u,v):return tuple(x+y for x,y in zip(u,v))
def minus(u,v):return tuple(x-y for x,y in zip(u,v))
def type_of(u):return tuple(sorted(u,reverse=True))
def key_by_permutation(u,v):
 p=tuple(sorted(zip(u[0],u[1],v[0],v[1])))
 q=tuple(sorted(zip(v[0],v[1],u[0],u[1])))
 return repr(min(p,q))

def spectrum_flat(d,k,F):
 ins=occ(1,d);out=occ(k+1,d);n=k+2
 kinds=sorted(set(type_of(b) for b in out)); reps={t:next(b for b in out if type_of(b)==t) for t in kinds}
 mat=[]
 for ty in kinds:
  beta=reps[ty];row=[]
  for tz in kinds:
   value=Q(0)
   for alpha in ins:
    for alpha2 in ins:
     for beta2 in out:
      if type_of(beta2)==tz and plus(alpha,beta)==plus(alpha2,beta2):value+=Q(factor_mult(beta2),d**n)
   row.append(value)
  mat.append(row)
 return kinds,mat

def assemble(d,k,cert,F):
 A=occ(1,d); B=occ(k+1,d); pairs=list(itertools.product(A,B));
 zblocks=collections.defaultdict(list);wblocks=collections.defaultdict(list)
 for a,b in pairs:
  zblocks[type_of(minus(b,a))].append((a,b)) if minus(b,a)==type_of(minus(b,a)) else None
  wblocks[type_of(plus(a,b))].append((a,b)) if plus(a,b)==type_of(plus(a,b)) else None
 # each representative must include *all* pairs having that exact signed difference / sum
 # above construction has no permutation reduction within the representative's stabilizer;
 # PSD on representatives is necessary and sufficient by coordinate-permutation covariance.
 y={tuple(t):F.expr(c) for t,c in zip(cert['ytypes'],cert['y'])}
 w={name:F.expr(coeff) for name,coeff in cert['w'].items()}
 types,flat=spectrum_flat(d,k,F)
 chi={ty:F.expr(cert['chi_by_type'][repr(ty)]) for ty in types}
 matrices=[]; z=F.zero; one=F.one; C=F.scale(one,Q(1,d**(k+2)))
 for charge, ps in zblocks.items():
  M=[]
  for i,(a,b) in enumerate(ps):
   row=[]
   for j,(a2,b2) in enumerate(ps):
    # partial transpose of a permutation-invariant W
    W=w[key_by_permutation((a,b2),(a2,b))]
    diag=F.scale(y[type_of(a)],Q(1,factor_mult(b))) if i==j else z
    row.append(F.sub(F.sub(diag,C),W))
   M.append(row)
  v=[F.scale(chi[type_of(b)],factor_mult(b)) for a,b in ps]
  matrices.append(('Z',charge,ps,M,v))
 for charge,ps in wblocks.items():
  M=[[w[key_by_permutation(p,q)] for q in ps] for p in ps]
  v=[F.scale(chi[type_of(b)],factor_mult(b)) for a,b in ps]
  matrices.append(('W',charge,ps,M,v))
 return matrices,flat,types,chi,y,A

def null_and_pd_minor(M,v,F):
 z=F.zero;sz=len(M)
 for i in range(sz):
  if sum_field((F.mul(M[i][j],v[j]) for j in range(sz)),F)!=z:
   return False,'kernel is not exact'
 if sz==1:return True,'singleton kernel'
 cut=next(i for i,x in enumerate(v) if x!=z)
 others=[i for i in range(sz) if i!=cut]
 # Fraction-free Schur (leading principal pivots positive), distinct from source's M+vv^T.
 V=[[M[i][j] for j in others] for i in others]
 for i in range(sz-1):
  pivot=V[i][i]
  if F.sign(pivot)<=0:return False,'principal submatrix nonpositive pivot '+str(i)
  if i==sz-2:break
  inv=F.inv(pivot)
  for j in range(i+1,sz-1):
   for k in range(j,sz-1):
    V[j][k]=F.sub(V[j][k],F.mul(F.mul(V[j][i],inv),V[i][k]))
    V[k][j]=V[j][k]
 return True,'PSD by exact principal-minor Sylvester'

def sum_field(iterable,F):
 v=F.zero
 for x in iterable:v=F.add(v,x)
 return v

def check_one(path,fast_fail=False):
 t0=time.monotonic();cert=json.load(open(path));d=cert['d'];k=cert['k'];F=RealRootField(cert['p_low_to_high'],cert['lambda_lo'],cert['lambda_hi'])
 matrices,N,types,chi,y,ins=assemble(d,k,cert,F)
 ev=[]
 for i in range(len(types)):
  lhs=sum_field([F.scale(chi[types[j]],N[i][j]) for j in range(len(types))],F)
  ev.append(lhs==F.mul(F.x,chi[types[i]]))
 positive=[F.sign(chi[t])>0 for t in types]
 dualtrace=sum_field((F.scale(y[type_of(a)],factor_mult(a)) for a in ins),F)
 trace_ok=dualtrace==F.x
 full_ok=True;err=[]
 for kind,typ,ps,M,v in matrices:
  if fast_fail:
   # A single negative *exact* diagonal quadratic form disproves PSD.
   negatives=[(i,F.interv_poly(M[i][i])) for i in range(len(M)) if F.sign(M[i][i])<0]
   if negatives:
    ii,interval=negatives[0]
    err.append(f'{kind}{typ} basis index {ii}: exact negative diagonal, rational enclosure ({float(interval[0]):.15g}, {float(interval[1]):.15g})')
    full_ok=False
    break
   continue
  ok,msg=null_and_pd_minor(M,v,F)
  if not ok:full_ok=False;err.append(f'{kind}{typ}: {msg}')
 dt=time.monotonic()-t0
 return {'d':d,'k':k,'Perron_equation':all(ev),'positive':all(positive),'dual_trace':trace_ok,'blocks':len(matrices),'PSD':full_ok if not fast_fail or err else 'undetermined','problems':err[:12],'elapsed_s':round(dt,2)}

if __name__=='__main__':
 files=sys.argv[1:]
 for file in files:
  print('BEGIN',os.path.basename(file),flush=True)
  try:print('RESULT',check_one(file,'d4_k5' in file),flush=True)
  except Exception as e:print('ERROR',repr(e),flush=True)
