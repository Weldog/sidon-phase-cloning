"""Standalone symbolic and exact finite-check verification for R0(1->2).

Uses SymPy for algebra, plus the independent_R0_GPT.py checker from the
round-2 archive when available. This is not the proof itself: see the
accompanying mathematical proof for the all-dimension positivity argument.
"""
from fractions import Fraction as Q
from math import isqrt
import ast, json, pathlib, sys
import sympy as s

D, X = s.symbols('d X', integer=True, positive=True)
POLY = X**2-(7*D-8)*X+(6*D**2-12*D+4)
q = (X-D)/(2*(D-1))
w = (
    0,
    (D-1)*(X-6*D+8)/(4*D**4),
    -(D-1)/D**4,
    (X-D)/D**4,
    (X-2*D)/(2*D**4),
    (2*D-X)/(4*D**4),
)
y = X/D**4
C = 1/D**3

def assert_poly_identity(z, name):
    r = s.together(z)
    numer, denom = s.fraction(r)
    remainder = s.rem(s.Poly(numer, X), s.Poly(POLY, X)).as_expr()
    assert s.simplify(remainder)==0, (name, remainder)
    print('PROVED symbolic identity:',name)

assert_poly_identity((X-D)*(X-6*D+8)-4*(D-1),'key quadratic')
assert_poly_identity(w[3]+2*q*w[2],'W[21] row 1 kernel')
assert_poly_identity(w[2]+2*q*w[1],'W[21] row 2 kernel')
assert_poly_identity(w[4]+2*w[5],'W[111] kernel')
assert_poly_identity(y-C-w[3],'Z [2,-1] kernel')
assert_poly_identity(y/2-C-w[4],'Z [1,1,-1] kernel')

zdiag=y/2-C-w[1]
zoff=-C-w[5]
h=-C-w[2]
last=y-C-w[0]
assert_poly_identity(s.simplify(h)+1/D**4,'Z cross')
assert_poly_identity(zdiag+(D-2)*zoff-(X-6*D+8)/(4*D**4),'Z 2x2 top-left')
assert_poly_identity(zdiag-zoff-((D-2)*(6*D-X)+8)/(4*D**4),'Z transverse eigen')
assert_poly_identity(2*q*(zdiag+(D-2)*zoff)+h,'Z common row kernel')
assert_poly_identity(2*q*(D-1)*h+last,'Z distinguished row kernel')
assert_poly_identity(w[1]*w[3]-w[2]**2,'W[21] determinant')
assert_poly_identity((zdiag+(D-2)*zoff)*last-(D-1)*h**2,'Z 2x2 determinant')
assert s.simplify(w[4]-w[5]-3*(X-2*D)/(4*D**4))==0
print('PSD signs: X>2d (d>=3), X<6d; proved in companion note.')

# For independent exact checks beyond the supplied d<=8 archive:
base=pathlib.Path(__file__).resolve().parent
if not (base/'independent_r0_GPT.py').exists():
 print('Independent finite checker unavailable; symbolic algebra checks completed.')
 sys.exit()
sys.path.insert(0,str(base))
from independent_r0_GPT import check_one

base_keys=json.load(open(base/'certs/t1r0_d5_k1.json'))['w']
base_keys=sorted(base_keys, key=lambda x:tuple(sorted(ast.literal_eval(x))))

def rat(r):
    return str(Q(r))

def build_cert(d):
    dd=d; disc=25*d*d-64*d+48
    sq=isqrt(disc)
    if sq*sq==disc:
        T=Q(7*d-8+sq,2*d**3)
        poly=[rat(-T),'1']; lo=hi=T
        coord=lambda a,b:[rat(Q(a)+Q(b)*T)]
    else:
        N=10**36; sn=isqrt(disc*N*N)
        lo=Q((7*d-8)*N+sn,2*d**3*N)
        hi=Q((7*d-8)*N+sn+1,2*d**3*N)
        poly=[rat(Q(6*d*d-12*d+4,d**6)),rat(-Q(7*d-8,d**3)),'1']
        coord=lambda a,b:[rat(a),rat(b)]
    wk=[coord(0,0),
      coord(-Q((d-1)*(3*d-4),2*d**4),Q(d-1,4*d)),
      coord(-Q(d-1,d**4),0),
      coord(-Q(1,d**3),Q(1,d)),
      coord(-Q(1,d**3),Q(1,2*d)),
      coord(Q(1,2*d**3),-Q(1,4*d))]
    labels={repr(((0,0,0,0),)*(d-5)+ast.literal_eval(k)):wk[j]
            for j,k in enumerate(base_keys)}
    return dict(d=d,T=1,k=1,p_low_to_high=poly,lambda_lo=rat(lo),lambda_hi=rat(hi),
       ytypes=[[1]+[0]*(d-1)],y=[coord(0,Q(1,d))],w=labels,
       chi_by_type={repr((2,)+(0,)*(d-1)):coord(1,0),
                    repr((1,1)+(0,)*(d-2)):coord(-Q(d,2*(d-1)),Q(d**3,2*(d-1)))})

for d in (5,8,9,10,12,16,20):
    cert=build_cert(d)
    path=base/f't1r0_gpt_closedform_d{d}_k1.json'
    path.write_text(json.dumps(cert,indent=2))
    result=check_one(str(path))
    assert result['Perron_equation'] and result['positive'] and result['dual_trace'] and result['PSD'],result
    print('EXACT independent checker passed:',d,'blocks:',result['blocks'],'s:',result['elapsed_s'])
print('ALL VERIFIED')
