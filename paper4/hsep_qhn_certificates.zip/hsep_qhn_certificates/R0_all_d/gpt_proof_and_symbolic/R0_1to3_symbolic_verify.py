"""Exact algebraic-field validation of candidate W22=0 R0 1->3 cert, d>=4."""
import sys,ast,json,math,pathlib,itertools,collections,functools,time
import sympy as sp
from fractions import Fraction as Q
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from independent_r0_GPT import RealRootField, assemble, spectrum_flat, type_of
D,Y=sp.symbols('d Y'); root=pathlib.Path(__file__).resolve().parent
C=1/D**4;y=Y/D**5
r=(Y-D)/(3*(D-1));u=((Y-6*D+3)*r-1)/(6*(D-2))
W=[sp.Integer(0)]*12
W[0]=sp.Integer(0)
W[5]=y-C;W[10]=y/6-C;W[11]=-W[10]/3;W[8]=y/3-C
W[1]=(D-1)**2/(D**5*(Y-D));W[2]=-(D-1)/D**5
W[3]=W[4]=sp.Integer(0)
L=(D-1)/(D**5*(Y-D))
W[9]=(W[8]-L)/(D-2)-C
W[6]=r*r/(2*u*u)*(W[8]+W[9])
W[7]=-u/r*W[6]
P=sp.Matrix([[24*D-54,18,0],[6*(D-2),6*D-3,1],[0,3*(D-1),D]]).charpoly(Y).as_expr().expand()
# Exact symbolic kernel equations for the five Z and five W charge types.
# All remainders must vanish in Q(d)[Y]/(P).
def assert_mod_cubic(expr, name):
    numerator=sp.together(expr).as_numer_denom()[0]
    rem=sp.factor(sp.rem(sp.Poly(numerator,Y),sp.Poly(P,Y)).as_expr())
    assert rem==0,(name,rem)
    print('PROVED symbolic cubic identity:',name,flush=True)
assert_mod_cubic(W[5]+3*r*W[2],'W[31] first kernel')
assert_mod_cubic(W[2]+3*r*W[1],'W[31] second kernel')
assert_mod_cubic(W[8]+W[9]+2*(u/r)*W[7],'W[211] first kernel')
assert_mod_cubic(r*W[7]+u*W[6],'W[211] second kernel')
assert_mod_cubic(W[10]+3*W[11],'W[1111] kernel')
assert_mod_cubic((y-C)+3*r*(D-1)*(-C-W[2]),'Z[2] distinguished kernel')
assert_mod_cubic(3*r*((W[8]-W[3])+(D-2)*(-C-W[9]))+(-C-W[2]),'Z[2] common kernel')
assert_mod_cubic(6*u*((W[10]-W[6])+(D-3)*(-C-W[11]))+6*r*(-C-W[7]),'Z[11] upper kernel')
assert_mod_cubic((D-2)*6*u*(-C-W[7])+3*r*(W[8]-W[1]-C-W[4]),'Z[11] lower kernel')
assert_mod_cubic(y/6-C-W[10],'Z[111,-1] singleton')
assert_mod_cubic(y/3-C-W[8],'Z[21,-1] singleton')
assert_mod_cubic(y-C-W[5],'Z[3,-1] singleton')
for idx,expr in enumerate(W):
 assert expr is not None
for d in (3,4,5,6,7,8,9,10,12,16):
 start=time.monotonic()
 pp=sp.Poly(P.subs(D,d),Y)
 roots=pp.intervals(eps=sp.Rational(1,10**45))
 aa,bb=roots[-1][0]
 # convert to t = Y/d^4
 low=Q(str(aa))/d**4;high=Q(str(bb))/d**4
 if low==high: print('special rational')
 ppT=sp.Poly(sp.expand(P.subs({D:d,Y:sp.Symbol('t')*d**4})/d**12),sp.Symbol('t'))
 fpoly=[str(c) for c in reversed(ppT.all_coeffs())]
 field=RealRootField(fpoly,str(low),str(high))
 def coeff(expr):
  rat=sp.factor(sp.together(expr.subs(D,d)))
  nn,dd=sp.fraction(rat)
  numerator=sp.Poly(nn,Y,domain='QQ');denominator=sp.Poly(dd,Y,domain='QQ')
  pp2=sp.Poly(P.subs(D,d),Y,domain='QQ')
  invden=sp.invert(denominator,pp2)
  mod=(numerator*invden).rem(pp2)
  vec=[Q(str(mod.nth(j)))*d**(4*j) for j in range(3)]
  return [str(v) for v in vec]
 keys=sorted(json.load(open(root/'certs/t1r0_d5_k2.json'))['w'],key=lambda k:tuple(sorted(ast.literal_eval(k))))
 def key_resize(k):
  v=ast.literal_eval(k)
  if d>=5: res=((0,0,0,0),)*(d-5)+v
  elif d==4:res=v[1:]
  else:
   if any(row!=(0,0,0,0) for row in v[:2]):return None
   res=v[2:]
  return repr(res)
 cert=dict(d=d,T=1,k=2,p_low_to_high=fpoly,lambda_lo=str(low),lambda_hi=str(high),
  ytypes=[[1]+[0]*(d-1)],y=[coeff(y)],
  w={key_resize(keys[j]):coeff(W[j]) for j in range(12) if key_resize(keys[j]) is not None},
  chi_by_type={repr((3,)+(0,)*(d-1)):coeff(sp.Integer(1)),
   repr((2,1)+(0,)*(d-2)):coeff(r),
   repr((1,1,1)+(0,)*(d-3)):coeff(u)})
 path=root/f't1r0_gpt_zero_d{d}_k2.json'
 path.write_text(json.dumps(cert,indent=2))
 blocks,N,types,chi,Yfield,ins=assemble(d,2,cert,field)
 def sumF(els):
  v=field.zero
  for e in els:v=field.add(v,e)
  return v
 ev=all(sumF(field.scale(chi[types[j]],N[i][j]) for j in range(len(types)))==field.mul(field.x,chi[types[i]]) for i in range(len(types)))
 tr=sumF(field.scale(Yfield[type_of(a)],1) for a in ins)==field.x
 positive=all(field.sign(v)>0 for v in chi.values())
 def check_psd(M):
  n=len(M); zero=field.zero
  if n==0:return True
  inds=[i for i in range(n) if field.sign(M[i][i])>0]
  if any(field.sign(M[i][i])<0 for i in range(n)):return False
  if not inds:
   return all(M[i][j]==zero for i in range(n) for j in range(n))
  k=inds[0]; idc=[i for i in range(n) if i!=k]
  pivot=M[k][k]; inv=field.inv(pivot)
  V=[[field.sub(M[i][j],field.mul(field.mul(M[i][k],inv),M[k][j])) for j in idc] for i in idc]
  return check_psd(V)
 psd=all(check_psd(M) for kind,charge,ps,M,v in blocks)
 kern=all(all(sumF(field.mul(M[i][j],v[j]) for j in range(len(v)))==field.zero for i in range(len(v))) for kind,charge,ps,M,v in blocks)
 print('d',d,'eigen',ev,'trace',tr,'chi_positive',positive,'kernel',kern,'PSD',psd,'blocks',len(blocks),'s',round(time.monotonic()-start,1),flush=True)
 assert all([ev,tr,positive,kern,psd]),'FAILED'
print('ALL k2 exact checks passed')
