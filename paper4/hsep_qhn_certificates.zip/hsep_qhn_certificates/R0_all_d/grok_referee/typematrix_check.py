"""Own code (Grok Bot), r57: exact comparison of my first-principles flat-seed type matrix (fp_check.flat_seed_lambda) with the
proof's d^3 N_2(d) and A_d = d^4 N_3(d): identical characteristic polynomials for d = 3..30 (m = 2) and d = 3..20 (m = 3).
Charpoly coefficients of both sides are polynomials in d of degree <= 6 (entries linear in d, size <= 3), so agreement at > 7
points proves equality of the charpolys for all d >= 3."""
import sys, json, sympy as sp
sys.path.insert(0, 'src'); import fp_check as fc
lam = sp.Symbol('lam'); ok = {}
for m, rng in ((2, range(3, 31)), (3, range(3, 21))):
    for d in rng:
        keys, N = fc.flat_seed_lambda(d, m)
        if m == 2: G = sp.Matrix([[6*d-8, 2], [2*(d-1), d]])
        else: G = sp.Matrix([[24*d-54, 18, 0], [6*(d-2), 6*d-3, 1], [0, 3*(d-1), d]])
        ok[f'm{m} d{d}'] = sp.expand(N.charpoly(lam).as_expr() - G.charpoly(lam).as_expr()) == 0
print(json.dumps({'all_equal': all(ok.values()), 'n': len(ok), 'failures': [k for k, v in ok.items() if not v]}))
