"""Own code (Grok Bot), r57: negative controls for fp_check.py (the checker must reject corrupted duals)."""
import sys, json, sympy as sp
sys.path.insert(0, 'src'); import fp_check as fc
orig = fc.closed_forms
def mk(m, mod):
    def cf(mm):
        P, y, C, w, o = orig(mm); w = dict(w); y = mod(w, y); return P, y, C, w, o
    return cf
tests = {
 'm2 swap w1,w3': (2, lambda w, y: (w.__setitem__(1, orig(2)[3][3]) or w.__setitem__(3, orig(2)[3][1]) or y)),
 'm2 y*(1-1e-6)': (2, lambda w, y: y*(1-sp.Rational(1, 10**6))),
 'm3 w6*1.01': (3, lambda w, y: (w.__setitem__(6, w[6]*sp.Rational(101, 100)) or y)),
 'm3 y*(1-1e-6)': (3, lambda w, y: y*(1-sp.Rational(1, 10**6))),
 'm3 w9 -> w9+C/10': (3, lambda w, y: (w.__setitem__(9, w[9] + 1/(10*fc.D**4)) or y)),
}
for name, (m, mod) in tests.items():
    fc.closed_forms = mk(m, mod)
    for d in (3, 5, 9):
        r = fc.run(m, d); print(json.dumps({'test': name, 'd': d, 'PASS': r['PASS'], 'ALL_PSD': r['ALL_PSD'], 'root_exact': r['dual_obj_is_root_exact']}))
    fc.closed_forms = orig
