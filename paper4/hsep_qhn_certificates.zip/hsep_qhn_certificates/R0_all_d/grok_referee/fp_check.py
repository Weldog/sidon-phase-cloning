"""Own code (Grok Bot), r57: first-principles, exact, zero-aware check of the closed-form PPT duals in R0_ROUND2_GPT_PROOF.md.
Independent of ChatGPT's and of my earlier t1r0 code. Rebuilds from the definitions:
  basis |i>|beta> of C^d (x) Sym^m (normalised occupation states), h_beta = m!/prod beta_j!;
  R~ = D^-1 R D^-1 has entry C = d^-(m+1) iff beta - e_i = beta' - e_i' (difference charge), else 0;
  W~ entry ((i,b),(i',b')) (same sum charge b+e_i = b'+e_i') = w[orbit], orbit = S_d-class of the entry;
  Z~ = diag(y/h_beta) - R~ - W~^Gamma,  W~^Gamma[(i,b),(i',b')] = W~[(i',b),(i,b')].
Values are taken from the proof's closed forms (B2)/(C2), typed in from the proof text, in the field Q(X) (m=2) or Q(Y) (m=3).
PSD of every block type is decided exactly: symmetric pivoting LDL^T in the number field (zero test = exact remainder mod the
minimal polynomial; sign test = mpmath interval evaluation at an isolating interval of width < 1e-60). Zero pivots with nonzero
rows => not PSD. Also checks: dual objective d*y equals lambda_max of the flat-seed operator, computed from first principles.
Usage: python3 -B src/fp_check.py m d_from d_to  -> JSON lines to stdout."""
import sys, json, itertools, time, math
from fractions import Fraction as F
import sympy as sp
from mpmath import iv, mp
iv.dps = 90; mp.dps = 90
D, Yv = sp.symbols('d Y')

def closed_forms(m):
    if m == 2:  # (B2); generator X with X^2-(7d-8)X+6d^2-12d+4=0, Perron root
        X = Yv; P = X**2 - (7*D-8)*X + 6*D**2 - 12*D + 4
        y = X/D**4; C = 1/D**3
        w = {0: sp.Integer(0), 1: (D-1)*(X-6*D+8)/(4*D**4), 2: -(D-1)/D**4, 3: (X-D)/D**4, 4: (X-2*D)/(2*D**4), 5: (2*D-X)/(4*D**4)}
        return P, y, C, w, X/D**3
    Y = Yv
    A = sp.Matrix([[24*D-54, 18, 0], [6*(D-2), 6*D-3, 1], [0, 3*(D-1), D]])
    P = sp.expand(A.charpoly(Y).as_expr())
    C = 1/D**4; y = Y/D**5
    r = (Y-D)/(3*(D-1)); s = ((Y-6*D+3)*r - 1)/(6*(D-2)); L = (D-1)/(D**5*(Y-D))
    w = {0: sp.Integer(0), 1: (D-1)**2/(D**5*(Y-D)), 2: -(D-1)/D**5, 3: sp.Integer(0), 4: sp.Integer(0), 5: (Y-D)/D**5,
         8: (Y-3*D)/(3*D**5), 10: (Y-6*D)/(6*D**5)}
    w[11] = -w[10]/3; w[9] = (w[8]-L)/(D-2) - C; w[6] = r**2/(2*s**2)*(w[8]+w[9]); w[7] = -(s/r)*w[6]
    return P, y, C, w, Y/D**4

class Field:
    def __init__(self, P_d):
        x = sp.Symbol('x')
        f = sp.Poly(P_d.subs(Yv, x), x, domain='QQ')
        roots = sorted(sp.Poly(f, x).real_roots(), key=lambda r: float(r))
        top = roots[-1]
        # minimal polynomial of the largest real root
        mpoly = None
        for fac, _ in sp.factor_list(f)[1]:
            if sp.Poly(fac, x).eval(top) == 0 if top.is_Rational else any(abs(float(rr) - float(top)) < 1e-30 for rr in sp.Poly(fac, x).real_roots()):
                mpoly = sp.Poly(fac, x).monic(); break
        self.mp = mpoly; self.n = mpoly.degree(); self.x = x
        self.c = [F(str(c)) for c in reversed(mpoly.all_coeffs())]  # low->high, monic
        if self.n == 1:
            v = -self.c[0]; self.lo = self.hi = v
        else:
            ivs = mpoly.intervals(eps=sp.Rational(1, 10**70))
            a, b = ivs[-1][0]; self.lo, self.hi = F(str(a)), F(str(b))
        self.root_iv = iv.mpf([str(self.lo.numerator) + '/' + str(self.lo.denominator), str(self.hi.numerator) + '/' + str(self.hi.denominator)]) if self.n > 1 else None
        self.top_float = float(top)
    def red(self, coeffs):
        c = list(coeffs) + [F(0)] * max(0, 2*self.n - len(coeffs))
        for k in range(len(c)-1, self.n-1, -1):
            t = c[k]
            if t:
                for j in range(self.n):
                    c[k-self.n+j] -= t * self.c[j]
                c[k] = F(0)
        return tuple(c[:self.n])
    def mul(self, a, b):
        c = [F(0)] * (2*self.n - 1)
        for i, ai in enumerate(a):
            if ai:
                for j, bj in enumerate(b):
                    c[i+j] += ai * bj
        return self.red(c)
    def add(self, a, b): return tuple(p+q for p, q in zip(a, b))
    def sub(self, a, b): return tuple(p-q for p, q in zip(a, b))
    def const(self, q): return tuple([F(q)] + [F(0)]*(self.n-1))
    def iszero(self, a): return all(v == 0 for v in a)
    def inv(self, a):
        x = self.x
        g = sp.Poly([sp.Rational(v.numerator, v.denominator) for v in reversed(a)], x, domain='QQ')
        h = sp.invert(g, self.mp)
        return self.red([F(str(c)) for c in reversed(sp.Poly(h, x).all_coeffs())])
    def sign(self, a):
        if self.iszero(a): return 0
        if self.n == 1: return 1 if a[0] > 0 else -1
        v = iv.mpf(0)
        for coef in reversed(a):
            v = v * self.root_iv + iv.mpf(str(coef.numerator) + '/' + str(coef.denominator))
        if v.a > 0: return 1
        if v.b < 0: return -1
        raise RuntimeError('sign undecided')
    def from_expr(self, e, d):
        e = sp.together(sp.sympify(e).subs(D, d)); num, den = sp.fraction(e)
        x = self.x
        nP = sp.Poly(num.subs(Yv, x), x, domain='QQ'); dP = sp.Poly(den.subs(Yv, x), x, domain='QQ')
        h = (nP * sp.invert(dP, self.mp)).rem(self.mp)
        cs = [F(str(c)) for c in reversed(h.all_coeffs())] if not h.is_zero else [F(0)]
        return self.red(cs)
    def val(self, a):
        return float(sum(float(c) * self.top_float**k for k, c in enumerate(a)))

def psd_exact(Fd, M):
    """symmetric-pivot LDL^T; returns (is_psd, rank)"""
    M = [row[:] for row in M]; n = len(M); idx = list(range(n)); rank = 0
    while idx:
        piv = None
        for i in idx:
            s = Fd.sign(M[i][i])
            if s < 0: return False, rank
            if s > 0 and piv is None: piv = i
        if piv is None:
            ok = all(Fd.iszero(M[i][j]) for i in idx for j in idx)
            return ok, rank
        rank += 1; ip = Fd.inv(M[piv][piv]); rest = [i for i in idx if i != piv]
        for i in rest:
            if Fd.iszero(M[i][piv]): continue
            f = Fd.mul(M[i][piv], ip)
            for j in rest:
                if not Fd.iszero(M[piv][j]):
                    M[i][j] = Fd.sub(M[i][j], Fd.mul(f, M[piv][j]))
        idx = rest
    return True, rank

def occ(d, m):
    for c in itertools.combinations_with_replacement(range(d), m):
        b = [0]*d
        for j in c: b[j] += 1
        yield tuple(b)

def label(d, i, b, i2, b2):
    t = tuple(sorted(t for t in ((int(i == j), b[j], int(i2 == j), b2[j]) for j in range(d)) if t != (0, 0, 0, 0)))
    t2 = tuple(sorted(t for t in ((int(i2 == j), b2[j], int(i == j), b[j]) for j in range(d)) if t != (0, 0, 0, 0)))
    return min(t, t2)

def orbit_order(m):
    """all W orbit labels (d = m+2 has every orbit), ordered as the padded sorted cert keys: by #modes, then lexicographic"""
    d = m + 2; labs = set()
    for b in occ(d, m):
        for i in range(d):
            sig = tuple(b[j] + (i == j) for j in range(d))
            for i2 in range(d):
                if sig[i2] >= 1:
                    b2 = tuple(sig[j] - (i2 == j) for j in range(d))
                    labs.add(label(d, i, b, i2, b2))
    return sorted(labs, key=lambda t: (len(t), t))

def hb(b, m): return math.factorial(m) // math.prod(math.factorial(x) for x in b)

def flat_seed_lambda(d, m):
    """first-principles flat-seed operator K_{b,b'} = d^-(m+1) sqrt(h h') #{(j,k): b - b' = e_k - e_j}; type reduction with
    basis f_tau = sum_{b in tau} sqrt(h_b) e_b (symmetric Perron vector); returns exact type matrix (times d^(m+1))"""
    types = {}
    for b in occ(d, m):
        types.setdefault(tuple(sorted(b, reverse=True)), []).append(b)
    keys = sorted(types)
    N = sp.zeros(len(keys))
    for a, ta in enumerate(keys):
        b = types[ta][0]
        for c, tc in enumerate(keys):
            tot = 0
            for b2 in types[tc]:
                diff = [b[j] - b2[j] for j in range(d)]
                if all(x == 0 for x in diff): cnt = d
                elif sorted(diff) == [-1] + [0]*(d-2) + [1]: cnt = 1
                else: cnt = 0
                # K f_tc component on e_b: K_{b b2} sqrt(h_b2) = sqrt(h_b h_b2) cnt sqrt(h_b2) / d^(m+1); coefficient of f_ta: / sqrt(h_b)
                tot += cnt * hb(b2, m)
            N[a, c] = tot
    return keys, N

def run(m, d):
    t0 = time.time()
    P, y_e, C_e, w_e, obj_e = closed_forms(m)
    Fd = Field(P.subs(D, d))
    order = orbit_order(m)
    w = {}
    for k, e in w_e.items():
        if k < len(order): w[order[k]] = Fd.from_expr(e, d)
    y = Fd.from_expr(y_e, d); C = Fd.const(F(1, d**(m+1)))
    out = {'m': m, 'd': d, 'minpoly_deg': Fd.n, 'n_orbits_total': len(order)}
    # flat seed: lambda_max of exact type matrix vs d*y
    keys, N = flat_seed_lambda(d, m)
    lam = sp.Symbol('lam'); cp = sp.Poly(N.charpoly(lam).as_expr(), lam)
    dy = Fd.mul(Fd.const(d), y)  # = objective
    dyv = Fd.val(dy)
    # dual objective must be a root of charpoly(N/d^(m+1)) and the largest one
    cpz = sp.Poly(sp.expand(cp.as_expr().subs(lam, lam * d**(m+1))), lam)
    roots = [float(r) for r in sp.Poly(cpz, lam).nroots(n=30)]
    out['dual_obj_float'] = dyv
    out['flat_seed_lambda_max_float'] = max(roots)
    # exact root test: cpz(dy) == 0 in the field
    acc = Fd.const(0)
    for c in cpz.all_coeffs():
        acc = Fd.add(Fd.mul(acc, dy), Fd.const(F(str(c))))
    out['dual_obj_is_root_exact'] = Fd.iszero(acc)
    # dy is an exact root of cpz (tested above); it is the largest root iff it is closer to max(roots) than half the gap to the
    # next-largest root (roots computed to 30 digits; float comparison, gap reported)
    rs = sorted(set(round(r, 25) for r in roots)); gap = rs[-1] - rs[-2] if len(rs) > 1 else float('inf')
    out['root_gap'] = gap
    out['dual_obj_is_largest'] = abs(dyv - rs[-1]) < min(1e-12, gap / 2)
    # enumerate all basis vectors once
    basis = [(i, b) for b in occ(d, m) for i in range(d)]
    bysum, bydiff = {}, {}
    for (i, b) in basis:
        s = tuple(b[j] + (i == j) for j in range(d)); df = tuple(b[j] - (i == j) for j in range(d))
        bysum.setdefault(s, []).append((i, b)); bydiff.setdefault(df, []).append((i, b))
    missing = set()
    def W(i, b, i2, b2):
        lab = label(d, i, b, i2, b2)
        if lab not in w: missing.add(lab); return Fd.const(0)
        return w[lab]
    res = {'W': {}, 'Z': {}}
    seen = set()
    for s, vecs in bysum.items():
        cls = tuple(sorted(s, reverse=True))
        if cls in seen: continue
        seen.add(cls)
        M = [[W(i, b, i2, b2) for (i2, b2) in vecs] for (i, b) in vecs]
        ok, rk = psd_exact(Fd, M); res['W'][str(tuple(x for x in cls if x))] = {'size': len(vecs), 'psd': ok, 'rank': rk}
    seen = set()
    for df, vecs in bydiff.items():
        cls = tuple(sorted(df, reverse=True))
        if cls in seen: continue
        seen.add(cls)
        M = []
        for (i, b) in vecs:
            row = []
            for (i2, b2) in vecs:
                e = Fd.sub(Fd.const(0), C)
                e = Fd.sub(e, W(i2, b, i, b2))       # W~^Gamma[(i,b),(i2,b2)] = W~[(i2,b),(i,b2)]
                if (i, b) == (i2, b2): e = Fd.add(e, Fd.mul(y, Fd.const(F(1, hb(b, m)))))
                row.append(e)
            M.append(row)
        ok, rk = psd_exact(Fd, M); res['Z'][str(tuple(x for x in cls if x))] = {'size': len(vecs), 'psd': ok, 'rank': rk}
    out['blocks'] = res
    out['missing_labels'] = [str(x) for x in missing]
    out['ALL_PSD'] = all(v['psd'] for g in res.values() for v in g.values()) and not missing
    out['PASS'] = out['ALL_PSD'] and out['dual_obj_is_root_exact'] and out['dual_obj_is_largest']
    out['secs'] = round(time.time() - t0, 2)
    return out

if __name__ == '__main__':
    m, a, b = map(int, sys.argv[1:4])
    for d in range(a, b + 1):
        print(json.dumps(run(m, d)), flush=True)
