"""Own code (Grok Bot), r57: all-d symbolic referee of the Perron-sector (non-singleton, d-dependent) Z blocks.
Reads the entry pattern of each d-dependent block from my first-principles construction (fp_check.label/occ) at d = 7 with
symbolic w_j (pattern is d-independent once d > support size: entries depend only on orbit labels), then forms the general-d
2-dimensional symmetric sector and transverse eigenvalues with symbolic d, substitutes the proof's closed forms and reduces
modulo the Perron polynomial in Q(d)[Y]. Also checks the pattern is identical at d = 6, 7, 8."""
import sys, json, sympy as sp
sys.path.insert(0, 'src'); import fp_check as fc
D, Yv = fc.D, fc.Yv
def pattern(m, d, dvec_support):
    order = fc.orbit_order(m); ws = sp.symbols(f'w0:{len(order)}'); yS, CS = sp.symbols('y C')
    delta = [0]*d
    for j, v in dvec_support: delta[j] += v
    vecs = [(i, tuple(delta[j] + (i == j) for j in range(d))) for i in range(d)]
    vecs = [(i, b) for i, b in vecs if min(b) >= 0]
    def W(i, b, i2, b2): return ws[order.index(fc.label(d, i, b, i2, b2))]
    Z = sp.Matrix(len(vecs), len(vecs), lambda p, q: (yS/fc.hb(vecs[p][1], m) if p == q else 0) - CS - W(vecs[q][0], vecs[p][1], vecs[p][0], vecs[q][1]))
    supp = [j for j, v in dvec_support]
    oth = [k for k, (i, b) in enumerate(vecs) if i not in supp]; dist = [k for k, (i, b) in enumerate(vecs) if i in supp]
    pat = {'O_d': Z[oth[0], oth[0]], 'O_o': Z[oth[0], oth[1]], 'X': [Z[k, oth[0]] for k in dist], 'Dm': Z.extract(dist, dist)}
    # consistency: all other-diag equal, all other-offdiag equal, cross entries independent of the 'other' index
    ok = all(Z[k, k] == pat['O_d'] for k in oth) and all(Z[p, q] == pat['O_o'] for p in oth for q in oth if p != q) \
        and all(Z[k, o] == Z[k, oth[0]] for k in dist for o in oth)
    return pat, ok, ws, yS, CS
results = {}
for m, blocks in ((2, {'[1]': [(0, 1)]}), (3, {'[2]': [(0, 2)], '[11]': [(0, 1), (1, 1)]})):
    P, y_e, C_e, w_e, obj = fc.closed_forms(m)
    for name, sup in blocks.items():
        pats = {d: pattern(m, d, sup) for d in (6, 7, 8)}
        same = all(str(pats[d][0]) == str(pats[7][0]) for d in (6, 8)) and all(p[1] for p in pats.values())
        pat, ok, ws, yS, CS = pats[7]
        sub = {yS: y_e, CS: C_e}; sub.update({ws[k]: v for k, v in w_e.items()})
        n = D - len(sup)
        transverse = sp.simplify((pat['O_d'] - pat['O_o']).subs(sub))
        Dm = pat['Dm']; X = pat['X']
        if len(sup) == 1:
            A = Dm[0, 0]; xc = X[0]; anti = None
        else:
            assert Dm[0, 0] == Dm[1, 1] and X[0] == X[1]
            A = Dm[0, 0] + Dm[0, 1]; xc = X[0]; anti = sp.simplify((Dm[0, 0] - Dm[0, 1]).subs(sub))
            # sym combo (e_a+e_b)/sqrt2 with u = sum others/sqrt n: <s|Z|u> = sqrt(2n) xc
        B = pat['O_d'] + (n - 1)*pat['O_o']
        k = n * (2 if len(sup) == 2 else 1)
        det = sp.together((A*B - k*xc**2).subs(sub))
        num = sp.fraction(det)[0]
        rem = sp.factor(sp.rem(sp.Poly(sp.expand(num), Yv), sp.Poly(P, Yv)).as_expr())
        results[f'm={m} {name}'] = {'pattern_same_d6_7_8': same, 'O_d': str(pat['O_d']), 'O_o': str(pat['O_o']), 'cross': [str(x) for x in X],
            'dist_block': str(Dm.tolist()), 'transverse_eig(mult d-%d)' % (len(sup)+1): str(sp.factor(transverse)),
            'antisym_eig': None if anti is None else str(sp.factor(anti)), 'sym_sector_diag_A': str(sp.factor(sp.together(A.subs(sub)))),
            'sym_sector_diag_B': str(sp.factor(sp.together(B.subs(sub)))), 'det_mod_P': str(rem)}
print(json.dumps(results, indent=1))
