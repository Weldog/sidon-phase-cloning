#!/usr/bin/env python3
"""STANDALONE checker for the task-1 certificate (Python 3 standard library only; does not import any other file).
Claim (for the task-1 file; other files: upper bound only, any d, T, k): the optimal measure-and-prepare (entanglement-breaking) average global fidelity P_EB of cloning 2 -> 3 copies of
the continuous phase family psi_theta = 5^{-1/2} sum_t e^{i theta_t}|t> (theta uniform on the torus) in d = 5 satisfies
      L <= P_EB <= U,
U rational (from the JSON certificate), L = root of an integer sextic in an exact rational interval.
Upper bound: P_EB <= PPT relaxation <= tr Y for any dual-feasible (Y, W) (weak duality). Rescaled form (congruence by
S = diag sqrt(m_a m_b)): need W~ >= 0 and Z~ = Y~ (x) diag(1/m_b) - X~ - W~^{T_A} >= 0, X~[(a,b),(a',b')] = [b-a = b'-a']/5^5,
tr Y = sum_a m_a Y~_aa. Positive definiteness is tested exactly (Fractions) by LDL^T: all pivots > 0.
Lower bound: the flat-seed covariant strategy (PGM-type measurement + optimal re-preparation) has value lambda_max(N),
N[b,b'] = sum_{a,a'} sqrt(m_a m_a' m_b m_b') 5^{-5} [a+b = a'+b']; any Rayleigh quotient is <= lambda_max (checked with
60-digit Decimal arithmetic and a 1e-45 safety margin); the sextic's root interval is checked by an exact sign change."""
import json, sys, itertools, math
from fractions import Fraction as F
from decimal import Decimal, getcontext
getcontext().prec = 60
cert = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'logs/t1_cert.json'))
d, T, k = cert['d'], cert['T'], cert['k']; n = 2*T + k
assert all(isinstance(v, int) for v in (d, T, k))
def comps(m):
    out = []
    for c in itertools.combinations_with_replacement(range(d), m):
        v = [0]*d
        for x in c: v[x] += 1
        out.append(tuple(v))
    return out
def mult(g): return math.factorial(sum(g)) // math.prod(math.factorial(x) for x in g)
A, B = comps(T), comps(T+k)
P = lambda s: tuple(int(x) for x in s.split(','))
y = {P(s): F(v) for s, v in cert['y_tilde'].items()}
assert set(y) == set(A)
def pd(M):
    M = [r[:] for r in M]; m = len(M)
    for i in range(m):
        if M[i][i] <= 0: return False
        for r in range(i+1, m):
            if M[r][i]:
                f = M[r][i] / M[i][i]
                for c in range(i, m): M[r][c] -= f*M[i][c]
    return True
# W~ blocks: each block lists its (a,b) pairs; all pairs in a block must share a+b (else W~^{T_A} would leave the sigma blocks)
Wentry = {}
okW = True
for blk in cert['W_tilde_blocks']:
    pairs = [(P(a), P(b)) for a, b in blk['pairs']]
    M = [[F(x) for x in row] for row in blk['matrix']]
    assert len({tuple(x+y_ for x, y_ in zip(a, b)) for a, b in pairs}) == 1
    assert all(M[i][j] == M[j][i] for i in range(len(M)) for j in range(len(M)))
    okW &= pd(M)
    for i, p1 in enumerate(pairs):
        for j, p2 in enumerate(pairs): Wentry[(p1, p2)] = M[i][j]
print("all W~ blocks symmetric positive definite:", okW, "(", len(cert['W_tilde_blocks']), "blocks )")
# Z~ in sigma = b - a blocks; also check that no W~^{T_A} entry falls outside the blocks (it cannot, by the a+b assertion)
blocks = {}
for a in A:
    for b in B: blocks.setdefault(tuple(x-y_ for x, y_ in zip(b, a)), []).append((a, b))
okZ = True; mx = 0
for s, l in blocks.items():
    m = len(l); mx = max(mx, m); Z = [[F(0)]*m for _ in range(m)]
    for r, (a2, b) in enumerate(l):
        for c, (a, b2) in enumerate(l):
            v = -F(1, d**n) + (y[a2] / mult(b) if r == c else 0)
            v -= Wentry.get(((a, b), (a2, b2)), 0)          # W~^{T_A}[(a',b),(a,b')] = W~[(a,b),(a',b')]
            Z[r][c] = v
    okZ &= pd(Z)
print("all Z~ blocks positive definite:", okZ, "(", len(blocks), "blocks, max size", mx, ")")
U = sum(mult(a) * y[a] for a in A)
assert U == F(cert['U'])
print("upper bound U = tr Y =", U, "~", float(U))
# lower bound
if 'seed_minpoly' not in cert:
    print('no exact lower-bound data in this certificate; upper bound only'); print('CHECK', 'PASS' if (okW and okZ) else 'FAIL'); sys.exit(0)
co = [int(c) for c in cert['seed_minpoly']]
ev = lambda x: sum(c * x**(len(co)-1-i) for i, c in enumerate(co))
lo, hi = F(cert['seed_lo']), F(cert['seed_hi'])
print("sextic has a sign change on [lo, hi]:", ev(lo) * ev(hi) < 0, "; width", float(hi - lo))
sq = {m: Decimal(m).sqrt() for m in range(1, 50)}
byg = {}
for a in A:
    for j, b in enumerate(B): byg.setdefault(tuple(x+y_ for x, y_ in zip(a, b)), []).append((a, j))
N = [[Decimal(0)]*len(B) for _ in B]
for g, lst in byg.items():
    for a, j in lst:
        for a2, j2 in lst:
            N[j][j2] += (Decimal(mult(a)*mult(a2)*mult(B[j])*mult(B[j2]))).sqrt() / Decimal(d**n)
v = [Decimal(1)]*len(B)
for _ in range(200):
    w = [sum(N[i][j]*v[j] for j in range(len(B))) for i in range(len(B))]
    nm = max(abs(x) for x in w); v = [x/nm for x in w]
Nv = [sum(N[i][j]*v[j] for j in range(len(B))) for i in range(len(B))]
rq = sum(a*b for a, b in zip(v, Nv)) / sum(a*a for a in v)
Lcert = rq - Decimal('1e-45')
print("Rayleigh-quotient lower bound L =", Lcert)
print("L agrees with the sextic root interval to 1e-29:", abs(Lcert - Decimal(lo.numerator)/Decimal(lo.denominator)) < Decimal('1e-29'))
print("certified bracket: %s <= P_EB(torus, d=5, 2->3) <= %s ; width %.3e" % (str(Lcert)[:22], str(float(U)), float(U) - float(Lcert)))
print("CHECK", "PASS" if (okW and okZ and ev(lo)*ev(hi) < 0 and Decimal(U.numerator)/Decimal(U.denominator) >= Lcert) else "FAIL")
