#!/usr/bin/env python3
"""STANDALONE checker (Python 3 standard library only; imports nothing else from this round) for the ZERO-GAP exact dual
of the torus relay (entanglement-breaking) cloning value, d = 5, 2 -> 3 (logs/t1_exact_dual.json).
Claim: P_EB(torus, d=5, 2->3) = lambda exactly, lambda = the root in [lo, hi] of the integer sextic.
 Upper bound: EB <= PPT relaxation <= tr Y for any feasible (Y, W) of the dual
   Z~_sigma = diag(y_a / m_b) - J / 5^5 - (W~^{T_A})_sigma >= 0  (every sigma = b - a),   W~_tau >= 0  (every tau = a + b),
 here S_5-invariant: y by sorted type of a, W~ entries by the S_5-orbit label of the column multiset
 {(a_c, b_c, a'_c, b'_c)} (symmetrised in the two pairs). Blocks of permuted sigma / tau are permutation-congruent to the
 representative (sorted) block, so PSD is checked on representatives only;
 with --full every one of the sigma and tau blocks is checked exactly (no symmetry argument needed).
 Lower bound: the flat-seed covariant measure-and-prepare strategy has value lambda_max(N) (r39, DERIVED); here N' = D^{-1/2} N D^{1/2}
   has an exact positive eigenvector chi with eigenvalue lambda, so lambda_max(N) = lambda (Perron-Frobenius, N' >= 0 entrywise).
Arithmetic: K = Q(sqrt2)[L]/(g), exact Fractions; signs by rigorous rational interval enclosure of sqrt2 and lambda."""
import json, sys, itertools, math
from fractions import Fraction as F
args = [x for x in sys.argv[1:] if not x.startswith('--')]; FULL = '--full' in sys.argv
J = json.load(open(args[0] if args else 'logs/t1_exact_dual.json'))
d, T, k = J['d'], J['T'], J['k']; n = 2*T + k; dn = d**n
def qa(x, y): return (x[0] + y[0], x[1] + y[1])
def qs(x, y): return (x[0] - y[0], x[1] - y[1])
def qm(x, y): return (x[0]*y[0] + 2*x[1]*y[1], x[0]*y[1] + x[1]*y[0])
def qi(x):
    nn = x[0]*x[0] - 2*x[1]*x[1]; return (x[0]/nn, -x[1]/nn)
Z0, O1 = (F(0), F(0)), (F(1), F(0))
G = [(F(a), F(b)) for a, b in J['g_cubic_over_Qsqrt2_low_to_high']]
def kmul(x, y):
    p = [Z0]*5
    for i in range(3):
        for j in range(3): p[i+j] = qa(p[i+j], qm(x[i], y[j]))
    for e in (4, 3):
        t = p[e]; p[e] = Z0
        for j in range(3): p[e-3+j] = qs(p[e-3+j], qm(t, G[j]))
    return tuple(p[:3])
def kadd(x, y): return tuple(qa(a, b) for a, b in zip(x, y))
def ksub(x, y): return tuple(qs(a, b) for a, b in zip(x, y))
def kc(p, q=0): return ((F(p), F(q)), Z0, Z0)
def kz(x): return all(c[0] == 0 and c[1] == 0 for c in x)
def kinv(x):
    cols = [kmul(x, tuple(O1 if i == j else Z0 for i in range(3))) for j in range(3)]
    M = [[cols[j][i] for j in range(3)] + [O1 if i == 0 else Z0] for i in range(3)]
    for c in range(3):
        r = next(r for r in range(c, 3) if not (M[r][c][0] == 0 and M[r][c][1] == 0)); M[c], M[r] = M[r], M[c]
        iv = qi(M[c][c]); M[c] = [qm(v, iv) for v in M[c]]
        for r in range(3):
            if r != c: f = M[r][c]; M[r] = [qs(M[r][j], qm(f, M[c][j])) for j in range(4)]
    return tuple(M[i][3] for i in range(3))
L = (Z0, O1, Z0)
def parse(e): return tuple((F(a), F(b)) for a, b in e)
# ---- embedding: lambda in [lo, hi], root of the sextic (sign change); sqrt2 enclosed
sext = [int(c) for c in J['sextic_high_to_low']]; lo, hi = F(J['lambda_lo']), F(J['lambda_hi'])
def pv(P, x):
    v = F(0)
    for c in P: v = v*x + c
    return v
assert pv(sext, lo) * pv(sext, hi) < 0, 'no sign change'
S2 = (F(14142135623730950488016887242096980785696, 10**40), F(14142135623730950488016887242096980785697, 10**40))
assert S2[0]**2 < 2 < S2[1]**2
def imul(a, b): ps = [a[0]*b[0], a[0]*b[1], a[1]*b[0], a[1]*b[1]]; return (min(ps), max(ps))
def iad(a, b): return (a[0] + b[0], a[1] + b[1])
LI = [lo, hi]
def ival(x):
    v = (F(0), F(0)); p = (F(1), F(1))
    for i in range(3):
        v = iad(v, imul(iad((x[i][0], x[i][0]), imul((x[i][1], x[i][1]), S2)), p)); p = imul(p, (LI[0], LI[1]))
    return v
def refine():
    m = (LI[0] + LI[1]) / 2
    if (pv(sext, m) > 0) == (pv(sext, LI[0]) > 0): LI[0] = m
    else: LI[1] = m
def sign(x):
    if kz(x): return 0
    for _ in range(500):
        a, b = ival(x)
        if a > 0: return 1
        if b < 0: return -1
        refine()
    raise RuntimeError
acc = kc(0)
for c in sext: acc = kadd(kmul(acc, L), kc(c))
print("g divides the sextic (sextic(L) = 0 in K):", kz(acc))
# the real root in [lo, hi] is a root of g (and not of its conjugate g~): g~ has no root there
Gc = [(a, -b) for a, b in G]
def gint(GG):
    v = imul((LI[0], LI[1]), (LI[0], LI[1])); v = imul(v, (LI[0], LI[1]))
    for j in range(3):
        c = iad((GG[j][0], GG[j][0]), imul((GG[j][1], GG[j][1]), S2)); p = (F(1), F(1))
        for _ in range(j): p = imul(p, (LI[0], LI[1]))
        v = iad(v, imul(c, p))
    return v
for _ in range(20): refine()
a, b = gint(Gc); print("conjugate factor has no root in the lambda interval:", a > 0 or b < 0)
assert a > 0 or b < 0
# ---- structure
def comps(m):
    out = []
    for c in itertools.combinations_with_replacement(range(d), m):
        v = [0]*d
        for x in c: v[x] += 1
        out.append(tuple(v))
    return out
def mult(gm): return math.factorial(sum(gm)) // math.prod(math.factorial(x) for x in gm)
A, B = comps(T), comps(T+k)
def srt(v): return tuple(sorted(v, reverse=True))
def lab(p, q):
    def c(p, q): return tuple(sorted(zip(p[0], p[1], q[0], q[1])))
    return repr(min(c(p, q), c(q, p)))
y = {tuple(t): parse(e) for t, e in zip(J['ytypes'], J['y'])}; w = {kk: parse(e) for kk, e in J['w'].items()}
def psd(M):
    M = [r[:] for r in M]; m = len(M)
    for i in range(m):
        s = sign(M[i][i])
        if s < 0: return False
        if s == 0:
            if any(not kz(M[r][i]) for r in range(i+1, m)): return False
            continue
        ip = kinv(M[i][i])
        for r in range(i+1, m):
            if not kz(M[r][i]):
                f = kmul(M[r][i], ip)
                for c in range(i, m): M[r][c] = ksub(M[r][c], kmul(f, M[i][c]))
    return True
sig, tau = {}, {}
for a_ in A:
    for b_ in B:
        s = tuple(x - z for x, z in zip(b_, a_)); t = tuple(x + z for x, z in zip(a_, b_))
        if FULL or s == srt(s): sig.setdefault(s, []).append((a_, b_))
        if FULL or t == srt(t): tau.setdefault(t, []).append((a_, b_))
okW = all(psd([[w[lab(p, q)] for q in l] for p in l]) for l in tau.values())
print(f"all {len(tau)} {'(ALL, --full)' if FULL else 'representative'} W~ blocks PSD (exact):", okW)
okZ = True
for s, l in sig.items():
    M = [[ksub(ksub(kmul(y[srt(a2)], kc(F(1, mult(b)))) if r == c else kc(0), kc(F(1, dn))), w[lab((a, b), (a2, b2))])
          for c, (a, b2) in enumerate(l)] for r, (a2, b) in enumerate(l)]
    okZ &= psd(M)
print(f"all {len(sig)} {'(ALL, --full)' if FULL else 'representative'} Z~ blocks PSD (exact):", okZ)
trY = kc(0)
for a_ in A: trY = kadd(trY, kmul(kc(mult(a_)), y[srt(a_)]))
print("tr Y = sum_a m_a y_a equals lambda exactly:", kz(ksub(trY, L)))
# lower bound: N' chi = lambda chi with chi > 0, N'[b,b'] = sum_{a+b=a'+b'} sqrt(m_a m_a') m_b' / d^n
chi = {eval(kk): parse(e) for kk, e in J['chi_by_type'].items()}
def ksq(m):
    r = math.isqrt(m)
    if r*r == m: return kc(r)
    r2 = math.isqrt(m // 2); assert 2*r2*r2 == m; return kc(0, r2)
byg = {}
for a_ in A:
    for b_ in B: byg.setdefault(tuple(x + z for x, z in zip(a_, b_)), []).append((a_, b_))
eig_ok = True
for b_ in B:
    acc = kc(0)
    for a_ in A:
        for (a2, b2) in byg[tuple(x + z for x, z in zip(a_, b_))]:
            acc = kadd(acc, kmul(kmul(ksq(mult(a_)*mult(a2)), kc(F(mult(b2), dn))), chi[srt(b2)]))
    eig_ok &= kz(ksub(acc, kmul(L, chi[srt(b_)])))
pos = all(sign(c) > 0 for c in chi.values())
print("N' chi = lambda chi on all", len(B), "rows, chi > 0:", eig_ok and pos)
print(f"lambda in [{float(LI[0]):.25f}, {float(LI[1]):.25f}]")
print("ZERO-GAP: lambda <= P_EB(torus, d=5, 2->3) <= tr Y = lambda.  CHECK", "PASS" if (okW and okZ and eig_ok and pos and kz(ksub(trY, L))) else "FAIL")
